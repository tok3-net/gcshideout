<?php
$starttime = microtime();
$protectedpage = 1;
include("common.php");
$navigationhead = "Active Topics";

$sql = "SELECT DISTINCT threadid, postdate, subject FROM ".TABLE_POSTS." WHERE recipientid = '0' ORDER BY postdate DESC LIMIT 999";
$exe = runQuery($sql);

$output = "<TABLE BORDER=1 CELLSPACING=1 CELLPADDING=3 STYLE=\"border-collapse: collapse;\" WIDTH=100%>"
	."<TR><TD CLASS='BoardColumn'>Topic</TD><TD CLASS='BoardColumn'>Board</TD>"
	."<TD CLASS='BoardColumn'>Category</TD><TD CLASS='BoardColumn'>Last Post</TD></TR>";
$countvar = "0";
while ($row = fetchResultArray($exe))
{
  if ($countvar < "25")
  {
  $threadid = $row['threadid'];
  $subject = $row['subject'];
  $postdate = $row['postdate'];
  $threadarray[] = "blah";
  if (!in_array($threadid, $threadarray))
  {
  $threadarray[] = $threadid;
  $topicsql = "SELECT boardid, postidlast FROM ".TABLE_THREADS." WHERE ID = '$threadid' LIMIT 1";
  $topicexe = runQuery($topicsql);
  $topicrow = fetchResultArray($topicexe);
  $lastpost = $topicrow['postidlast'];
  $boardid = $topicrow['boardid'];
  $boardsql = "SELECT boardname, groupid FROM ".TABLE_BOARDS." WHERE ID = '$boardid' LIMIT 1";
  $boardexe = runQuery($boardsql);
  $boardrow = fetchResultArray($boardexe);
  $boardname = $boardrow['boardname'];
  $groupid = $boardrow['groupid'];
  $groupsql = "SELECT groupname FROM ".TABLE_GROUPS." WHERE ID = '$groupid' LIMIT 1";
  $groupexe = runQuery($groupsql);
  $grouprow = fetchResultArray($groupexe);
  $groupname = $grouprow['groupname'];

  $canViewBoard = checkBoardAccess($boardid);
  if ($canViewBoard)
  {
    $output .= ""
	."<TR>"
	."<TD CLASS='BoardRowBody'><A HREF='thread.php?threadid=".$threadid."&lastpostid=".$lastpost."' CLASS='SubjectLink'>".applyOnlyTextEffects($subject)."</A></TD>"
	."<TD CLASS='BoardRowBody'><A HREF='board.php?boardid=".$boardid."' CLASS='SubjectLink'>".applyOnlyTextEffects($boardname)."</A></TD>"
	."<TD CLASS='BoardRowBody'><A HREF='index.php?action=viewgroup&groupid=".$groupid."' CLASS='SubjectLink'>".applyOnlyTextEffects($groupname)."</A></TD>"
	."<TD CLASS='BoardRowBody'>".dateNeat($postdate)."</TD></TR>"
	."";
  }
  else
  {
    $output .= ""
	."<TR>"
	."<TD CLASS='BoardRowBody' COLSPAN=4><B># # # This Message Posted To A Private Board # # #</B></TD>"
	."</TR>"
	."";
  }
  $countvar ++;
  }
  }
  else
  {
    $done = "yes";
  }
  
}
$output .= "</TABLE>";

$output = "<TABLE BORDER\"0\" WIDTH=\"100%\" CLASS=\"BoardRowBody\">"
	."<TR><TD WIDTH=\"100%\" CLASS=\"BoardRowBody\">"
	.$output
	."</TD></TR></TABLE>";
$pagecontents = $output;
include("layout.php");
?>