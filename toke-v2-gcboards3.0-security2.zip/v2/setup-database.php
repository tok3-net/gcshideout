<?php
   $pagetitle = "Setup";
   
   include("common.php");
   
   $ThemeName = "plain";
   $bodycolor = "#E9E9E9";
   $marginx = $marginy = 15;
   if (!$_POST && $action == "runquery") { exit; }
   if (!$mysql)
   {
     echo "Please set up your MySQL connection in common.php";
     Exit();
   }
   else
   {
     if ($action == "runquery")
     {
       $whattodo = $_POST['whattodo'];
       if ($whattodo == "tables")
       {
         $sqlfile = "sql/database-tables.sql";
       }
       elseif ($whattodo == "data")
       {
         $sqlfile = "sql/database-data.sql";
       }
       elseif ($whattodo == "rename")
       {
         $sqlfile = "sql/rename-tables.sql";
       }
       else
       {
         $action = "";
       }
       $handle = fopen($sqlfile, "rb");
       $sql = fread($handle, filesize($sqlfile));
       fclose($handle);
       if ($whattodo == "rename")
       {
         $whattorenameto = $_POST['whattorenameto'];
         $sql = str_replace("NEWTABLENAME", $whattorenameto, $sql);
       }

       // get_magic_quotes_gpc() was removed in PHP 8; magic_quotes_gpc was
       // removed entirely in PHP 5.4 (2012), so this always returned false
       // on any supported PHP anyway -- this branch never ran.
       $exe = multiQuery($sql, "yes");
       if ($exe)
       {
         $status = "<B CLASS='green'>Your query was executed successfully</B>\n";
         $sql = "";
       }
       else
       {
         $status = "<B CLASS='red'>Your query was not executed:</B><BR>\n"
                  ."MySQL said: ".mysqli_error($mysql)."\n";
       }
       $status .= "<P>\n";
       $action = "";
     }
     
     if (!$action || $action == "")
     {
       $output = "Enter the SQL query or queries to execute here:<BR>\n"
                ."<FORM ACTION='$PHP_SELF' METHOD=POST>\n"
                .inputHidden("action", "runquery")
                // .inputTextArea("sql", $sql, 70, 15)."<BR>\n"
	  ."<B>Create Tables </B><INPUT TYPE=\"RADIO\" NAME=\"whattodo\" VALUE=\"tables\" CHECKED><BR>"
	  ."<B>Insert Data </B><INPUT TYPE=\"RADIO\" NAME=\"whattodo\" VALUE=\"data\"><BR>";
                if (checkAccess("accessadmin"))
                {
                  $output .= "<B>Rename Tables </B><INPUT TYPE=\"RADIO\" NAME=\"whattodo\" VALUE=\"rename\"><BR>"
		."<B>New Table Prefix </B><INPUT TYPE=\"TEXT\" NAME=\"whattorenameto\"><BR>"
		."<SPAN CLASS='InputNotes'>Only Admins Can See The Rename Radio Button.<BR>"
		."Make Sure To Change The settings.php File After The Tables Are Renamed.</SPAN><BR>";
                }
  $output .= inputSubmit("Process Query")
                ."</FORM>\n";
     }
   }
   
   $output = "<B>DiscoBoard Database Setup</B>\n"
            ."<P>\n"
            .$status
            .$output;
            
   $pagecontents = $output;
   include("layout.php");
?>