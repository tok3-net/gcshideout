<?php
   // This is the default DiscoBoard theme. It's modelled loosely on the
   // look and feel of IGNBoards http://boards.ign.com.
   
   $bodycolor      = "white";
   $bodybackground = "";
   $pagetitle      = "GC Boards";
   if ($pageareatitle)
   {
     $pagetitle = $pagetitle." | ".$pageareatitle;
   }

   if ($bodybackground)
   {
     $bodybackgroundtag = " BACKGROUND='$bodybackground'";
   }
   
   // Final definition of page layout conditions...
if((!$userdata['stylesheet']) || ($userdata['stylesheet'] == "NULL"))
{
   $css = "default.php";
}
else
{
   $css = $userdata['stylesheet'];
   // Stored stylesheet preferences have historically been saved without
   // a .php extension in some places -- the <LINK> tag needs the real
   // filename or the request 404s/redirects and the user silently gets
   // no stylesheet at all.
   if (substr($css, -4) !== ".php")
   {
     $css .= ".php";
   }
}
$pagetop = ""
             ."<HTML>\n"
             ."<HEAD>\n"
             ." <TITLE> $pagetitle </TITLE>\n"
	."<meta name='keywords' content='discoboard, mods, hacks, modifications, game, cheater, gc, boards, sb, switchblade, switch, blade'>"
	."<meta name='description' content='GC Boards | A Very Modded Version Of DiscoBoard available for download at http://www.sbdesigning.com or you can visit the boards at http://boards.sbdesigning.com'>"
             ." <LINK REL='STYLESHEET' HREF='".$DBRoot."/stylesheets/".$css."' TYPE='text/css'>\n"
             ."<STYLE TYPE=\"text/css\">\n"
             .".Image{\n"
             ."background: url(gfx/GC-Boards-Back.gif);\n"
             ."}\n"
             .".back{\n"
             ."position:absolute;\n"
             ."width:150px;\n"
             ."border:1px solid #ACA899;\n"
             ."background-color:#FFFFFF;\n"
             ."font-family:Verdana;\n"
             ."line-height:15px;\n"
             ."font-size:10px;\n"
             ."z-index:100;\n"
             ."visibility:hidden;\n"
             ."}\n"
             .".options{\n"
             ."padding-left:20px;\n"
             ."padding-right:20px;\n"
             ."color:#000000;\n"
             ."}\n"
             .".options2{\n"
             ."padding-left:20px;\n"
             ."padding-right:20px;\n"
             ."color:#aca899;\n"
             ."}\n"
             ."</STYLE>\n";
if ($userdata['rcmenu'] && $functionset != "admin")
{
$pagetop .= "<div id=\"rcmenu\" class=\"back\" onMouseover=\"highlight(event)\" onMouseout=\"dehighlight(event)\" onClick=\"linkify(event)\" display:none>"
             ."<div class=\"options\" url=\"http://www.sbdesigning.com\">SB Designing</div>"
             ."<div class=\"options\" url=\"http://boards.sbdesigning.com\">SB Boards</div>"
             ."<div class=\"options\" url=\"http://www.sbdesigning.com/irc/\">Chats</div>"
             ."<div class=\"options\" url=\"javascript:window.location.reload();\">Refresh Page</div>"
             ."<hr width='95%'>";
global $AllowShop;
if (checkAccess("accessvip"))
{
  $pagetop .= "<div class=\"options\" url=\"admin/\">Admin Panel</div>";
}
else
{
  $pagetop .= "<div class=\"options2\">Admin Panel</div>";
}
$pagetop .= ""
             ."<div class=\"options\" url=\"activetopics.php\">Active Topics</div>"
             ."<div class=\"options\" url=\"help/\">Help</div>"
             ."<div class=\"options\" url=\"memberlist.php\">Member List</div>"
             ."<div class=\"options\" url=\"memberupdate.php\">Member Update</div>";
if ($AllowShop)
{
$pagetop .= "<div class=\"options\" url=\"shop.php\">Shop</div>";
}
$pagetop .= "<div class=\"options\" url=\"staff.php\">Staff List</div>"
             ."<div class=\"options\" url=\"tos.php\">TOS</div>"
             ."<div class=\"options\" url=\"usersonline.php\">Users Online</div>"
             ."</div>"
             ."<script type='text/javascript' src='elements/rcmenu.js'></script>";
}
$pagetop .= $javascriptlink
             ."</HEAD>\n"
             ."<BODY MARGINWIDTH=\"0\" MARGINHEIGHT=\"0\" LEFTMARGIN=\"0\" TOPMARGIN=\"0\" \n"
             ."      BGCOLOR='".$bodycolor."' ".$bodybackgroundtag." \n"
             ."      TEXT='black' LINK='blue' VLINK='blue' ALINK='red'>\n";
	if ($functionset == "admin")
	{
$pagetop .= "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<SPAN CLASS='MainMenuLink' STYLE='font-weight:none;'>[header disabled for admin pages]</SPAN><br>";
	}
	else
	{
$pagetop .= "";
	}
$pagetop .= "<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" style=\"margin: 0px; padding: 0px;\">\n"
	."<tr>\n"
	."<td align=\"left\" style=\"background-color:#CCCCCC;\" valign=\"top\" nowrap><a href=\"http://www.sbdesigning.com\" target=\"_new\"><img src=\"".$GFXRoot."/mylogo.gif\" alt=\"GC Boards\" border=\"0\"></a></td>\n"
	."<td width=\"100%\" style=\"background-color:#CCCCCC;\" valign=\"top\" style=\"background:url(".$GFXRoot."/bg.gif);\"><img src=\"".$GFXRoot."/bg.gif\" border=\"0\" width=\"100%\" height=\"55\" alt=\"\"></td>\n"
	."<td align=\"right\" style=\"background-color:#CCCCCC;\" valign=\"top\" nowrap><a href=\"javascript:history.go(-1);\"><img src=\"".$GFXRoot."/back.gif\" alt=\"\" border=\"0\"></a></td>\n"
	."</tr>\n"
	."</table>\n"
             ."<TABLE WIDTH=\"100%\" ALIGN=CENTER CELLPADDING=0 CELLSPACING=0 BORDER=0>\n"
             ."<TR><TD WIDTH=10 style=\"background-color:#CCCCCC;\"><IMG SRC='$GFXRoot/blank.gif' WIDTH=10 HEIGHT=10 ALT=''></TD>\n"
             ."<TD WIDTH=\"100%\" CLASS='MainTable'>\n"
             .""
             .$pageformstart
             .$navigationrow
             .$menurow
             .$areaoptionsrow
             .$messagerow
             .$centerrow
	.$quicklogin
             ."";
   $pagegentime = array_sum(explode(' ',microtime())) - $starttime;
   $pagegentime = round($pagegentime, 6);
   $pageend = $centerrow
             .$bottommessagerow
             .$navigationrow
             ."<TABLE WIDTH=\"100%\" CELLPADDING=1 CELLSPACING=1 BORDER=0 class=\"MainTable\"><TR>\n"
             ."<TD CLASS='VersionText' WIDTH=\"33%\">Current Time: ".dateNeat(Date("U"))."</TD>\n"
             ."<TD ALIGN=RIGHT CLASS='VersionText' WIDTH=\"33%\"><CENTER>Page Generation Time: ".$pagegentime."</CENTER></TD>\n"
             ."<TD ALIGN=RIGHT CLASS='VersionText' WIDTH=\"33%\">&copy; ".Date("Y")." GC Boards(v".$DBVersion."), Based On DiscoBoard</TD>\n"
             ."</TR></TABLE></TD>\n"
             ."<TD WIDTH=10 style=\"background-color:#CCCCCC;\"><IMG SRC='$GFXRoot/blank.gif' WIDTH=\"10\" HEIGHT=10 ALT=''></TD>\n"
             ."</TR>\n"
	."<tr>\n"
	."<td width=\"10\" align=\"left\" style=\"background-color:#CCCCCC;\"><img src=\"".$GFXRoot."/lowerleftcorner.gif\" width=\"10\" height=\"10\" alt=\"\" border=\"0\"></td>\n"
	."<td width=\"100%\" align=\"center\" style=\"background-color:#CCCCCC;\"><img src=\"".$GFXRoot."/blank.gif\" border=\"0\" alt=\"\" width=\"10\" height=\"10\"></td>\n"
	."<td width=\"10\" align=\"right\" style=\"background-color:#CCCCCC;\"><img src=\"".$GFXRoot."/lowerrightcorner.gif\" width=\"10\" height=\"10\" alt=\"\" border=\"0\"></td>\n"
	."</tr>\n"
             ."</TABLE><BR>\n"
             .$pageformstop;
if ($functionset == "admin")
{
$pageend .= "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<SPAN CLASS='MainMenuLink' STYLE='font-weight:none;'>[footer disabled for admin pages]</SPAN>";
}
else
{
$pageend .= '';
}
$pageend .= "</BODY>\n"
             ."</HTML>\n";
?>
