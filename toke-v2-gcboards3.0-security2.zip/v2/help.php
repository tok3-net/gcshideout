<?php
   $starttime = microtime();
   include("common.php");
   $navigation[] = array("name" => "Help",
                         "url"  => $PHP_SELF);
if (!$action) { $action = 'intro'; }

   $markupexample[] = array("[b]Bold Text[/b]");
   $markupexample[] = array("[i]Italic Text[/i]");
   $markupexample[] = array("[u]Underlined Text[/u]");
   $markupexample[] = array("[o]Overlined Text[/o]");
   $markupexample[] = array("[strike]Struck-Through Text[/strike]");
   $markupexample[] = array("[center]Centered Text[/center]");
   $markupexample[] = array("[blink]Blinking Text! (Doesn't Work In IE)[/blink]");
   $markupexample[] = array("[bq]Blockquoted Text[/bq]");
   $markupexample[] = array("[spaces]Text   With   All    Spaces Shown Between Words[/spaces]");
   $markupexample[] = array("[quote]Quoted Text[/quote]");
   $markupexample[] = array("[spoiler]Spoiler Text[/spoiler]");
   $markupexample[] = array("[move]Text That Moves[/move]");
   $markupexample[] = array("[hr] (Horizontal Rule)");
   $markupexample[] = array("[ul][li]Unordered List[li]Unordered List[/ul]");
   $markupexample[] = array("[ol][li]Ordered List[li]Ordered List[/ul]");
   $markupexample[] = array("[color=red]Red Text[/color]");
   $markupexample[] = array("[hl=yellow]Yellow Highlight[/hl]");
   $markupexample[] = array("[ucol=Username]Usernames Colors[/ucol]");
   $markupexample[] = array("[left-border=lime]Lime Left Border[/left-border]");
   $markupexample[] = array("[right-border=navy]Navy Right Border[/right-border]");
   $markupexample[] = array("[top-border=brown]Brown Top Border[/top-border]");
   $markupexample[] = array("[bottom-border=orange]Orange Bottom Border[/bottom-border]");
   $markupexample[] = array("[border=green]Green Border[/border]");
   $markupexample[] = array("[dashedborder=blue]Blue Dashed Border[/dashedborder]");
   $markupexample[] = array("[me] Does Something IRC-Style");
   $markupexample[] = array("[you] Does Something IRC-Style");
   $markupexample[] = array("[link=http://www.sbdesigning.com/]SB Designing![/link]");
   $markupexample[] = array("[image=http://www.sbdesigning.com/images/GCs-Hideout.gif]");
   $markupexample[] = array("[fimage=http://www.sbdesigning.com/images/GCs-Hideout.gif]");
   $markupexample[] = array("[icon=http://www.sbdesigning.com/images/tediz.jpg]");
if (checkAccess("accessvip"))
{
$markupexample[] = array("[vip]VIP Only Text[/vip]");
}
   
   for ($i = 0; $i < count($markupexample); $i++ )
   {
     $markuprow .= "<TR VALIGN=BASELINE>\n"
                  ."    <TD STYLE='font-size: 8pt;'>".$markupexample[$i][0]."</TD>\n"
                  ."    <TD>=</TD>\n"
                  ."    <TD>".bodyText($markupexample[$i][0], "(Insert-Username-Here)")."</TD></TR>\n";
   }
   $markupexamples = "<TABLE CELLPADDING=4 CELLSPACING=1 BORDER=0>\n"
                    ."<TR><TD COLSPAN=2 CLASS='BoardRowHeading'>Markup</TD>\n"
                    ."    <TD CLASS='BoardRowHeading'>Output</TD></TR>\n"
                    .$markuprow
                    ."</TABLE>\n";
   
   // Show the smiley list as currently configured
   foreach ($configoptions['emoticons'] as $key => $value)
   {
     $facerow .= "<TR VALIGN=BASELINE>\n"
                  ."    <TD STYLE='font-size: 8pt;'>".$value['code']." or [face_".$value['name']."]</TD>\n"
                  ."    <TD>=</TD>\n"
                  ."    <TD>".bodyText("[face_".$value['name']."]")."</TD></TR>\n";
   }
   $faceexamples = "<TABLE CELLPADDING=4 CELLSPACING=1 BORDER=0>\n"
                  ."<TR><TD COLSPAN=2 CLASS='BoardRowHeading'>Code</TD>\n"
                  ."    <TD CLASS='BoardRowHeading'>Output</TD></TR>\n"
                  .$facerow
                  ."</TABLE>\n";

// ------------------------------
// Actions And Output
// ------------------------------

if ($action == "intro")
{
      $starttime = microtime();
     $output = ""
            ."<P>\n"
            ."<B>GCs Hideout Board Introduction</B>\n"
            ."<P>\n"
            ."GC Boards is a highly modified version of DiscoBoards.  DiscoBoards is a board system made by Discosis "
	."which was made to replicate IGN's board system.  These boards have many markup codes and "
	."emoticons.  If you are not sure what those are you can check out those links to the left "
	."in the Help Menu.  Basically everything you need to know is in the Help Menu.  If there "
	."is something you are un-sure of you can always contact one of the higher ups on the boards "
	."(Administrators, Managers, Moderators, VIPs, etc...) and they should be able to help you, "
	."or you can post a topic on what you need help with in the board that it corresponds with.";
}

if ($action == "markup")
{
   $starttime = microtime();   
     $output = ""
            ."<P>\n"
            ."<B>Markup Codes</B>\n"
            ."<P>\n"
            ."GC Boards supports the following markup codes:\n"
            ."<P>\n"
            .$markupexamples
            ."<P>\n";
}

if ($action == "emoticon")
{
   $starttime = microtime();   
     $output = ""
            ."<P>\n"
            ."<B>Emoticons</B>\n"
            ."<P>\n"
            ." With GC Boards you can use the following emoticons:\n"
            ."<P>\n"
            .$faceexamples
            ."<P>\n";

}

if ($action == "defboard")
{
   $starttime = microtime();   
     $output = ""
            ."A board is a bunch of topics usually all related by a certain category.  Boards are usually "
			."grouped in Categories.  Boards are also sometimes referred to as Forums.";
}

if ($action == "defcategory")
{
   $starttime = microtime();   
     $output = ""
            ."A category has no posts it is just a menu bar above a bunch of boards that tells a user what "
			."type of topics would be in the boards below.  The Board names will also tell the user what kind "
			."of topics to expect in the Board";
}

if ($action == "definsider")
{
   $starttime = microtime();   
     $output = ""
            	."An Insider is a member who has access to boards that normal members can't even see."
	."  Insider boards have the insider symbol before their name (<IMG SRC='gfx/insider.gif' BORDER='0' ALT='Insider'>"
	.").";
}

if ($action == "deflockedboard")
{
   $starttime = microtime();   
     $output = ""
            	."A &quot;Locked Board&quot; is pretty much the same as any other board, except that only VIP+ can post topics/polls "
	."and reply to topics/polls in these boards.  A &quot;Locked Board&quot; is mainly used for an Announcement Board or other "
	."things similar to it.";
}

if ($action == "defpoll")
{
   $starttime = microtime();   
     $output = ""
            ."A poll can be made by a user in a Board, and it asks users who visit the poll a question of the "
			."poll author's choice.  The user will be able to choose from a list of options of how they would like "
			."to answer the question.";
}

if ($action == "defprivatemessage")
{
   $starttime = microtime();   
     $output = ""
            ."A private message or PM for short is like an email to another user.  Users on GCs Hideout Boards "
			."can use this to chat with other users.  You will be notified of new Private Messages up in the main "
			."link bar beside Private Message.  If you have say 2 Unread Private Messages istead of saying Private "
			."Message in the main link bar it will say Private Message - 2 New, as soon as you read the private "
			."message it will not be counted as new anymore.";
}

if ($action == "defreply")
{
   $starttime = microtime();  
     $output = ""
            ."A reply is just a message left by a user in a topic.  A reply will usually say the users views "
			."on the topic.  A reply is also known as a post";
}

if ($action == "defsignature")
{
    $starttime = microtime();  
     $output = ""
            ."A users signature can be set in the Edit Your Profile option of the Options link.  Your signature "
			."gets displayed at the bottom of every Post or Reply you make.";
}

if ($action == "deftopic")
{
      $starttime = microtime();
     $output = ""
            ."A topic is usually based on one thing and is there for users to post their replies on that one "
			."thing.  Topics can be used as discussions on whatever the user feels like.";
}
if ($action == "defuser")
{
   $starttime = microtime();   
     $output = ""
            ."A user is anyone who registers on the site and posts messages.";
}

if ($action == "login")
{
   $starttime = microtime();   
     $output = ""
            ."In order to login you have to have registered.  If you haven't registered yet click on the Register "
			."link in the main menu.  If you have just registered it will send a random password to your email "
			."address.  If you want to change your password after check out the Changing Password help topic.  Then "
			."to login click on the Login link in the main menu bar.";
}

if ($action == "stars")
{
    $starttime = microtime();  
     $output = ""
	."<TABLE BORDER=1 WIDTH=100%>"
	."<TR>"
	."<TD CLASS='BoardRowBody'><B>Star System #</B></TD><TD CLASS='BoardRowBody'><B>Star 1</B></TD>"
	."<TD CLASS='BoardRowBody'><B>Star 2</B></TD><TD CLASS='BoardRowBody'><B>Star 3</B></TD>"
	."<TD CLASS='BoardRowBody'><B>Star 4</B></TD><TD CLASS='BoardRowBody'><B>Star 5</B></TD>"
	."<TD CLASS='BoardRowBody'><B>Star 6</B></TD><TD CLASS='BoardRowBody'><B>Star 7</B></TD>"
	."<TD CLASS='BoardRowBody'><B>Star 8</B></TD><TD CLASS='BoardRowBody'><B>Star 9</B></TD>"
	."<TD CLASS='BoardRowBody'><B>Star 10</B></TD></TR>"
	."<TR>"
	."<TD CLASS='BoardRowBody'>1</TD>"
	."<TD CLASS='BoardRowBody'>"
            ."<img src='".$DBRoot."/gfx/stars/star1.gif' alt='".$PostLevel[1]." Posts'></TD>"
	."<TD CLASS='BoardRowBody'>"
            ."<img src='".$DBRoot."/gfx/stars/star2.gif' alt='".$PostLevel[2]." Posts'></TD>"
	."<TD CLASS='BoardRowBody'>"
            ."<img src='".$DBRoot."/gfx/stars/star3.gif' alt='".$PostLevel[3]." Posts'></TD>"
	."<TD CLASS='BoardRowBody'>"
            ."<img src='".$DBRoot."/gfx/stars/star4.gif' alt='".$PostLevel[4]." Posts'></TD>"
	."<TD CLASS='BoardRowBody'>"
            ."<img src='".$DBRoot."/gfx/stars/star5.gif' alt='".$PostLevel[5]." Posts'></TD>"
	."<TD CLASS='BoardRowBody'>"
            ."<img src='".$DBRoot."/gfx/stars/star6.gif' alt='".$PostLevel[6]." Posts'></TD>"
	."<TD CLASS='BoardRowBody'>"
            ."<img src='".$DBRoot."/gfx/stars/star7.gif' alt='".$PostLevel[7]." Posts'></TD>"
	."<TD CLASS='BoardRowBody'>"
            ."<img src='".$DBRoot."/gfx/stars/star8.gif' alt='".$PostLevel[8]." Posts'></TD>"
	."<TD CLASS='BoardRowBody'>"
            ."<img src='".$DBRoot."/gfx/stars/star9.gif' alt='".$PostLevel[9]." Posts'></TD>"
	."<TD CLASS='BoardRowBody'>"
            ."<img src='".$DBRoot."/gfx/stars/star10.gif' alt='".$PostLevel[10]." Posts'></TD></TR>"
	."<TR>"
	."<TD CLASS='BoardRowBody'>2</TD>"
	."<TD CLASS='BoardRowBody'>"
            ."<img src='".$DBRoot."/gfx/stars/IGN/star1.gif' alt='".$PostLevel[1]." Posts'></TD>"
	."<TD CLASS='BoardRowBody'>"
            ."<img src='".$DBRoot."/gfx/stars/IGN/star2.gif' alt='".$PostLevel[2]." Posts'></TD>"
	."<TD CLASS='BoardRowBody'>"
            ."<img src='".$DBRoot."/gfx/stars/IGN/star3.gif' alt='".$PostLevel[3]." Posts'></TD>"
	."<TD CLASS='BoardRowBody'>"
            ."<img src='".$DBRoot."/gfx/stars/IGN/star4.gif' alt='".$PostLevel[4]." Posts'></TD>"
	."<TD CLASS='BoardRowBody'>"
            ."<img src='".$DBRoot."/gfx/stars/IGN/star5.gif' alt='".$PostLevel[5]." Posts'></TD>"
	."<TD CLASS='BoardRowBody'>"
            ."<img src='".$DBRoot."/gfx/stars/IGN/star6.gif' alt='".$PostLevel[6]." Posts'></TD>"
	."<TD CLASS='BoardRowBody'>"
            ."<img src='".$DBRoot."/gfx/stars/IGN/star7.gif' alt='".$PostLevel[7]." Posts'></TD>"
	."<TD CLASS='BoardRowBody'>"
            ."<img src='".$DBRoot."/gfx/stars/IGN/star8.gif' alt='".$PostLevel[8]." Posts'></TD>"
	."<TD CLASS='BoardRowBody'>"
            ."<img src='".$DBRoot."/gfx/stars/IGN/star9.gif' alt='".$PostLevel[9]." Posts'></TD>"
	."<TD CLASS='BoardRowBody'>"
            ."<img src='".$DBRoot."/gfx/stars/IGN/star10.gif' alt='".$PostLevel[10]." Posts'></TD></TR>"
	."<TR>"
	."<TD CLASS='BoardRowBody'>3</TD>"
	."<TD CLASS='BoardRowBody'>"
            ."<img src='".$DBRoot."/gfx/stars/Red/star1.gif' alt='".$PostLevel[1]." Posts'></TD>"
	."<TD CLASS='BoardRowBody'>"
            ."<img src='".$DBRoot."/gfx/stars/Red/star2.gif' alt='".$PostLevel[2]." Posts'></TD>"
	."<TD CLASS='BoardRowBody'>"
            ."<img src='".$DBRoot."/gfx/stars/Red/star3.gif' alt='".$PostLevel[3]." Posts'></TD>"
	."<TD CLASS='BoardRowBody'>"
            ."<img src='".$DBRoot."/gfx/stars/Red/star4.gif' alt='".$PostLevel[4]." Posts'></TD>"
	."<TD CLASS='BoardRowBody'>"
            ."<img src='".$DBRoot."/gfx/stars/Red/star5.gif' alt='".$PostLevel[5]." Posts'></TD>"
	."<TD CLASS='BoardRowBody'>"
            ."<img src='".$DBRoot."/gfx/stars/Red/star6.gif' alt='".$PostLevel[6]." Posts'></TD>"
	."<TD CLASS='BoardRowBody'>"
            ."<img src='".$DBRoot."/gfx/stars/Red/star7.gif' alt='".$PostLevel[7]." Posts'></TD>"
	."<TD CLASS='BoardRowBody'>"
            ."<img src='".$DBRoot."/gfx/stars/Red/star8.gif' alt='".$PostLevel[8]." Posts'></TD>"
	."<TD CLASS='BoardRowBody'>"
            ."<img src='".$DBRoot."/gfx/stars/Red/star9.gif' alt='".$PostLevel[9]." Posts'></TD>"
	."<TD CLASS='BoardRowBody'>"
            ."<img src='".$DBRoot."/gfx/stars/Red/star10.gif' alt='".$PostLevel[10]." Posts'></TD></TR></TABLE>";
}

if ($action == "gcboards")
{
$output = "
	<CENTER><H1>GC Board Stats</H1></CENTER>
	GC Boards is a Modified DiscoBoard system that is gaining more and more features every released version.  The one good thing that 
	sets it apart from most other DiscoBoards is it is completely <B><U>FREE</U></B>.  Anyone can download <I>GC Boards</I> here:<BR><BR>
	<A HREF='http://www.sbdesigning.com/disco.php' TARGET='_new'>GC Boards Downloads</A><BR><BR>
	Or you can check out the original <I>GC Boards</I> here:<BR><BR>
	<A HREF='http://gcboards.sbdesigning.com' TARGET='_new'>Original GC Boards</A><BR><BR>
	<B><U>Features That Set GC Boards Apart From A Standard DiscoBoard Are:</U></B><BR>
	<UL><LI>VIP+ Only Boards
	<LI>Insider Only Boards
	<LI>Star System Chooser
	<LI>[Your Icon Here] Modification
	<LI>Page Generation Time
	<LI>Quick Login
	<LI>Stylesheet Chooser
	<LI>Profile Titles
	<LI>Staff List
	<LI>Boards Only VIP+ Can Post In
	<LI>Member List
	<LI>Admin Add User
	<LI>Admin Menu Reformatted
	<LI>Moderator Reply For Locked Topics
	<LI>TOS Main Menu Link
	<LI>Quick Reply
	<LI>Right Border Fixed
	<LI>Edit Post Count
	<LI>Ban User
	<LI>Unban User
	<LI>Admin Edit TOS
	<LI>Admin Edit Stylesheet
	<LI>On 404 Error System Message Displayed
	<LI>VIP+ Can Use Own Icons No Matter What
	<LI>Edit Own Title
	<LI>Stars Fixed So star1.gif Works
	<LI>Fully Functional Manager Access Class
	<LI>Fully Functional VIP Access Class
	<LI>Fully Functional Insider Access Class
	<LI>VIPs Have Access To Admin Panel
	<LI>Fake setup.php File
	<LI>Member Update
	<LI>Header Disabled For Admin Pages
	<LI>Shop
	<LI>UseOwnIcons Setting Allows Users Either To Upload Their Own Icon Or Not
	<LI>EditOwnTitles Setting Allows Users To Edit Their Own Title Or Not
	<LI>AlllowFileViewer Setting Will Either Turn File Viewer On Or Off
	<LI>AllowShop Setting Will Set Whether Or Not The Shop Is Available At Your Boards
	<LI>AllowSigMarkup Setting Will Either Allow Or Dis-Allow Markup Codes In Signatures
	<LI>Admin Action Log
	<LI>Topic Marker Looks Nicer
	<LI>Admin Files In An Admin Folder
	<LI>Managers Can Edit User Profiles
	<LI>Manage Stylesheets Through Admin Menu
	<LI>Managers Can Manage Insiders
	<LI>Administrators Can Mass Email Members
	<LI>Can Allow/Disallow Registrations
	<LI>Easy To Setup Database (setup-database.php No Longer NEEDS To Be Deleted)
	<LI>Every Topic Page Is No Longer Displayed If Over 5 Pages
	<LI>On Register Password Can Either Be Emailed Or Displayed Right There
	<LI>When A Moderator Deletes A Users Post You Can Set If Their Postcount Goes Down Or Not
	<LI>Moderators Can Synch A Users Postcount
	<LI>Moderators Can Remove All Of A Users Posts In A Matter Of 2 Seconds
	<LI>More Emoticons
	</UL>
	";
}

$menuoutput = "<table width=100% cellspacing=0 cellpadding=0 border=0>"
		  ."<tr valign='top'><td width=100% align=\"center\"><span class='InputSection' valign='top'><B>Help Menu</B></span></td></tr>"
		  ."<tr><td width=100%><hr width='100%'></td></tr>"
		  ."<tr><td width=100%><span class='InputNotes'><B>Main</B></span></td></tr>"
		  ."<tr><td width=100%>&nbsp;<a href='help.php?action=intro' class='BoardRowHeadingLink'>Introduction</a></td></tr><br>"
		  ."<tr><td width=100%>&nbsp;<a href='help.php?action=emoticon' class='BoardRowHeadingLink'>Emoticons</a></td></tr>"
		  ."<tr><td width=100%>&nbsp;<a href='help.php?action=gcboards' class='BoardRowHeadingLink'>GC&nbsp;Board&nbsp;Stats</a></td></tr>"
		  ."<tr><td width=100%>&nbsp;<a href='help.php?action=login' class='BoardRowHeadingLink'>Logging&nbsp;In</a></td></tr>"
		  ."<tr><td width=100%>&nbsp;<a href='help.php?action=markup' class='BoardRowHeadingLink'>Markup&nbsp;Codes</a></td></tr>"
		  ."<tr><td width=100%>&nbsp;<a href='help.php?action=stars' class='BoardRowHeadingLink'>Stars</a></td></tr>"
		  ."<tr><td width=100%><span class='InputNotes'><B>Definitions</B></span></td></tr>"
		  ."<tr><td width=100%>&nbsp;&nbsp;<a href='help.php?action=defboard' class='BoardRowHeadingLink'>Board</a></td></tr>"
		  ."<tr><td width=100%>&nbsp;&nbsp;<a href='help.php?action=defcategory' class='BoardRowHeadingLink'>Category</a></td></tr>"
		  ."<tr><td width=100%>&nbsp;&nbsp;<a href='help.php?action=definsider' class='BoardRowHeadingLink'>Insider</a></td></tr>"
		  ."<tr><td width=100%>&nbsp;&nbsp;<a href='help.php?action=deflockedboard' class='BoardRowHeadingLink'>Locked&nbsp;Board</a></td></tr>"
		  ."<tr><td width=100%>&nbsp;&nbsp;<a href='help.php?action=defpoll' class='BoardRowHeadingLink'>Poll</a></td></tr>"
		  ."<tr><td width=100%>&nbsp;&nbsp;<a href='help.php?action=defprivatemessage' class='BoardRowHeadingLink'>Private&nbsp;Message</a></td></tr>"
		  ."<tr><td width=100%>&nbsp;&nbsp;<a href='help.php?action=defreply' class='BoardRowHeadingLink'>Reply</a></td></tr>"
		  ."<tr><td width=100%>&nbsp;&nbsp;<a href='help.php?action=defsignature' class='BoardRowHeadingLink'>Signature</a></td></tr>"
		  ."<tr><td width=100%>&nbsp;&nbsp;<a href='help.php?action=deftopic' class='BoardRowHeadingLink'>Topic</a></td></tr>"
		  ."<tr><td width=100%>&nbsp;&nbsp;<a href='help.php?action=defuser' class='BoardRowHeadingLink'>User</a></td></tr>"
		  ."</table>";

     $output = "<TABLE WIDTH=\"100%\" CELLPADDING=\"3\" CELLSPACING=\"1\" BORDER=\"0\">"
	."<TR>\n"
	."<td class=\"BoardRowHeading\" valign=\"top\" nowrap>\n"
	.$menuoutput
	."</td>\n"
	."<TD CLASS=\"BoardRowBody\" width=\"100%\" valign=\"top\">"
	.$output
	."</TD></TR></TABLE>";


   $pagecontents = $output;
   include("layout.php");
?>