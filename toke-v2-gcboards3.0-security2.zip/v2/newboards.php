<?php
   $starttime = microtime();
   include("common.php");
   
   $navigationhead = "New Boards";

$sql = "SELECT b.ID, b.description, b.private, g.groupname, b.postidlast, b.boardname, b.groupid FROM ".TABLE_BOARDS." b, ".TABLE_GROUPS." g ORDER BY ID DESC LIMIT 20";
$exe = runQuery($sql);

$output = "<TABLE BORDER=\"1\" CLASS='BoardRowBody'  WIDTH=100% style=\"border-collapse: collapse;\">
	<TR><TD CLASS='BoardColumn'>Board</TD>
	<TD CLASS='BoardColumn'>Category</TD>
	<TD CLASS='BoardColumn'>Description</TD></TR>";

while ($row = fetchResultArray($exe))
{
   $groupid = $row['groupid'];
   $hasAccess = checkBoardAccess($row['ID']);
if ((!$row['private']) || ($row['private'] == "1" && checkAccess("accessvip")) || ($row['private'] == "2" && checkAccess("accessinsider")) || $hasAccess)
{
$output .= "<TR>
	<TD CLASS='BoardRowBody' WIDTH=20%><A HREF='board.php?boardid=".$row['ID']."&lastpostid=".$row['postidlast']."'>".$row['boardname']."</A></TD>
	<TD CLASS='BoardRowBody' WIDTH=15%>".$row['groupname']."</TD>
	<TD CLASS='BoardRowBody' WIDTH=65%>".$row['description']."</TD></TR>\n";
}
else
{
$output .= "<TR><TD CLASS='BoardRowBody' COLSPAN=3><B># # # Private Board # # #</B></TD></TR>\n";
}
}

   $output .= "</TABLE>";
   
   $pagecontents = $output;
   include("layout.php");
?>