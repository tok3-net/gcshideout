<?php
	$starttime = microtime();
   	include("common.php");
	include("functions.iconview.php");

	$sql = "SELECT ID, filename, data, groupid, lastmod, mimetype FROM ".TABLE_ICONS;
	$exe = runQuery($sql);

	$output = '<table border="0" width="100%" cellspacing="1" cellpadding="20">'
		.'<tr>'
		.'<td width="100%" class="BoardRowBody">';
	while ($iconinfo = fetchResultArray($exe))
	{
		$filename = $iconinfo['filename'];
		$filename = rand(1000000, 9999999).preg_replace('#'.("([^a-zA-Z0-9\_\.\-])").'#', "", $filename);

		$icondata = base64ToFile($iconinfo['data']);
   
		$out = fopen("gfx/icons/".$filename, "w+");
		fwrite($out, $icondata);
		fclose($out);
		chmod("gfx/icons/".$filename, 0755);
		$output .= "<b>Icon ID #".$iconinfo['ID']."</b>... ".$filename."<br>";

		$sql_update = "UPDATE ".TABLE_ICONS." SET data = '{$filename}' WHERE ID = '{$iconinfo['ID']}' LIMIT 1";
		runQuery($sql_update);
	}
	$output .= '<p><span class="InputNotes"><b>The icon conversion is now complete!</b></span></td></tr></table>';

	$pagecontents = $output;
	include("layout.php");
?>