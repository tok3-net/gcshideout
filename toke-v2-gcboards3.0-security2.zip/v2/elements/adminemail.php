<?php
$editemailsform = "
    <table>
      <tr>
        <td class=\"BoardRowB\" valign=\"top\">
          <span class=\"InputSection\">System Email:</span><br/>
          <span class=\"InputNotes\">Required Input</span><br/>
          ".inputTextarea("systememails", $systememails, 50, 20)."
        </td>
        <td class=\"BoardRowB\" valign=\"top\">
          <br/>
          <br/>

        </td>
      </tr>
      <tr>
        <td align=\"center\" class=\"BoardRowB\">
          ".inputSubmit("Update System Email")."
        </td>
        <td>
          &nbsp;
        </td>
      </tr>
    </table>
";

?>