var main=document.all&&document.getElementById
var main2=document.getElementById&&!document.all
if (main||main2)
var menu=document.getElementById("rcmenu")

function menuappear(e)
{
  var horizontal=main? document.body.clientWidth-event.clientX : window.innerWidth-e.clientX
  var vertical=main? document.body.clientHeight-event.clientY : window.innerHeight-e.clientY
  if (horizontal<menu.offsetWidth)
  menu.style.left=main? document.body.scrollLeft+event.clientX-menu.offsetWidth : window.pageXOffset+e.clientX-menu.offsetWidth
  else
  menu.style.left=main? document.body.scrollLeft+event.clientX : window.pageXOffset+e.clientX
  if (vertical<menu.offsetHeight)
  menu.style.top=main? document.body.scrollTop+event.clientY-menu.offsetHeight : window.pageYOffset+e.clientY-menu.offsetHeight
  else
  menu.style.top=main? document.body.scrollTop+event.clientY : window.pageYOffset+e.clientY
  menu.style.visibility="visible"
  return false
}

function menudissapear(e)
{
  menu.style.visibility="hidden"
}

function highlight(e)
{
  var lightup=main? event.srcElement : e.target
  if (lightup.className=="options"||main2&&lightup.parentNode.className=="options")
  {
    if (main2&&lightup.parentNode.className=="options") lightup=lightup.parentNode
    lightup.style.backgroundColor="#316AC5"
    lightup.style.color="#FFFFFF"
  }
  if (lightup.className=="options2"||main2&&lightup.parentNode.className=="options2")
  {
    if (main2&&lightup.parentNode.className=="options2") lightup=lightup.parentNode
    lightup.style.backgroundColor="#316AC5"
    lightup.style.color="#aca899"
  }
}

function dehighlight(e)
{
  var lightup=main? event.srcElement : e.target
  if (lightup.className=="options"||main2&&lightup.parentNode.className=="options")
  {
    if (main2&&lightup.parentNode.className=="options") lightup=lightup.parentNode
    lightup.style.backgroundColor="transparent"
    lightup.style.color=""
  }
  if (lightup.className=="options2"||main2&&lightup.parentNode.className=="options2")
  {
    if (main2&&lightup.parentNode.className=="options2") lightup=lightup.parentNode
    lightup.style.backgroundColor="transparent"
    lightup.style.color=""
  }
}

function linkify(e)
{
  var lightup=main? event.srcElement : e.target
  if (lightup.className=="options"||main2&&lightup.parentNode.className=="options")
  {
    if (main2&&lightup.parentNode.className=="options") lightup=lightup.parentNode
    if (lightup.getAttribute("target"))
    window.open(lightup.getAttribute("url"),lightup.getAttribute("target"))
    else
    window.location=lightup.getAttribute("url")
  }
}

if (main||main2)
{
  menu.style.display=''
  document.oncontextmenu=menuappear
  document.onclick=menudissapear
}