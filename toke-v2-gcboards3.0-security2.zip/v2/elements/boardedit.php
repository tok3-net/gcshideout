<?php
if ($boardvippost == "1"){ 
$bvippost = "True"; 
$vipselect = "SELECTED";
}else{ 
$bvippost = "False"; 
}
if ($boardprivate == "1"){ 
$bprivate = "VIP+"; 
$poselect = "SELECTED";
}elseif ($boardprivate == "2"){ 
$bprivate = "Insider"; 
$ptselect = "SELECTED";
}else{ 
$bprivate = "False"; 
}
if (!$boardprivateusers){ $bprivateusers = "None"; }

$boardform = "
<SPAN CLASS='InputSection'>Current Settings</SPAN><BR>
<TABLE>
<TR><TD CLASS='BoardColumn'>Board ID</TD>    <TD>".$boardid."</TD></TR>
<TR><TD CLASS='BoardColumn'>Name</TD>        <TD>".$boardname."</TD></TR>
<TR><TD CLASS='BoardColumn'>Description</TD> <TD>".$boarddescription."</TD></TR>
<TR><TD CLASS='BoardColumn'>Rank</TD>        <TD>".$boardrank."</TD></TR>
<TR><TD CLASS='BoardColumn'>Group</TD>       <TD>".inputDBCycle("", $boardgroupid, TABLE_GROUPS, "ID", "groupname", "show", "grouprank")."</TD></TR>
<TR><TD CLASS='BoardColumn'>VIP+ Only Post</TD> <TD>".$bvippost."</TD></TR>
<TR><TD CLASS='BoardColumn'>Private Board</TD> <TD>".$bprivate."</TD></TR>
<TR><TD CLASS='BoardColumn'>Invited Users</TD> <TD>".$bprivateusers."</TD></TR>
</TABLE>
<P>
<TABLE>
<TR><TD WIDTH='50%' CLASS='BoardRowHeading'>Description</TD>
<TD WIDTH='50%' CLASS='BoardRowHeading'>Permissions</TD></TR>
<TR><TD WIDTH='50%'>
<SPAN CLASS='InputSection'>Board Name</SPAN><BR>
".inputText("boardname", $boardname, 30)."<BR>
<SPAN CLASS='InputSection'>Board Description</SPAN><BR>
".inputText("boarddescription", $boarddescription, 30)."<BR>
<SPAN CLASS='InputSection'>Board Rank</SPAN><BR>
".inputText("boardrank", $boardrank, 3, 1)."<BR>
<SPAN CLASS='InputSection'>Group</SPAN><BR>
".inputDBCycle("boardgroupid", $boardgroupid, TABLE_GROUPS, "ID", "groupname", "edit", "grouprank")."
</TD>
<TD WIDTH='50%'>
<SPAN CLASS='InputSection'>Board Post Limits</SPAN><BR>
<SELECT NAME='boardvippost'>
<OPTION VALUE='0'>No Limits</OPTION>
<OPTION VALUE='1'  ".$vipselect.">VIP+ Only</OPTION>
</SELECT>
<BR>
<SPAN CLASS='InputSection'>Board Private</SPAN><BR>
<SELECT NAME='boardprivate'>
<OPTION VALUE='0'>No</OPTION>
<OPTION VALUE='2' ".$ptselect.">Insider</OPTION>
<OPTION VALUE='1' ".$poselect.">VIP+</OPTION>
</SELECT><BR>
<SPAN CLASS='InputSection'>User's With Access</SPAN><BR><SPAN CLASS='red'>
If &quot;Board Private&quot; is set to Insider or VIP+, you can give users not in those Access Classes access to the boards 
by inputting their user ID in the box below.<BR>
ex. 1,5,18,32</SPAN><BR>
<INPUT TYPE='TEXT' NAME='boardprivateusers' VALUE='".$boardprivateusers."'><BR>
</TD></TR>
</TABLE>
<P>";
?>
