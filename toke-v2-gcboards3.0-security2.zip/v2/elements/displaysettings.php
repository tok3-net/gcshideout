<?php
$displaysettingsform = "
<SPAN CLASS='InputSection'>Posts Per Page</SPAN><BR>
Controls the maximum number of posts you will see on a page at a time when 
viewing a thread.<BR>
".inputChoice("perpage", "perpageposts", $userinfo['perpageposts'])."
<P>
<SPAN CLASS='InputSection'>Threads Per Page</SPAN><BR>
Controls the number of threads you will see on a page at a time when viewing
the threads posted on a board.<BR>
".inputChoice("perpage", "perpagethreads", $userinfo['perpagethreads'])."
<P>
<SPAN CLASS='InputSection'>Timezone Settings</SPAN><BR>
The current system time is <I>".Date("d M Y H:i:s")."</I><BR>
Your configuration shows the current time as <I>".dateNeat(Date("U"), "datetime")."</I><BR>
Select the number of hours offset required to change this to your local time.<BR>
<I>Default setting is currently <U>".$TimeZoneChange."</U></I><BR>
".inputTimeZoneSelect("timezone", $userinfo['timezone'])."<p>

<SPAN CLASS='InputSection'>Board Stylesheet</SPAN><BR>
Choose the stylesheet you would like to view the board with.<BR>
<SELECT NAME='stylesheet'>";
	$sql = "SELECT * FROM ".TABLE_STYLESHEETS." ORDER BY name ASC";
	$exe = runQuery($sql);
	while ($row = fetchResultArray($exe))
	{
	  if ($userdata['stylesheet'] == $row['filename']) { $selected = " SELECTED"; }
	  else { $selected = ""; }
	  $displaysettingsform .= "<OPTION VALUE='".$row['filename']."'".$selected.">".$row['name']."</OPTION>";
	}
$displaysettingsform .= "</SELECT>
<P>

<SPAN CLASS='InputSection'>Choose A Star System</SPAN><BR>
Choose the star system you would like to use.<BR>
<INPUT TYPE='RADIO' NAME='starsystem' VALUE='1'".$selectone.">
<img src='".$GFXRoot."/stars/star1.gif'><img src='".$GFXRoot."/stars/star2.gif'><img src='".$GFXRoot."/stars/star3.gif'>
<img src='".$GFXRoot."/stars/star4.gif'><img src='".$GFXRoot."/stars/star5.gif'><img src='".$GFXRoot."/stars/star6.gif'>
<img src='".$GFXRoot."/stars/star7.gif'><img src='".$GFXRoot."/stars/star8.gif'><img src='".$GFXRoot."/stars/star9.gif'>
<img src='".$GFXRoot."/stars/star10.gif'><BR>
<INPUT TYPE='RADIO' NAME='starsystem' VALUE='2'".$selecttwo.">
<img src='".$GFXRoot."/stars/IGN/star1.gif'><img src='".$GFXRoot."/stars/IGN/star2.gif'><img src='".$GFXRoot."/stars/IGN/star3.gif'>
<img src='".$GFXRoot."/stars/IGN/star4.gif'><img src='".$GFXRoot."/stars/IGN/star5.gif'><img src='".$GFXRoot."/stars/IGN/star6.gif'>
<img src='".$GFXRoot."/stars/IGN/star7.gif'><img src='".$GFXRoot."/stars/IGN/star8.gif'><img src='".$GFXRoot."/stars/IGN/star9.gif'>
<img src='".$GFXRoot."/stars/IGN/star10.gif'><BR>
<INPUT TYPE='RADIO' NAME='starsystem' VALUE='3'".$selectthree.">
<img src='".$GFXRoot."/stars/Red/star1.gif'><img src='".$GFXRoot."/stars/Red/star2.gif'><img src='".$GFXRoot."/stars/Red/star3.gif'>
<img src='".$GFXRoot."/stars/Red/star4.gif'><img src='".$GFXRoot."/stars/Red/star5.gif'><img src='".$GFXRoot."/stars/Red/star6.gif'>
<img src='".$GFXRoot."/stars/Red/star7.gif'><img src='".$GFXRoot."/stars/Red/star8.gif'><img src='".$GFXRoot."/stars/Red/star9.gif'>
<img src='".$GFXRoot."/stars/Red/star10.gif'><br>
<INPUT TYPE='RADIO' NAME='starsystem' VALUE='4'".$selectfour.">
<img src='".$GFXRoot."/stars/Mix/star1.gif'><img src='".$GFXRoot."/stars/Mix/star2.gif'><img src='".$GFXRoot."/stars/Mix/star3.gif'>
<img src='".$GFXRoot."/stars/Mix/star4.gif'><img src='".$GFXRoot."/stars/Mix/star5.gif'><img src='".$GFXRoot."/stars/Mix/star6.gif'>
<img src='".$GFXRoot."/stars/Mix/star7.gif'><img src='".$GFXRoot."/stars/Mix/star8.gif'><img src='".$GFXRoot."/stars/Mix/star9.gif'>
<img src='".$GFXRoot."/stars/Mix/star10.gif'>
<P>

".inputCheckbox("rcmenu", 1, $userinfo['rcmenu'])."<span class=\"InputSection\">Right Click Menu</span> (check to enable)";
?>