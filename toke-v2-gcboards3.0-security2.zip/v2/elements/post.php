<?php
$postform = "
<SPAN CLASS='InputSection'>Subject</SPAN><BR>
".inputText("subject", $subject, 40)."
<P>
<SPAN CLASS='InputSection'>Body</SPAN><BR>
".inputTextArea("body", $body, 45, 15, "", "", "", "linewrapfix")."<BR>
<SPAN STYLE='font-size: 8pt;'>Check the <A HREF='help.php' TARGET='_blank'>Help Area</A> for supported Markup Codes</SPAN>
<P>
<SPAN STYLE='font-size: 8pt;'>Please read the <A HREF='tos.php'>Terms Of Service</A> before posting. By pressing the POST button 
below, you are agreeing to the <A HREF='tos.php'>TOS</A>.</SPAN>
<P>
";
?>