<style type="text/css">
A {
text-decoration: none;
}
A:hover {
text-decoration: underline;
}

BODY, TD {
font-family: arial, helvetica, sans-serif;
font-weight: normal;
font-size: 10pt;
color: black;
text-decoration: none;
}

.MainTable {
background-color: #436697;
font-family: arial, helvetica, sans-serif;
font-weight: normal;
font-size: 10pt;
color: black;
text-decoration: none;
}

.MainMenuRowAlt {
background-color: transparent;
font-family: tahoma,arial,sans-serif;
font-weight: bold;
font-size: 9pt;
color: yellow;
text-decoration: none;
}

.MainMenuRow {
background-color: #333366;
font-family: tahoma,arial,sans-serif;
font-weight: normal;
font-size: 9pt;
color: white;
text-decoration: none;
}

.MainMenuLink {
background-color: transparent;
font-family: tahoma,arial,sans-serif;
font-weight: bold;
font-size: 9pt;
color: white;
text-decoration: none;
}

.BoardColumn {
background-color: navy;
background: url(gc-boards-back.jpg);
font-family: verdana,arial,sans-serif;
font-weight: bold;
font-size: 10pt;
color: white;
text-decoration: none;
}

.BoardColumnLink {
background-color: transparent;
font-family: verdana,arial,sans-serif;
font-weight: bold;
font-size: 10pt;
color: white;
text-decoration: none;
}

.BoardRowA {
background-color: #b1b3bc;
font-family: verdana,arial,sans-serif;
font-weight: normal;
font-size: 10pt;
color: black;
text-decoration: none;
}

.BoardRowALink {
background-color: transparent;
font-family: verdana,arial,sans-serif;
font-weight: normal;
font-size: 10pt;
color: #000099;
text-decoration: none;
}

.BoardRowB {
background-color: #c1c3c9;
font-family: verdana,arial,sans-serif;
font-weight: normal;
font-size: 10pt;
color: black;
text-decoration: none;
}

.BoardRowBLink {
background-color: transparent;
font-family: verdana,arial,sans-serif;
font-weight: normal;
font-size: 10pt;
color: #000099;
text-decoration: none;
}

.SubjectLink {
background-color: transparent;
font-family: verdana,arial,sans-serif;
font-weight: bold;
font-size: 10pt;
color: #000099;
text-decoration: none;
}

a.SubjectLink {
background-color: transparent;
font-family: verdana,arial,sans-serif;
font-weight: bold;
font-size: 10pt;
color: #000099;
text-decoration: none;
}

a.SubjectLink:active {
background-color: transparent;
font-family: verdana,arial,sans-serif;
font-weight: bold;
font-size: 10pt;
color: #000099;
text-decoration: none;
}

a.SubjectLink:visited {
background-color: transparent;
font-family: verdana,arial,sans-serif;
font-weight: normal;
font-size: 10pt;
color: #000099;
text-decoration: none;
}

.AuthorLink {
background-color: transparent;
font-family: verdana,arial,sans-serif;
font-weight: bold;
color: #000099;
text-decoration: none;
}

.VersionText {
background-color: transparent;
font-family: verdana,arial,sans-serif;
font-weight: normal;
font-size: 8pt;
color: white;
text-decoration: none;
}

.InputSection {
background-color: transparent;
font-family: verdana,arial,sans-serif;
font-weight: bold;
font-size: 10pt;
color: black;
text-decoration: none;
}

.InputNotes {
background-color: transparent;
font-family: verdana,arial,sans-serif;
font-weight: normal;
font-size: 9pt;
color: maroon;
text-decoration: none;

width: 65%;
}

.SignatureTitle {
background-color: transparent;
font-family: verdana,arial,sans-serif;
font-weight: bold;
font-size: 9pt;
color: maroon;
text-decoration: none;
}

.SignatureText {
background-color: transparent;
font-family: verdana,arial,sans-serif;
font-weight: normal;
font-size: 9pt;
color: #333333;
text-decoration: none;
}

.AdminMenuLink {
background-color: transparent;
font-family: arial, helvetica, sans-serif;
font-size: 8pt;
color: white;
text-decoration: none;
}
.AdminMenuSection {
font-size: 10px; font-weight: bold; color: beige; text-decoration: underline;
}
</style>
