<style type="text/css">

.MainTable {
background-color: black ! important; font-family: arial, helvetica, sans-serif ! important; font-weight: normal ! important; font-size: 10pt ! important; color: #B22222 ! important; text-decoration: none ! important;  border: #8B0000 ! important; 
}
.MainMenuRowAlt {
background-color: #ADADAD ! important; font-family: arial, helvetica, sans-serif ! important; font-weight: bold ! important; font-size: 10pt ! important; color: #EEEE00 ! important; text-decoration: none ! important; 
}
.MainMenuRow {
background-color: #ADADAD ! important; border: 1px solid lightslateblue ! important; font-family: arial, helvetica, sans-serif ! important; font-weight: normal ! important; font-size: 10pt ! important; color: #B22222 ! important; text-decoration: none ! important; 
}
.MainMenuLink {
background-color: transparent ! important; font-family: arial, helvetica, sans-serif ! important; font-weight: bold ! important; font-size: 10pt ! important; color: #B22222 ! important; text-decoration: underline ! important; 
}
.BoardColumn {
background-color: #8B0000 ! important; font-family: arial, helvetica, sans-serif ! important; font-weight: bold ! important; font-size: 10pt ! important; color: #DCDCDC ! important; text-decoration: none ! important; 
}
.BoardColumnLink {
background-color: transparent ! important; font-family: arial, helvetica, sans-serif ! important; font-weight: bold ! important; font-size: 10pt ! important; color: #DCDCDC ! important; text-decoration: underline ! important; 
}
.BoardRowA {
background-color: #ADADAD ! important; font-family: arial, helvetica, sans-serif ! important; font-weight: normal ! important; font-size: 10pt ! important; color: #8D0000 ! important; text-decoration: none ! important; 
}
.BoardRowALink {
background-color: transparent ! important; font-family: arial, helvetica, sans-serif ! important; font-weight: normal ! important; font-size: 10pt ! important; color: #000000 ! important; text-decoration: underline ! important; 
}
.BoardRowALink:visited {
background-color: transparent ! important; font-family: arial, helvetica, sans-serif ! important; font-weight: normal ! important; font-size: 10pt ! important; color: #000000 ! important; text-decoration: underline ! important; 
}
.BoardRowB {
background-color: #DCDCDC ! important; font-family: arial, helvetica, sans-serif ! important; font-weight: normal ! important; font-size: 10pt ! important; color: #B22222 ! important; text-decoration: none ! important; 
}
.BoardRowBLink {
background-color: transparent ! important; font-family: arial, helvetica, sans-serif ! important; font-weight: normal ! important; font-size: 10pt ! important; color: #8B0000 ! important; text-decoration: underline ! important; 
}
.SubjectLink {
background-color: transparent ! important; font-family: arial, helvetica, sans-serif ! important; font-weight: bold ! important; font-size: 10pt ! important; color: #B22222 ! important; text-decoration: underline ! important; 
}
a.SubjectLink {
background-color: transparent ! important; font-family: arial, helvetica, sans-serif ! important; font-weight: bold ! important; font-size: 10pt ! important; color: #8B0000 ! important; text-decoration: underline ! important; 
}
a.SubjectLink:active {
background-color: transparent ! important; font-family: arial, helvetica, sans-serif ! important; font-weight: bold ! important; font-size: 10pt ! important; color: #B22222 ! important; text-decoration: underline ! important; 
}
a.SubjectLink:visited {
background-color: transparent ! important; font-family: arial, helvetica, sans-serif ! important; font-weight: normal ! important; font-size: 10pt ! important; color: black ! important; text-decoration: underline ! important; 
}
.AuthorLink {
background-color: transparent ! important; font-family: arial, helvetica, sans-serif ! important; font-weight: bold ! important; font-size: 10pt ! important; color: black ! important; text-decoration: underline ! important; 
}
.VersionText {
background-color: transparent ! important; font-family: arial, helvetica, sans-serif ! important; font-weight: normal ! important; font-size: 8pt ! important; color: black ! important; text-decoration: none ! important; 
}
.InputSection {
background-color: transparent ! important; font-family: Arial, Helvetica, sans-serif ! important; font-weight: bold ! important; font-size: 10pt ! important; color: #8B0000 ! important; text-decoration: none ! important; 
}
.InputNotes {
background-color: transparent ! important; font-family: Arial, Helvetica, sans-serif ! important; font-weight: normal ! important; font-size: 9pt ! important; color: #B22222 ! important; text-decoration: none ! important; 
width: 65% ! important; 
}
.SignatureTitle {
background-color: transparent ! important; font-family: Arial, Helvetica, sans-serif ! important; font-weight: bold ! important; font-size: 9pt ! important; color: green ! important; text-decoration: none ! important; 
}
.SignatureText {
background-color: transparent ! important; font-family: Arial, Helvetica, sans-serif ! important; font-weight: normal ! important; font-size: 9pt ! important; color: black ! important; text-decoration: none ! important; 
}
.AdminMenuLink {
font-size: 9px ! important;  color: #B22222 ! important;  text-decoration: none ! important; 
}
.AdminMenuSection {
font-size: 10px ! important;  font-weight: bold ! important;  color: #8B0000 ! important;  text-decoration: underline ! important; 
}
</style>