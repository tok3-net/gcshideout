<STYLE TYPE='text/css'>
A {
text-decoration: none;
}

A:hover {
text-decoration: underline;
}

BODY, TD {
font-family: arial, helvetica, sans-serif;
font-weight: normal;
font-size: 10pt;
color: black;
text-decoration: none;
}

border {
border-collapse: collapse;
}

textarea {
width: 100%;
}

.PlainText {
font-family: arial, helvetica, sans-serif;
font-weight: normal;
font-size: 10pt;
color: black;
text-decoration: none;
}

.MainTable {
background-color: #436697;
font-family: arial, helvetica, sans-serif;
font-weight: normal;
font-size: 10pt;
color: black;
text-decoration: none;
}

.MainMenuRowAlt {
background-color: transparent;
font-family: tahoma,arial,sans-serif;
font-weight: bold;
font-size: 9pt;
color: yellow;
text-decoration: none;
}

.MainMenuRow {
background-color: #333366;
font-family: tahoma,arial,sans-serif;
font-weight: normal;
font-size: 9pt;
color: white;
text-decoration: none;
}

.MainMenuLink {
background-color: transparent;
font-family: tahoma,arial,sans-serif;
font-weight: bold;
font-size: 9pt;
color: white;
text-decoration: none;
}

.MainMenuLinkLight {
background-color: transparent;
font-family: tahoma,arial,sans-serif;
font-weight: bold;
font-size: 9pt;
color: #CCCCFF;
text-decoration: none;
}

.BoardColumn {
background-color: navy;
background: url(gc-boards-back.jpg);
font-family: verdana,arial,sans-serif;
font-weight: bold;
font-size: 10pt;
color: white;
text-decoration: none;
}

.BoardColumnLink {
background-color: transparent;
font-family: verdana,arial,sans-serif;
font-weight: bold;
font-size: 10pt;
color: white;
text-decoration: none;
}

.BoardRowHeading {
background-color: #b1b3bc;
font-family: verdana,arial,sans-serif;
font-weight: normal;
font-size: 10pt;
color: black;
text-decoration: none;
}

.BoardRowHeadingLink {
background-color: transparent;
font-family: verdana,arial,sans-serif;
font-weight: normal;
font-size: 10pt;
color: #000099;
text-decoration: none;
}

.BoardRowBody {
background-color: #c1c3c9;
font-family: verdana,arial,sans-serif;
font-weight: normal;
font-size: 10pt;
color: black;
text-decoration: none;
}

.BoardRowBodySticky {
background-color: #c1c3c9;
font-family: verdana,arial,sans-serif;
font-weight: normal;
font-size: 10pt;
color: black;
text-decoration: none;
}

.BoardRowBodyLink {
background-color: transparent;
font-family: verdana,arial,sans-serif;
font-weight: normal;
font-size: 10pt;
color: #000099;
text-decoration: none;
}

.SubjectLink {
background-color: transparent;
font-family: verdana,arial,sans-serif;
font-weight: bold;
font-size: 10pt;
color: #000099;
text-decoration: none;
}

a.SubjectLink {
background-color: transparent;
font-family: verdana,arial,sans-serif;
font-weight: bold;
font-size: 10pt;
color: #000099;
text-decoration: none;
}

a.SubjectLink:active {
background-color: transparent;
font-family: verdana,arial,sans-serif;
font-weight: bold;
font-size: 10pt;
color: #000099;
text-decoration: none;
}

a.SubjectLink:visited {
background-color: transparent;
font-family: verdana,arial,sans-serif;
font-weight: normal;
font-size: 10pt;
color: #000099;
text-decoration: none;
}

.AuthorLink {
background-color: transparent;
font-family: verdana,arial,sans-serif;
font-weight: bold;
color: #000099;
text-decoration: none;
}

.AuthorLinkSmall {
background-color: transparent;
font-family: verdana,arial,sans-serif;
font-weight: bold;
font-size: 8pt;
color: #000099;
text-decoration: none;
}

.VersionText {
background-color: transparent;
font-family: verdana,arial,sans-serif;
font-weight: normal;
font-size: 8pt;
color: white;
text-decoration: none;
}

.InputSection {
background-color: transparent;
font-family: verdana,arial,sans-serif;
font-weight: bold;
font-size: 10pt;
color: black;
text-decoration: none;
}

.InputNotes {
background-color: transparent;
font-family: verdana,arial,sans-serif;
font-weight: normal;
font-size: 9pt;
color: maroon;
text-decoration: none;

width: 65%;
}

.SignatureTitle {
background-color: transparent;
font-family: verdana,arial,sans-serif;
font-weight: bold;
font-size: 9pt;
color: maroon;
text-decoration: none;
}

.SignatureText {
background-color: transparent;
font-family: verdana,arial,sans-serif;
font-weight: normal;
font-size: 9pt;
color: #333333;
text-decoration: none;
}

B     { font-weight: bold; }
.red  { color: #880000; }
.grey { color: #999999; }

.statistictext { color: white; }

.statisticvalue { 
font-weight: bold;
color: yellow; 
}

.QuotedText {
border: 1px dashed #888888;
background-color: #A1A3AC;
font-family: verdana,arial,sans-serif;
font-weight: normal;
font-size: 9pt;
color: white;
text-decoration: none;
margin-top: 5px;
margin-left: 5px;
margin-right: 5px;
padding: 5px;
}

.tos {
font-family: verdana,arial,sans-serif;
font-size: 8pt;
}

.AdminMenuLink {
background-color: transparent;
font-family: arial, helvetica, sans-serif;
font-size: 8pt;
color: white;
text-decoration: none;
}

</STYLE>
