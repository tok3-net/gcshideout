<style type="text/css">

.MainTable {
background-color: #008B00 ! important; font-family: arial, helvetica, sans-serif ! important; font-weight: normal ! important; font-size: 10pt ! important; color: #FFFFFF ! important; text-decoration: none ! important;  border: lavender ! important; 
}
.MainMenuRowAlt {
background-color: #556B2F ! important; font-family: arial, helvetica, sans-serif ! important; font-weight: bold ! important; font-size: 10pt ! important; color: cyan ! important; text-decoration: none ! important; 
}
.MainMenuRow {
background-color: #556B2F ! important; border: 1px solid lightslateblue ! important; font-family: arial, helvetica, sans-serif ! important; font-weight: normal ! important; font-size: 10pt ! important; color: white ! important; text-decoration: none ! important; 
}
.MainMenuLink {
background-color: #556B2F ! important; font-family: arial, helvetica, sans-serif ! important; font-weight: bold ! important; font-size: 10pt ! important; color: #FFFFFF ! important; text-decoration: underline ! important; 
}
.BoardColumn {
background-color: #003300 ! important; font-family: arial, helvetica, sans-serif ! important; font-weight: bold ! important; font-size: 10pt ! important; color: #8FBC8F ! important; text-decoration: none ! important; 
}
.BoardColumnLink {
background-color: transparent ! important; font-family: arial, helvetica, sans-serif ! important; font-weight: bold ! important; font-size: 10pt ! important; color: olivedrab ! important; text-decoration: underline ! important; 
}
.BoardRowA {
background-color: #001700 ! important; font-family: arial, helvetica, sans-serif ! important; font-weight: normal ! important; font-size: 10pt ! important; color: white ! important; text-decoration: none ! important; 
}
.BoardRowALink {
background-color: transparent ! important; font-family: arial, helvetica, sans-serif ! important; font-weight: normal ! important; font-size: 10pt ! important; color: yellow ! important; text-decoration: underline ! important; 
}
.BoardRowALink:visited {
background-color: transparent ! important; font-family: arial, helvetica, sans-serif ! important; font-weight: normal ! important; font-size: 10pt ! important; color: yellow ! important; text-decoration: underline ! important; 
}
.BoardRowBody {
background-color:  black ! important; font-family: arial, helvetica, sans-serif ! important; font-weight: normal ! important; font-size: 10pt ! important; color: #016843 ! important; text-decoration: none ! important; 
}
.BoardRowBLink {
background-color: transparent ! important; font-family: arial, helvetica, sans-serif ! important; font-weight: normal ! important; font-size: 10pt ! important; color: #556B2F ! important; text-decoration: underline ! important; 
}
.SubjectLink {
background-color: transparent ! important; font-family: arial, helvetica, sans-serif ! important; font-weight: bold ! important; font-size: 10pt ! important; color: #016843 ! important; text-decoration: underline ! important; 
}
a.SubjectLink {
background-color: transparent ! important; font-family: arial, helvetica, sans-serif ! important; font-weight: bold ! important; font-size: 10pt ! important; color: #016843 ! important; text-decoration: underline ! important; 
}
a.SubjectLink:active {
background-color: transparent ! important; font-family: arial, helvetica, sans-serif ! important; font-weight: bold ! important; font-size: 10pt ! important; color: #016843 ! important; text-decoration: underline ! important; 
}
a.SubjectLink:visited {
background-color: transparent ! important; font-family: arial, helvetica, sans-serif ! important; font-weight: normal ! important; font-size: 10pt ! important; color: #556B2F ! important; text-decoration: underline ! important; 
}
.AuthorLink {
background-color: transparent ! important; font-family: arial, helvetica, sans-serif ! important; font-weight: bold ! important; font-size: 10pt ! important; color: yellow ! important; text-decoration: underline ! important; 
}
.VersionText {
background-color: transparent ! important; font-family: arial, helvetica, sans-serif ! important; font-weight: normal ! important; font-size: 8pt ! important; color: yellow ! important; text-decoration: none ! important; 
}
.InputSection {
background-color: transparent ! important; font-family: Arial, Helvetica, sans-serif ! important; font-weight: bold ! important; font-size: 10pt ! important; color: #CDC673 ! important; text-decoration: none ! important; 
}
.InputNotes {
background-color: transparent ! important; font-family: Arial, Helvetica, sans-serif ! important; font-weight: normal ! important; font-size: 9pt ! important; color: yellow ! important; text-decoration: none ! important; 
width: 65% ! important; 
}
.SignatureTitle {
background-color: transparent ! important; font-family: Arial, Helvetica, sans-serif ! important; font-weight: bold ! important; font-size: 9pt ! important; color: blue ! important; text-decoration: none ! important; 
}
.SignatureText {
background-color: transparent ! important; font-family: Arial, Helvetica, sans-serif ! important; font-weight: normal ! important; font-size: 9pt ! important; color: green ! important; text-decoration: none ! important; 
}
.AdminMenuLink {
font-size: 9px ! important;  color: blue ! important;  text-decoration: none ! important; 
}
.AdminMenuSection {
font-size: 10px ! important;  font-weight: bold ! important;  color: green ! important;  text-decoration: underline ! important; 
}
</style>