<?php
   $starttime = microtime();
   $protectedpage = 1;
   include("common.php");

   $navigation[] = array("name" => "Users currently online",
                         "url"  => "");
                       
$sortby = strtolower($_GET['sortby']);
if ($sortby) { $extrawhere = " AND u.displayname LIKE '".$sortby."%'"; }
else { $extrawhere = ''; }     

     $sql = "SELECT b.username, b.lastactivity, u.postcount, u.displayname, u.displayformat "
           ."  FROM ".TABLE_BOARD_SESSIONS." b, ".TABLE_USERS." u"
           ." WHERE b.username = u.ID "
           ."   AND expirytime >= ".Date("U")
           ."   AND lastactivity > ".(Date("U")-(60*60))
	.$extrawhere
           ." ORDER BY lastactivity DESC";
     if ($exe = runQuery($sql))
     {
       if (resultCount($exe))
       {
         // Initialise the array
         $userids = array();
$sessioncount = 0;
         while ($row = fetchResultArray($exe))
         {
           // We've pulled out enough data to send to usernameDisplay() so that it doesn't need
           // to do any database queries itself...
           $dataarray = array("postcount" => $row['postcount'], 
                              "displayname" => $row['displayname'], 
                              "displayformat" => $row['displayformat']);
           
           // Get the light and dark versions of the username
           $username = usernameDisplay($row['username'], "", "showstar", $dataarray);
           $usernamelight = usernameDisplay($row['username'], "MainMenuLinkLight", "", $dataarray);
           
           // Don't repeat usernames
           if (!in_array($row['username'], $userids))
           {
             $userids[] = $row['username'];
             $users[] = $usernamelight;
             
             // Now we keep this to make our users-currently-online table later
             $sessiondata[] = array("username" => $username,
                                    "lastactivity" => $row['lastactivity'], 
			"lastpost" => getLastPost($row['username']), 
			"userid" => $row['username'], 
			"plain" => $row['displayname']);
	$sessioncount = $sessioncount + 1;
           }
         }
         
         $usernames = implode(", ", $users);
       }
     }

     // Now we make the table
     for ($i = 0; $i < $sessioncount; $i++ )
     {
       $tablerow .= "<TR><TD CLASS='BoardRowBody'>".$sessiondata[$i]['username']."</TD>\n"
                   ."    <TD CLASS='BoardRowBody'>".dateNeat($sessiondata[$i]['lastactivity'])."</TD>\n"
	."<td class=\"BoardRowBody\">".$sessiondata[$i]['lastpost']."</td>\n"
	."<td class=\"BoardRowBody\">\n"
	.makeLink("private.php?action=send&recipient=".$sessiondata[$i]['plain'], "Send PM", "BoardRowBodyLink")." | \n"
	.makeLink("messages.php?userid=".$sessiondata[$i]['userid'], "Post History", "BoardRowBodyLink")
	."</td>\n"
	."</TR>\n";
     }
$sql  = "SELECT ID FROM ".TABLE_USERS;
$totalcount = mysqli_num_rows(runQuery($sql));
     $table = "<TABLE WIDTH=100% CELLPADDING=2 CELLSPACING=1 BORDER=0>\n"
	."<tr>\n"
	."<td colspan=\"4\" class=\"BoardRowHeading\">\n"
	."<b>Sort By:</b>\n"
	."<select name=\"sortby\" onChange=\"document.location='usersonline.php?sortby=' + this.options[this.selectedIndex].value;\">\n"
	."<option value=\"\"> </option>\n"
	."<option value=\"a\"> A</option>\n"
	."<option value=\"b\"> B</option>\n"
	."<option value=\"c\"> C</option>\n"
	."<option value=\"d\"> D</option>\n"
	."<option value=\"e\"> E</option>\n"
	."<option value=\"f\"> F</option>\n"
	."<option value=\"g\"> G</option>\n"
	."<option value=\"h\"> H</option>\n"
	."<option value=\"i\"> I</option>\n"
	."<option value=\"j\"> J</option>\n"
	."<option value=\"k\"> K</option>\n"
	."<option value=\"l\"> L</option>\n"
	."<option value=\"m\"> M</option>\n"
	."<option value=\"n\"> N</option>\n"
	."<option value=\"o\"> O</option>\n"
	."<option value=\"p\"> P</option>\n"
	."<option value=\"q\"> Q</option>\n"
	."<option value=\"r\"> R</option>\n"
	."<option value=\"s\"> S</option>\n"
	."<option value=\"t\"> T</option>\n"
	."<option value=\"u\"> U</option>\n"
	."<option value=\"v\"> V</option>\n"
	."<option value=\"w\"> W</option>\n"
	."<option value=\"x\"> X</option>\n"
	."<option value=\"y\"> Y</option>\n"
	."<option value=\"z\"> Z</option>\n"
	."</select>\n"
	."<b>".number_format($sessioncount)."</b> out of <b>".number_format($totalcount)."</b> users have been online in the past 60 minutes.\n"
	."</td>\n"
	."</tr>\n"
             ."<TR><TD WIDTH=25% CLASS='BoardColumn'>User Name</TD>\n"
             ."    <TD WIDTH=25% CLASS='BoardColumn'>Last Login</TD>\n"
	."<td width=\"25%\" class=\"BoardColumn\">Last Post</td>\n"
	."<td width=\"25%\" class=\"BoardColumn\">Options</td>\n"
	."</TR>\n"
             .$tablerow
             ."</TABLE>\n";
     
   $online = fetchLoggedinUsers("50");
   $output = $table;

   $pagecontents = $output;
   include("layout.php");
?>