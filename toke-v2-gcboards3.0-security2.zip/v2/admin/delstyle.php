<?php
$boardfile = "admin/delstyle.php";
$protectedpage = 1;
$adminfile = 1;
$title = "Remove System Style";
include("common.php");
if (!$_POST && $action == "delete") { exit; }
if (!$action) { $action = $_POST['action']; }

if (checkAccess("admin"))
{
  if ($action == "delete")
  {
    $styleid = $_POST['style'];
    $styleinfo = fetchRow($styleid, $TableStyles, "ID");
    unlink("../stylesheets/".$styleinfo['filename']);
    $sql = "DELETE FROM ".$TableStyles." WHERE ID = '$styleid' LIMIT 1";
    $exe = runQuery($sql);
    if ($exe)
    {
      $adminaction = "System Style Removed";
      $description = "The ".$styleinfo['name']." System Style Was Removed";
      newAdminAction($adminaction, $description);
      $sysmsg = "The System Style Was Successfully Removed";
      $action = "";
    }
    else
    {
      $sysmsg = "An Error Occured, Please Try Again";
      $action = "";
    }
  }

  if (!$action)
  {
    $sql = "SELECT * FROM ".$TableStyles." ORDER BY name ASC";
    $exe = runQuery($sql);
    while ($row = fetchResult($exe))
    {
      $options .= "<option value=\"".$row['ID']."\">".$row['name']."</option>\n";
    }
    $output = "<table border=\"0\" width=\"100%\" cellspacing=\"1\" cellpadding=\"20\">\n"
	."<tr>\n"
	."<td class=\"BoardRowB\" width=\"100%\">\n"
	."<form action=\"delstyle.php\" method=\"post\" name=\"sbform\" onSubmit=\"disableSubmit()\">\n"
	."<span style=\"InputSection\">Choose A System Style To Remove</span><p>\n"
	."<select name=\"style\">\n"
	.$options
	."</select><p>\n"
	.inputHidden("action", "delete")."\n"
	.inputSubmit("Remove Style")."\n"
	."</form>\n"
	."</td>\n"
	."</tr>\n"
	."</table>\n";
  }
}
else
{
  header("Location: ../noaccess.php");
}

include("layout.php");
?>