<?php
$starttime = microtime();
$protectedpage = 1;
$functionset = "admin";
include("common.php");
if (($_COOKIE['adminlogin'] != $userdata['adminpass']) || (!$userdata['adminpass'])) { header("Location: login.php"); }
if ((!$_POST) && ($action == "reallyremove" || $action == "save" || $action == "update")) { exit; }
$navigation[] = array("name" => "System Styles", "url" => "stylesheets.php");

if (checkAccess("accessadmin"))
{

  if ($action == "edit")
  {
    $navigationhead = "Edit System Style";
    $name = $_GET['name'];
    $sql = "SELECT filename FROM ".TABLE_STYLESHEETS." WHERE name = '$name' LIMIT 1";
    $exe = runQuery($sql);
    $row = fetchResultArray($exe);
    $filename = $row['filename'];
    
    $stylefile = "../stylesheets/".$filename."";
    $handle = fopen($stylefile, "rb");
    $stylesheet = fread($handle, filesize($stylefile));
    fclose($handle);

    if (false /* get_magic_quotes_gpc() removed in PHP8; always false since 5.4 */)
    {
      $stylesheet = stripSlashes($stylesheet);
    }
    include("../elements/adminstyle.php");
    $output ="<table width=\"100%\" cellpadding=\"20\" cellspacing=\"1\" border=\"0\">\n"
            ."  <tr>\n"
            ."    <td class=\"BoardRowBody\">\n"
 	      ."    <form action='".$PHP_SELF."' method=\"POST\">\n"
            .inputHidden("action", "update")
            .inputHidden("name", $name)
            .inputHidden("filename", $filename)
            .$editstyleform
            ."    </form>\n"
            ."    </td>\n"
            ."  </tr>\n"
            ."</table>\n";
  }

  if ($action == "update")
  {
    $navigationhead = "Updating System Style";
    if (false /* get_magic_quotes_gpc() removed in PHP8; always false since 5.4 */)
    {
      $stylesheet = stripSlashes($stylesheet);
    }
    $out = fopen("../stylesheets/".$filename."", "w");
    if ($out === false)
    {
      $writefileerror = "Couldn't write to ../stylesheets/$filename -- check its file permissions.";
    }
    else
    {
      fwrite($out, $stylesheet);
      fclose($out);
      $adminaction = "Style Updated";
      $description = "The ".$name." System Style Was Updated";
      newAdminAction($adminaction, $description);
      $sysmsg = "custom";
      $sysmsgcustomcontent = "Stylesheet Updated Successfully";
    }
    $action = "";
  }

  if ($action == "reallyremove")
  {
    $navigationhead = "Deleting Stylesheet";
    $sql = "DELETE FROM ".TABLE_STYLESHEETS." WHERE name = '$name' LIMIT 1";
    if ($exe = runQuery($sql))
    {
      $adminaction = "System Style Deleted";
      $description = "The ".$name." System Style Was Removed";
      newAdminAction($adminaction, $description);
      $sysmsg = "custom";
      $sysmsgcustomcontent = "The System Style Was Successfully Removed";
      $action = "";
    }
    else
    {
      $sysmsg = "custom";
      $sysmsgcustomcontent = "An Error Occured And The System Style Couldn't Be Deleted";
      $action = "";
    }
  }

  if ($action == "remove")
  {
    $navigationhead = "Remove System Style";
    $name = $_GET['name'];
    $sql = "SELECT filename FROM ".TABLE_STYLESHEETS." WHERE name = '$name' LIMIT 1";
    $exe = runQuery($sql);
    $row = fetchResultArray($exe);
    $filename = $row['filename'];
    $output = "<FORM ACTION='".$PHP_SELF."' METHOD=\"POST\">"
	."<SPAN CLASS='InputSection'>Are you sure you want to remove the &quot;".$name." (".$filename.")&quot; system style?<BR>"
	."Once the style is deleted it can no longer be recovered.  Click <A HREF='stylesheets.php'>Back</A> If you no longer want "
	."to delete the style otherwise click &quot;Proceed&quot; below.<BR></SPAN>"
	.inputHidden("action", "reallyremove")
	.inputHidden("name", $name)
	.inputSubmit("Proceed")
	."</FORM>";
  }

  if ($action == "save")
  {
    $name = $_POST['name'];
    $filename = $_POST['filename'];
    $content = $_POST['content'];
    $writefile = "../stylesheets/".$filename;
    $handle = fopen($writefile, "w");
    if ($handle === false)
    {
      $writefileerror = "Couldn't write to $writefile -- check its file permissions.";
    }
    else
    {
      fwrite($handle, $content);
      fclose($handle);
    }
    $sql = "INSERT INTO ".TABLE_STYLESHEETS." VALUES ('$name', '$filename')";
    if ($exe = runQuery($sql))
    {
      $adminaction = "System Style Added";
      $description = "The ".$name." System Style Was Added";
      newAdminAction($adminaction, $description);
      $sysmsg = "custom";
      $sysmsgcustomcontent = "The System Style Was Added Successfully";
      $action = "";
    }
    else
    {
      $sysmsg = "custom";
      $sysmsgcustomcontent = "An Error Occured And The System Style Couldnt Be Added";
      $action = "add";
    }
  }

  if ($action == "add")
  {
    $navigationhead = "Add System Style";
    $output = "<FORM ACTION='".$PHP_SELF."' METHOD=\"POST\">"
	."<TABLE BORDER=1 STYLE=\"border-collapse: collapse;\">"
	."<TR><TD COLSPAN=\"2\"><SPAN CLASS='InputNotes'>"
	."In order to add a stylesheet you have to have it uploaded to the boards stylesheet folder."
	."</SPAN></TD></TR>"
	."<TR><TD ALIGN=RIGHT CLASS='BoardRowHeading'>Style Name</TD>"
	."<TD CLASS='BoardRowBody'>".inputText("name", $name)."</TD></TR>"
	."<TR><TD ALIGN=RIGHT CLASS='BoardRowHeading'>File Name (With .php extension)</TD>"
	."<TD CLASS='BoardRowBody'>".inputText("filename", $filename)."</TD></TR>"
	."<TR><TD ALIGN=RIGHT CLASS=\"BoardRowHeading\" VALIGN=\"top\">CSS</TD>"
	."<TD CLASS=\"BoardRowBody\"><TEXTAREA NAME=\"content\" ROWS=\"15\" COLS=\"50\"></TEXTAREA></TD></TR>"
	."</TABLE>"
	.inputHidden("action", "save")
	.inputSubmit("Add Style")
	."</FORM>";
  }

  if (!$action || $action == "")
  {
    $navigationhead = "Manage System Styles";
    $sql = "SELECT * FROM ".TABLE_STYLESHEETS." ORDER BY name ASC";
    $exe = runQuery($sql);
    $output = "<B>Note: If you delete the default.php stylesheet people without a stylesheet selected will not see a stylesheet equipped.</B>"
	."<TABLE BORDER=1 WIDTH=100% CELLSPACING=1 CELLPADDING=3 STYLE=\"border-collapse: collapse;\">"
	."<TR><TD CLASS='BoardRowHeading' COLSPAN=\"4\"><A HREF='stylesheets.php?action=add' CLASS='MainMenuLink'>Add A New System Style</A></TD></TR>"
	."<TR><TD CLASS='BoardRowHeading'>Name</TD><TD CLASS='BoardRowHeading'>File Name</TD>"
	."<TD CLASS='BoardRowHeading'>Edit Style</TD><TD CLASS='BoardRowHeading'>Remove Style</TD></TR>";
    while ($row = fetchResultArray($exe))
    {
      $output .= "<TR>"
	."<TD CLASS='BoardRowBody'>".$row['name']."</TD><TD CLASS='BoardRowBody'>".$row['filename']."</TD>"
	."<TD CLASS='BoardRowBody'><A HREF='stylesheets.php?action=edit&name=".$row['name']."'>Edit</A></TD>"
	."<TD CLASS='BoardRowBody'><A HREF='stylesheets.php?action=remove&name=".$row['name']."'>Delete</A></TD>"
	."</TR>";
    }
    $output .= "</TABLE>";
  }
}
else
{
  header("Location: ../noaccess.php");
}

$output = "<TABLE BORDER\"0\" WIDTH=\"100%\" CLASS=\"BoardRowBody\">"
	."<TR><TD WIDTH=\"100%\" CLASS=\"BoardRowBody\">"
	.$output
	."</TD></TR></TABLE>";
$pagecontents = $output;
include("layout.php");
?>