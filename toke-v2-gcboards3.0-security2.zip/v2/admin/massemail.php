<?php
   $starttime = microtime();
   $functionset = "admin";
   include("common.php");
   $navigationhead = "Mass Email Members";
if (($_COOKIE['adminlogin'] != $userdata['adminpass']) || (!$userdata['adminpass'])) { header("Location: login.php"); }
if (!$_POST && $action == "mail") { exit; }

if (checkAccess("accessadmin"))
{

if ($action == "mail")
{
  $email = $_POST['message'];
  $sql = "SELECT contactemail, fname FROM ".TABLE_USERS."";
  $exe = runQuery($sql);
  while ($row = fetchResultArray($exe))
  {
    $recipient = $row['fname']>" <".$row['contactemail'].">";
    sendSystemEmail($recipient, "massemail", $email);
  }
  $adminaction = "Mass Email";
  $description = "A Mass Email Was Sent Out To All Members";
  newAdminAction($adminaction, $description);
  $sysmsg = "custom";
  $sysmsgcustomcontent = "The Mass Email Has Been Sent Out";
  $output = "<SPAN CLASS=\"InputSection\">Mass Email:</SPAN><BR>"
	.$email;
}

if (!$action || $action == "")
{

  $output = "<FORM ACTION='".$PHP_SELF."' METHOD=\"POST\">"
	  ."Enter Your Message Below:<BR>"
	  ."<TEXTAREA NAME=\"message\" ROWS=\"15\" COLS=\"60\"></TEXTAREA><BR>"
	  ."<INPUT TYPE=\"HIDDEN\" NAME=\"action\" VALUE=\"mail\">"
	  ."<INPUT TYPE=\"SUBMIT\" VALUE=\"Mass Email Members\">"
	  ."</FORM>";
}
   
$output = "<TABLE BORDER\"0\" WIDTH=\"100%\" CLASS=\"BoardRowBody\">"
	."<TR><TD WIDTH=\"100%\" CLASS=\"BoardRowBody\">"
	.$output
	."</TD></TR></TABLE>";
}
else
{
header("Location: ../noaccess.php");
}

$pagecontents = $output;
include("layout.php");
?>