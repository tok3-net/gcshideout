<?php
   $starttime = microtime();
   $protectedpage = 1;
   $functionset   = "admin";
   include("common.php");
if (($_COOKIE['adminlogin'] != $userdata['adminpass']) || (!$userdata['adminpass'])) { header("Location: login.php"); }
if (!$_POST && $action == "savepass") { exit; }

if (checkAccess("accessvip"))
{     
  $navigationhead = "Change Admin Password";
  if ($action == "savepass")
  {
    $currpass = $_POST['currpass'];
    $password1 = $_POST['password1'];
    $password2 = $_POST['password2'];
    $enccurrpass = encPassword($currpass);
    $encnewpass = encPassword($password1);
    if ($password1!= $password2)
    {
      $err = "yes";
      $sysmsg = "custom";
      $sysmsgcustomcontent = "Your passwords dont match";
      $action = "";
    }
    if ($enccurrpass != $userdata['adminpass'])
    {
      $err = "yes";
      $sysmsg = "custom";
      $sysmsgcustomcontent = "Your didn't enter the right current password";
      $action = "";
    }
    if (!$currpass || !$password1 || !$password2)
    {
      $err = "yes";
      $sysmsg = "custom";
      $sysmsgcustomcontent = "You didn't enter passwords into all the fields";
      $action = "";
    }
    if (!$err)
    {
      $data['adminpass'] = $encnewpass;
      $update = updateUser($userdata['ID'], $data);
      if ($update)
      {
        sendCookie("adminlogin", "");
        $adminaction = "Admin Pass Changed";
        $description = "Users Admin Password Was Changed";
        newAdminAction($adminaction, $description);
        $sysmsg = "custom";
        $sysmsgcustomcontent = "Your Admin Password Was Changed";
        $action = "";
      }
      else
      {
        $sysmsg = "custom";
        $sysmsgcustomcontent = "An error occured and your admin password couldn't be changed";
        $action = "";
      }
    }
  }

  if (!$action || $action == "")
  {
    include("../elements/changepass.php");
    $output = "<FORM ACTION='".$PHP_SELF."' METHOD=\"POST\">"
	."<SPAN CLASS='InputSection'>Change Admin Password</SPAN><BR>"
	."Enter you current admin password, then your new admin password twice to verify it.<BR><BR>"
	.$changepassform
	.inputHidden("action", "savepass")
	.inputSubmit("Change Admin Password")
	."</FORM>";
  }
}
else
{
header("Location: ../noaccess.php");
}

     $output = "<TABLE WIDTH=100% CELLPADDING=20 CELLSPACING=1 BORDER=0>\n"
              ."<TR><TD CLASS='BoardRowBody'>\n"
              ."        ".str_replace("\n", "\n        ", $output)."</TD></TR>\n"
              ."</TABLE>\n";
$pagecontents = $output;
include("layout.php");
?>