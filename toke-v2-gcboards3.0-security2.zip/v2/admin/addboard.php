<?php
$boardfile = "admin/addboard.php";
$adminfile = 1;
$protectedpage = 1;
include("common.php");
$title = "Add Board";
if (!$_POST && $action == "add") { exit; }

if (checkAccess("manager"))
{
  if ($action == "add")
  {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $rank = $_POST['rank'];
    $group = $_POST['group'];
    $private = $_POST['private'];
    $users = $_POST['users'];
    $post = $_POST['post'];
    $poll = $_POST['poll'];
    $reply = $_POST['reply'];
    $posti = $_POST['posti'];
    $dollari = $_POST['dollari'];
    $date = Date("U");
    $sql = "INSERT INTO ".$TableBoards." (name, description, rank, date, groupid, private, users, post, poll, reply, posti, dollari) 
	VALUES ('$name', '$description', '$rank', '$date', '$group', '$private', '$users', '$post', '$poll', '$reply', '$posti', '$dollari')";
    $exe = runQuery($sql);
    if ($exe)
    {
      $adminaction = "New Board";
      $description = "The ".$name." board was created.";
      newAdminAction($adminaction, $description);
      header("Location: intro.php?sysmsg=The+board+".$name."+was+successfully+created");
    }
    else
    {
      $sysmsg = "An error occured, please try again.";
      $action = "";
    }
  }

  if (!$action || $action == "")
  {
    include("../elements/boardform.php");
    $output = "<table width=\"100%\" cellpadding=\"3\" cellspacing=\"1\" border=\"0\">\n"
	."<tr>\n"
	."<form name=\"sbform\" action=\"addboard.php\" method=\"post\" onSubmit=\"disableSubmit()\">\n"
	."<td class=\"BoardColumn\" width=\"50%\">Description</td>\n"
	."<td class=\"BoardColumn\" width=\"50%\">Permissions</td>\n"
	."</tr>\n"
	.$boardform
	."<tr valign=\"middle\">\n"
	."<td colspan=\"2\" class=\"BoardRowB\" align=\"center\" valign=\"middle\">\n"
	.inputHidden("action", "add")."\n"
	.inputSubmit("Add Board")."\n"
	."</td>\n"
	."</form>\n"
	."</tr>\n"
	."</table>\n";
  }
}
else
{
  header("Location: ../noaccess.php");
}

include("layout.php");
?>