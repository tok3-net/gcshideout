<?php
$starttime = microtime();
$protectedpage = 1;
$functionset = "admin";
include("common.php");
if (($_COOKIE['adminlogin'] != $userdata['adminpass']) || (!$userdata['adminpass'])) { header("Location: login.php"); }
if (!$_POST && $action == "remove") { exit; }
$navigationhead = "Remove Users Account";
if (checkAccess("accessadmin"))
{

if ($action == "remove")
{
  $username = $_POST['username'];
  $userinfo = fetchRow($username, TABLE_USERS, "displayname", "idfieldistext", "dontcareifblank");
  if ($userinfo['ID'])
  {
    $sql = "DELETE FROM ".TABLE_USERS." WHERE ID = '".$userinfo['ID']."' LIMIT 1";
    if ($exe = runQuery($sql))
    {
	$adminaction = "Account Deleted";
	$description = "The Account For ".$username." Was Deleted";
       newAdminAction($adminaction, $description);
      $sysmsg = "custom";
      $sysmsgcustomcontent = "Account For ".$username." Was Successfully Deleted";
      $action = "";
    }
    else
    {
      $sysmsg = "custom";
      $sysmsgcustomcontent = "An Error Occured, Please Try Again";
      $action = "";
    }
  }
  else
  {
    $sysmsg = "custom";
    $sysmsgcustomcontent = "No Such Username, Please Try Again";
    $action = "";
  }
}

if (!$action || $action == "")
{
  $output = "<FORM ACTION='".$PHP_SELF."' METHOD=\"POST\">"
	  ."<SPAN CLASS=\"InputSection\">Enter The Username Of The Person's Account You Wish To Remove Below:</SPAN><BR>"
	  ."<INPUT TYPE=\"TEXT\" NAME=\"username\" VALUE='".$username."'><BR>"
	  .inputHidden("action", "remove")
	  .inputSubmit("Remove Users Account")
	  ."</FORM>";
}

$output = "<TABLE WIDTH=\"100%\" CELLSPACING=\"1\" CELLPADDING=\"20\" BORDER=\"0\">"
	."<TR><TD WIDTH=\"100%\" CLASS=\"BoardRowBody\">"
	.$output
	."</TD></TR></TABLE>";
}
else
{
header("Location: ../noaccess.php");
}
$pagecontents = $output;
include("layout.php");
?>