<?php
   $starttime = microtime();
   $protectedpage = 1;
   $functionset   = "admin";
   include("common.php");
if (($_COOKIE['adminlogin'] != $userdata['adminpass']) || (!$userdata['adminpass'])) { header("Location: login.php"); }
if ((!$_POST) && ($action == "savenewicon" || $action == "removegroup" || $action == "creategroup" || $action == "updategroup" || $activity == "del" || $operation)) { exit; }

if (checkAccess("accessmanager"))
{                           

       $navigation[] = array("name" => "Icon Management",
                             "url"  => "$PHP_SELF?action=manageicons&step=1");

       if ($step == "savenewicon")
       {
         $navigationhead = "Add New Icon";

         //echo "NewIcon is $newicon.<BR>\n";
         if (($newicon) && ($newicon != "none"))
         {
           $source = $newicon;

           //$filedata = fileToBase64($source);
	$sb_gen_filename = rand(1000000, 9999999).$_FILES['newicon']['name'];
	move_uploaded_file($source, "../gfx/icons/".$sb_gen_filename);
           $newicon = newIcon($groupid, $iconname, $newicon_name, $sb_gen_filename, $newicon_type);
	$adminaction = "Icon Added";
	$description = "".$iconname." Icon Added To Group ID: ".$groupid."";
       newAdminAction($adminaction, $description);
           
           if ($newicon)
           {
             $icondata['iconid'] = $newicon;
             $icondata['align']  = "MIDDLE";
             
             $output = getIcon("", $icondata)
                      ."Your new icon, $newicon_name, has been put into group ".$groupid."<BR>\n"
                      ."<A HREF='$PHP_SELF?action=manageicons&step=2&groupid=".$groupid."'>Click here to see it</A>\n"
                      ."<P><SPAN CLASS='PlainText'>\n"
                      ."&nbsp; &raquo; <A HREF='$PHP_SELF?action=manageicons&step=addicon&groupid=".$groupid."'>Add Another Icon Here</A><BR>\n"
                      ."&nbsp; &raquo; <A HREF='$PHP_SELF?action=manageicons'>Return to Icon Management</A>\n";
           }
           else
           {
             $sysmsg = "custom";
             $sysmsgcustomcontent = "Icon data could not be inserted";
             $step = "addicon";
           }
         }
         else
         {
           $step = "addicon";
         }
       }
       
       if ($step == "addicon")
       {
         $navigationhead = "Add New Icon";

         include("../elements/newicon.php");
         $output = "<FORM ACTION='$PHP_SELF' ENCTYPE='multipart/form-data' METHOD=POST>\n"
                  .inputHidden("MAX_FILE_SIZE", 50000)
                  .inputHidden("action", "manageicons")
                  .inputHidden("step", "savenewicon")
                  .inputHidden("groupid", $groupid)
                  .$iconform
                  ."<P>\n"
                  .inputSubmit("Save Icon")
                  ."</FORM>\n";
       }
       
       if ($step == "removegroup")
       {
         $removegroup = removeIconGroup($groupid);
         if ($removegroup)
         {
	$adminaction = "Icon Group Removed";
	$description = "Icon Group: ".$groupid." Was Removed";
       newAdminAction($adminaction, $description);
           $sysmsg = "custom";
           $sysmsgcustomcontent = "Group ".$groupid." was removed";
         }
         else
         {
           $sysmsg = "custom";
           $sysmsgcustomcontent = "Group ".$groupid." couldn't be removed";
         }
         $step = "";
       }
       
       if ($step == "creategroup")
       {
         $navigationhead = "Create New Icon Group";

         $creategroup = newIconGroup($groupname, $classid);
         if ($creategroup)
         {
	$adminaction = "Icon Group Created";
	$description = "Icon Group: ".$groupname." Was Added";
       newAdminAction($adminaction, $description);
           $sysmsgcustom = "custom";
           $sysmsgcustomcontent = "Your new group, $groupname, has been created.\n";
           $step = "1";
           $groupid = fetchLastInsert($exe);
         }
         else
         {
           $sysmsgcustom = "custom";
           $sysmsgcustomcontent = "Your new icon group was not created.\n";
           $step = "newgroup";
         }
       }
       
       if ($step == "newgroup")
       {
         $navigationhead = "Create New Icon Group";

         include("../elements/icongroup.php");
         $output = "<FORM ACTION='$PHP_SELF' METHOD=POST>\n"
                  .inputHidden("action", "manageicons")
                  .inputHidden("step", "creategroup")
                  .$icongroupform
                  ."<P>\n"
                  .inputSubmit("Create Group")
                  ."</FORM>\n";
       }
       
       if ($step == "updategroup")
       {
         $navigationhead = "Change Icon Group";

         $update = updateIconGroup($groupid, $groupname, $classid);
         
         if ($update)
         {
	$adminaction = "Icon Group Updated";
	$description = "Icon Group ".$groupname." Was Updated";
       newAdminAction($adminaction, $description);
           $sysmsgcustom = "custom";
           $sysmsgcustomcontent = "This group, '".$groupname."', has been updated.<BR>\n";
           $step = 2;
         }
       }
       
       if ($step == "editgroup")
       {
         $navigationhead = "Change Icon Group";

         $icongroupdata = fetchRow($groupid, TABLE_ICON_GROUPS);
         $currentgroupid   = $icongroupdata['ID'];
         $currentgroupname = $icongroupdata['groupname'];
         $currentclassid   = $icongroupdata['classid'];
         
         if (!$reason)
         {
           $groupname = $currentgroupname;
           $classid   = $currentclassid;
         }
         
         include("../elements/icongroup.php");
         $output = "<FORM ACTION='$PHP_SELF' METHOD=POST>\n"
                  .inputHidden("action", "manageicons")
                  .inputHidden("step", "updategroup")
                  .inputHidden("groupid", $groupid)
                  .$icongroupform
                  ."<P>\n"
                  .inputSubmit("Update Group")
                  ."</FORM>\n";
       }
       
       if ($step == 3)
       {
         $navigationhead = "Update Icons";

         if (!$iconid)   { $err[] = "No icon was selected"; }
         if (!$activity) { $err[] = "No activity was selected"; }
         
         if ($err)
         {
           $reason = implode("<BR>\n", $err);
           $step = 2;
         }
         else
         {
           // $activity will either contain "del" to delete the icon,
           // or an integer value which is to be the icon's new groupid.
           if ($activity == "del")
           {
             $operation = deleteIcon($iconid);
	$adminaction = "Icon Deleted";
	$description = "Icon: ".$iconid." Was Deleted";
       newAdminAction($adminaction, $description);
             $successmsg = "Icon ".$iconid." has been deleted";
           }
           else
           {
             $groupdata = fetchRow($activity, TABLE_ICON_GROUPS);
             
             // Must be a move operation, then
             $operation = changeIconGroup($iconid, $activity);
             $successmsg = "Icon ".$iconid." has been moved to <I>".$groupdata['groupname']."</I>\n";
           }
           
           if ($operation)
           {
	$adminaction = "Icon Moved";
	$description = "Icon ID: ".$iconid." Was Moved To: ".$groupdata['groupname']."";
       newAdminAction($adminaction, $description);
             // Operation (whatever it was) was successful
             $sysmsgcustom = "custom";
             $sysmsgcustomcontent = $successmsg;
           }
           else
           {
             $sysmsgcustom = "custom";
             $sysmsgcustomcontent = "Sorry, your requested operation was not carried out.";
           }
           $step = 2;
         }
       }
       
       if ($step == 2)
       {
         $icongroupdata = fetchRow($groupid, TABLE_ICON_GROUPS);

         $navigationhead = "Icons in ".$icongroupdata['groupname'];
        
         if (!$page) { $page = 1; }
        
         $browseopt['showall'] = 1; 
         $browseopt['groupid'] = $groupid;
         $browseopt['orderby'] = "iconname";
         $browseopt['page']    = $page;
         $browseopt['perpage'] = 25;
         $browseopt['linkparameters'] = "action=manageicons&step=2";
         
         $icons = listIcons($browseopt);
         
         $centerrow = $icons['navbar'];
         
         $extraoptions = array("del" => "Delete Icon");
         
         $output = $reasonoutput
                  ."<FORM ACTION='$PHP_SELF' METHOD=POST>\n"
                  .inputHidden("action", "manageicons")
                  .inputHidden("step", 2)
                  ."View group: \n"
                  .inputIconGroup("groupid", $groupid, "edit", "-- Select Group --")
                  .inputSubmit("Browse")
                  ."</FORM>\n"
                  ."<SPAN CLASS='InputSection'>Icon Selection</SPAN><BR>\n"
                  ."Select an icon, operation and press <I>Proceed</I>\n"
                  ."<FORM ACTION='$PHP_SELF' METHOD=POST>\n"
                  .inputHidden("action", "manageicons")
                  .inputHidden("step", 3)
                  .inputHidden("groupid", $groupid)
                  .inputHidden("groupname", $icongroupdata['groupname'])
                  .$icons['icontable']
                  .inputIconGroup("activity", $activity, "edit", "-- Select Option --", "", "Move to '", "' group &nbsp;", $extraoptions)
                  .inputSubmit("Proceed")
                  ."</FORM><SPAN CLASS='PlainText'>\n"
                  ."&nbsp; &raquo; <A HREF='$PHP_SELF?action=manageicons&step=addicon&groupid=".$groupid."'>Add an icon to this group</A>\n";
       }
       
       if (!$step) { $step = 1; }
       
       if ($step == 1)
       {
         $navigationhead = "Icon Groups";

         $icongroups = listIconGroups();
         
         $areaoptions[] = array("name" => "Create a New Icon Group",
                                "url"  => $PHP_SELF."?action=manageicons&step=newgroup");

         $output = $icongroups;

         $nowrap = 1;
       }

}
else
{
header("Location: ../noaccess.php");
}

     $output = "<TABLE WIDTH=100% CELLPADDING=20 CELLSPACING=1 BORDER=0>\n"
              ."<TR><TD CLASS='BoardRowBody'>\n"
              ."        ".str_replace("\n", "\n        ", $output)."</TD></TR>\n"
              ."</TABLE>\n";
$pagecontents = $output;
include("layout.php");
?>