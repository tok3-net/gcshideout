<?php
   $starttime = microtime();
   $protectedpage = 1;
   $functionset   = "admin";
   include("common.php");
if (($_COOKIE['adminlogin'] != $userdata['adminpass']) || (!$userdata['adminpass'])) { header("Location: login.php"); }
if (!$_POST && $action == "ban") { exit; }
if (checkAccess("accessmoderator"))
{

   $navigation[] = array("name" => "Ban User",
                         "url"  => $PHP_SELF);
   
   if ($action == "ban")
   {
     $username = $_POST['username'];
     if ($username)
     {
       $unbandate = $_POST['unbandate'];
      if ($unbandate)
      {

       $vars['classid'] = 7;
       $vars['unbandate'] = $unbandate;
       $vars['banreason'] = $_POST['banreason'];
       
       $userinfo = fetchRow($username, TABLE_USERS, "displayname", "idfieldistext", "dontcareifblank");
      if (($userinfo['classid'] == "6" || $userinfo['classid'] == "5") || (checkAccess("accessadmin")))
      {
       if ($userinfo['ID'])
       {
         $update = updateUser($userinfo['ID'], $vars);
	$adminaction = "User Banned";
	$description = $username." Was Banned";
       newAdminAction($adminaction, $description);

	global $DiscoBoardName;
       $email = implode("", file("../templates/banned.txt"));
       
       // Replace the special bits in the welcome email
       $email = str_replace("FNAME", $_POST['username'], $email);
       $email = str_replace("DISCOBOARDNAME", $DiscoBoardName, $email);
       $email = str_replace("BANNINGREASON", $_POST['banreason'], $email);
       $email = str_replace("UNBANDATE", $_POST['unbandate'], $email);
       $from = "From: <ban@gcshideout.com>";
       $message = $email;
       mail($userinfo['contactemail'], "You Have Been Banned", $message, $from);
       $userinfoID = $userinfo['ID'];
         if ($update)
         {
	$sql = "DELETE FROM ".TABLE_BOARD_SESSIONS." WHERE username = '$userinfoID'";
	if ($exe = runQuery($sql))
	{
	$body = "[b]Banning Reason:[/b]\n"
		.$_POST['banreason']."\n\n"
		."[b]UnBan Date:[/b]\n"
		.$_POST['unbandate'];
	global $userdata;
	addAdminNote($userinfo['ID'], $userdata['ID'], $body);
              $sysmsg = "custom";
	$sysmsgcustomcontent = $username." Has Been Banned, Please Make Sure To UnBan On The Correct Date";
 	$action = "";
	}
	else
	{
	$reason = "This users board sessions couldn't be deleted.<BR>\n";
	$action = "";
	}
         }
         else
         {
           $reason = "Couldn't ban this user - you'll have to get an administrator to do it.<BR>\n";
           $action = "";
         }
        
       }
       else
       {
         $reason = "Didn't find a user named  <I>".$username."</I>. Mistyped?<BR>\n";
         $action = "";
       }
     }
     else
     {
       $reason = "This member is not in the Member/Insider access class, you will have to get an admin to ban this user.";
       $action = "";
     }
    }
    else
    {
      $reason = "Please enter an UnBan Date";
      $action = "";
    }
  }
}


   
   if (!$action || $action == "")
   {

       $output = ""

              ."<FORM ACTION='$PHP_SELF' METHOD=POST>\n"
              ."<SPAN CLASS='InputSection'>Username To Ban: </SPAN>".inputText("username", $username)."<BR>"
	."<SPAN CLASS='InputSection'>UnBan Date: </SPAN>".inputText("unbandate", $unbandate)."<BR>"
	."<TEXTAREA NAME='banreason' COLS='40' ROWS='10'>- - - Reason For Banning - - -</TEXTAREA><BR>"
              .inputHidden("action", "ban")
              .inputSubmit("Ban User")
              ."</FORM>\n\n";
   }



   if ($reason)
   {
     $reasonoutput = "<B CLASS='red'>".$reason."</B>\n"
                    ."<P>\n";
   }
   
   $output = "<TABLE WIDTH=100% CELLPADDING=20 CELLSPACING=1 BORDER=0>\n"
            ."<TR><TD CLASS='BoardRowBody'>\n"
            ."        ".str_replace("\n", "\n        ", $reason.$output)."</TD></TR>\n"
            ."</TABLE>\n";
}
else
{
header("Location: ../noaccess.php");
}
   $pagecontents = $output;
   include("layout.php");
?>