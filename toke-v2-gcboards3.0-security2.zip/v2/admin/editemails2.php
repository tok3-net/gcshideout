<?php
   $starttime = microtime();
   $protectedpage = 1;
   $functionset   = "admin";
   include("common.php");
if (($_COOKIE['adminlogin'] != $userdata['adminpass']) || (!$userdata['adminpass'])) { header("Location: login.php"); }
if (!$_POST && $action == "save") { exit; }
   
   $navigation[] = array("name" => "Edit System Emails",
                         "url"  => "editemails.php");

if(checkAccess("accessadmin"))
{
$navigationhead = "Change Password";
  if(!$action)
{ 
$action = "edit"; 
}
  if($action == "edit")
{

    $emailsfile = "../templates/changepass.txt";
    $handle = fopen($emailsfile, "rb");
    $systememails = fread($handle, filesize($emailsfile));
    fclose($handle);
    
    if (false /* get_magic_quotes_gpc() removed in PHP8; always false since 5.4 */)
    {
      $systememails = stripSlashes($systememails);
    }
    include("../elements/adminemail.php");
    $output ="<table width=\"100%\" cellpadding=\"20\" cellspacing=\"1\" border=\"0\">\n"
            ."  <tr>\n"
            ."    <td class=\"BoardRowBody\">\n"
 	      ."    <form action=\"editemails2.php\" method=\"post\">\n"
            .inputHidden("action", "save")
	.inputHidden("emailsfile", $emailsfile)
            .$editemailsform
            ."    </form>\n"
            ."    </td>\n"
            ."  </tr>\n"
            ."</table>\n";
    

  }
  if($action == "save")
{
    if (false /* get_magic_quotes_gpc() removed in PHP8; always false since 5.4 */)
    {
      $systememails = stripSlashes($systememails);
    }
    $out = fopen($emailsfile, "w");
    if ($out === false)
    {
      $writefileerror = "Couldn't write to $emailsfile -- check its file permissions.";
    }
    else
    {
      fwrite($out, $systememails);
      fclose($out);
	$adminaction = "System Email Updated";
	$description = "System Email - ".$navigationhead." Successfully Updated";
       newAdminAction($adminaction, $description);
      $sysmsg = "custom";
      $sysmsgcustomcontent = "System Email - ".$navigationhead." Successfully Updated";
    }
    $action = "edit";

    
    $output ="<table width=\"100%\" cellpadding=\"20\" cellspacing=\"1\" border=\"0\">\n"
            ."  <tr>\n"
            ."    <td class=\"BoardRowBody\">\n"
            ."    <span class=\"InputSection\">System Email - ".$navigationhead.":</span><br><br>\n"
            .$systememails
            ."    </td>\n"
            ."  </tr>\n"
            ."</table>\n";
  }
}
else
{
header("Location: ../noaccess.php");
}

$pagecontents = $output;
include("layout.php");
?>