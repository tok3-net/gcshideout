<?php
   $starttime = microtime();
   $protectedpage = 1;
   $functionset   = "admin";
   include("common.php");
if (($_COOKIE['adminlogin'] != $userdata['adminpass']) || (!$userdata['adminpass'])) { header("Location: login.php"); }
if (!$_POST && $action == "savenote") { exit; }

if (checkAccess("accessmoderator"))
{     
       
    if (checkAccess("accessmanager"))
    {
       if ($step == "removenote")
       {
         $userinformation = fetchRow($userid, TABLE_USERS);
         $username = $userinformation['displayname'];

         $remove = removeAdminNote($noteid);
         if ($remove)
         {
           $step = "viewuser";
           $sysmsg = "custom";
           $sysmsgcustomcontent = "Note ".$noteid." has been removed";
	$adminaction = "User Note Removed";
	$description = "User Admin Note No. ".$noteid." Was Removed";
       newAdminAction($adminaction, $description);
         }
         else
         {
           $step = "newnote";
           $sysmsg = "custom";
           $sysmsgcustomcontent = "Note ".$noteid." couldn't be removed";
         }
       }
     }
       
       if ($step == "savenote")
       {
         $userinformation = fetchRow($userid, TABLE_USERS);
         $username = $userinformation['displayname'];

         $save = addAdminNote($userid, $userdata['ID'], $body);
	$adminaction = "User Note Saved";
	$description = "Note Added For: ".$username."";
       newAdminAction($adminaction, $description);
         if ($save)
         {
           $step = "viewuser";
           $sysmsg = "custom";
           $sysmsgcustomcontent = "Your note has been saved";
         }
         else
         {
           $step = "newnote";
           $sysmsg = "custom";
           $sysmsgcustomcontent = "Your note couldn't be saved";
         }
       }
       
       if ($step == "newnote")
       {
         $userinformation = fetchRow($userid, TABLE_USERS);

         $navigation[] = array("name" => $userinformation['displayname'],
                               "url"  => "$PHP_SELF?action=usernotes&step=viewuser&username=".$userinformation['displayname']);
         $navigationhead = "New Note";
         
         $pageformstart = "<FORM ACTION='".$PHP_SELF."' METHOD=POST>\n"
                         .inputHidden("action", $action)
                         .inputHidden("userid", $userid)
                         .inputHidden("step", "savenote");
         $pageformstop =  "</FORM>";
         $output = "Enter a new note for ".$userinformation['displayname']."<BR>\n"
                  .inputTextArea("body", $body, 45, 5, "", "", "", "linewrapfix")
                  ."<P>\n"
                  .inputSubmit("Save Note");
       }
       
       if ($step == "viewuser")
       {
         $userinformation = fetchRow($username, TABLE_USERS, "displayname", "idfieldistext", "dontcareifblank");
         $navigationhead = $userinformation['displayname'];
         
         if ($userinformation['ID'])
         {
           $areaoptions[] = array("name" => "Add Note For ".$userinformation['displayname'],
                                  "url"  => $PHP_SELF."?action=usernotes&step=newnote&userid=".$userinformation['ID']);
    
           $notes = fetchAdminNotes($userinformation['ID']);
           $output = $notes['html'];
           $nowrap = 1;
         }
         else
         {
           $step = "";
           $sysmsg = "custom";
           $sysmsgcustomcontent = "Unknown user";
           
         }
       }
       
       if (!$step)
       {
         $output = "<B>User Notes</B><BR>\n"
                  ."Enter the name of a user for whom to view notes.<BR>\n"
                  ."<FORM ACTION='$PHP_SELF' METHOD=POST>\n"
                  .inputHidden("action", $action)
                  .inputHidden("step", "viewuser")
                  .inputText("username", $username)
                  .inputSubmit("View")
                  ."</FORM>\n";
       }
     
}
else
{
header("Location: ../noaccess.php");
}

     $output = "<TABLE WIDTH=100% CELLPADDING=20 CELLSPACING=1 BORDER=0>\n"
              ."<TR><TD CLASS='BoardRowBody'>\n"
              ."        ".str_replace("\n", "\n        ", $output)."</TD></TR>\n"
              ."</TABLE>\n";
$pagecontents = $output;
include("layout.php");
?>