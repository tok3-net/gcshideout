<?php
   $starttime = microtime();
   $protectedpage = 1;
   $functionset   = "admin";
   include("common.php");
if (($_COOKIE['adminlogin'] != $userdata['adminpass']) || (!$userdata['adminpass'])) { header("Location: login.php"); }
if (!$_POST && $step == "2") { exit; }

if (checkAccess("accessvip"))
{


       $navigation[] = array("name" => "Daily System Stats",
                             "url"  => "$PHP_SELF?action=viewsessions&step=1");

       if (!$step) { $step = 1; }
       
       if ($step == 2)
       {
         $unixstart = mkTime(0, 0, 0, $frommonth, $fromday, $fromyear);
         $unixstop  = mkTime(23, 59, 59, $tomonth, $today, $toyear);
         
         $output = viewSessions ($unixstart, $unixstop);
	$adminaction = "Sessions Viewed";
	$description = "Sessions Viewed For ".dateNeat($unixstart)." To ".dateNeat($unixstop)."";
       newAdminAction($adminaction, $description);
         $nowrap = 1;
       }
       
       if ($step == 1)
       {
         $today = Date("U");
         $yesterday = (Date("U")-3600*24);
         
         $form = "<FORM ACTION='$PHP_SELF' METHOD=POST>\n"
                .inputHidden("action", "viewsessions")
                .inputHidden("step", "2")
                ."View sessions from \n"
                .inputDMYtext("from", Date("d", $yesterday), Date("m", $yesterday), Date("Y", $yesterday))
                ." to \n"
                .inputDMYtext("to", Date("d"), Date("m"), Date("Y"))
                .inputSubmit("Go")
                ."</FORM>\n";
          
          $output .= $form;
       }
}
else
{
header("Location: ../noaccess.php");
}

     $output = "<TABLE WIDTH=100% CELLPADDING=20 CELLSPACING=1 BORDER=0>\n"
              ."<TR><TD CLASS='BoardRowBody'>\n"
              ."        ".str_replace("\n", "\n        ", $output)."</TD></TR>\n"
              ."</TABLE>\n";
$pagecontents = $output;
include("layout.php");
?>