<?php
$boardfile = "admin/addcategory.php";
$adminfile = 1;
$protectedpage = 1;
include("common.php");
$title = "Add Category";
if (!$_POST && $action == "create") { exit; }

if (checkAccess("manager"))
{
  if ($action == "create")
  {
    $name = $_POST['name'];
    $rank = $_POST['rank'];
    $sql = "INSERT INTO ".$TableGroups." (name, rank) VALUES ('$name', '$rank')";
    $exe = runQuery($sql);
    if ($exe)
    {
      $adminaction = "New Category";
      $description = "The ".$name." category was added";
      newAdminAction($adminaction, $description);
      header("Location: intro.php?sysmsg=The+".$name."+category+was+successfully+created.");
    }
    else
    {
      $sysmsg = "An error occured, please try again.";
      $action = "";
    }
  }

  if (!$action || $action == "")
  {
    include("../elements/catform.php");
    $output = "<TABLE WIDTH=\"100%\" CELLPADDING=\"20\" CELLSPACING=\"1\" BORDER=\"0\">\n"
	."<TR>\n"
	."<TD CLASS=\"BoardRowB\" WIDTH=\"100%\">\n"
	."<FORM ACTION=\"addcategory.php\" METHOD=\"POST\" NAME=\"sbform\" onSubmit=\"disableSubmit()\">\n"
	."<SPAN CLASS=\"InputSection\">Add A Category</SPAN><BR>\n"
	."<SPAN CLASS=\"InputNotes\">Type a name and a rank for the category, below.  The higher the rank the higher up \n"
	."it will be on the category list. (1 is the highest.  z is the lowest.)</SPAN><P>\n"
	.$catform
	.inputSubmit("Create Group")."\n"
	.inputHidden("action", "create")."\n"
	."</FORM>\n"
	."</TD>\n"
	."</TR>\n"
	."</TABLE>\n";
  }
}
else
{
  header("Location: ../noaccess.php");
}

include("layout.php");
?>