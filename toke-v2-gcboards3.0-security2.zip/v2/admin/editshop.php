<?php
   $starttime = microtime();
   $protectedpage = 1;
   $functionset   = "admin";
   include("common.php");
if (($_COOKIE['adminlogin'] != $userdata['adminpass']) || (!$userdata['adminpass'])) { header("Location: login.php"); }
if (!$_POST && $action == "update") { exit; }
if (checkAccess("accessadmin"))
{
$navigationhead = "Edit Shop";

if ($action == "update")
{
$title = $_POST['title'];
$ownicon = $_POST['ownicon'];
$username = $_POST['username'];
$postcount = $_POST['postcount'];
$colors = $_POST['colors'];
$allowshoptitle = $_POST['allowshoptitle'];
$allowshopicon = $_POST['allowshopicon'];
$allowshopname = $_POST['allowshopname'];
$allowshoppost = $_POST['allowshoppost'];
$allowshopcolor = $_POST['allowshopcolor'];
$sql = "UPDATE ".TABLE_SETTINGS." SET titlechangeprice = '$title', owniconprice = '$ownicon', changenameprice = '$username', increasepostprice = '$postcount', colorsprice = '$colors', allowshoptitle = '$allowshoptitle', allowshopicon = '$allowshopicon', allowshopname = '$allowshopname', allowshoppost = '$allowshoppost', allowshopcolor = '$allowshopcolor' WHERE nothingkey = '1'";
if ($exe = runQuery($sql))
{
$adminaction = "Shop Updated";
$description = "The Shops Prices Were Updated";
newAdminAction($adminaction, $description);
$sysmsg = "custom";
$sysmsgcustomcontent = "The Prices Were Successfully Updated";
$action = "";
}
else
{
$sysmsg = "custom";
$sysmsgcustomcontent = "An error occured while trying to update the shop";
$action = "";
}
}

if (!$action)
{
$sql = "SELECT titlechangeprice, owniconprice, changenameprice, increasepostprice, colorsprice, allowshoptitle, allowshopicon, allowshopname, allowshoppost, allowshopcolor FROM ".TABLE_SETTINGS."";
$exe = runQuery($sql);
$row = fetchResultArray($exe);
if ($row['allowshoptitle']) { $checkedtitle = "CHECKED"; }
if ($row['allowshopicon']) { $checkedicon = "CHECKED"; }
if ($row['allowshopname']) { $checkedname = "CHECKED"; }
if ($row['allowshoppost']) { $checkedpost = "CHECKED"; }
if ($row['allowshopcolor']) { $checkedcolor = "CHECKED"; }

$output = "<FORM ACTION='".$PHP_SELF."' METHOD='POST'>"
	."<TABLE BORDER=1 CELLSPACING=1 CELLPADDING=3>"
	."<TR>"
	."<TD CLASS='BoardRowHeading' WIDTH=\"10\"><B><U>Allow</U></B></TD>"
	."<TD CLASS='BoardRowHeading' WIDTH=\"35\"><B><U>Item</U></B></TD>"
	."<TD CLASS='BoardRowHeading' WIDTH=\"35\"><B><U>Price</U></B></TD>"
	."</TR>"
	."<TR>"
	."<TD CLASS='BoardRowBody'><INPUT TYPE=\"CHECKBOX\" NAME=\"allowshoptitle\" VALUE=\"1\" ".$checkedtitle."></TD>"
	."<TD CLASS='BoardRowHeading'>Title Change</TD>"
	."<TD CLASS='BoardRowBody'>".inputText("title", $row['titlechangeprice'])."</TD>"
	."</TR>"
	."<TR>"
	."<TD CLASS='BoardRowBody'><INPUT TYPE=\"CHECKBOX\" NAME=\"allowshopicon\" VALUE=\"1\" ".$checkedicon."></TD>"
	."<TD CLASS='BoardRowHeading'>Own Icon</TD>"
	."<TD CLASS='BoardRowBody'>".inputText("ownicon", $row['owniconprice'])."</TD>"
	."</TR>"
	."<TR>"
	."<TD CLASS='BoardRowBody'><INPUT TYPE=\"CHECKBOX\" NAME=\"allowshopname\" VALUE=\"1\" ".$checkedname."></TD>"
	."<TD CLASS='BoardRowHeading'>Change Username</TD>"
	."<TD CLASS='BoardRowBody'>".inputText("username", $row['changenameprice'])."</TD>"
	."</TR>"
	."<TR>"
	."<TD CLASS='BoardRowBody'><INPUT TYPE=\"CHECKBOX\" NAME=\"allowshoppost\" VALUE=\"1\" ".$checkedpost."></TD>"
	."<TD CLASS='BoardRowHeading'>Increase Postcount</TD>"
	."<TD CLASS='BoardRowBody'>".inputText("postcount", $row['increasepostprice'])."</TD>"
	."</TR>"
	."<TR>"
	."<TD CLASS='BoardRowBody'><INPUT TYPE=\"CHECKBOX\" NAME=\"allowshopcolor\" VALUE=\"1\" ".$checkedcolor."></TD>"
	."<TD CLASS='BoardRowHeading'>Username Colors</TD>"
	."<TD CLASS='BoardRowBody'>".inputText("colors", $row['colorsprice'])."</TD>"
	."</TR>"
	."<TR>"
	."<TD CLASS='BoardRowBody' COLSPAN=\"3\">".inputHidden("action", "update")."".inputSubmit("Update Shop")."</TD>"
	."</TR>"
	."</TABLE>"
	."</FORM>";
}
}
else
{
header("Location: ../noaccess.php");
}

   $output = "<TABLE WIDTH=100% CELLPADDING=20 CELLSPACING=1 BORDER=0>\n"
            ."<TR><TD CLASS='BoardRowBody'>\n"
            ."        ".str_replace("\n", "\n        ", $output)."</TD></TR>\n"
            ."</TABLE>\n";
$pagecontents = $output;
include("layout.php");
?>