<?php
   $starttime = microtime();
   $protectedpage = 1;
   $functionset   = "admin";
   include("common.php");
if (($_COOKIE['adminlogin'] != $userdata['adminpass']) || (!$userdata['adminpass'])) { header("Location: login.php"); }
   
   $navigation[] = array("name" => "Edit System Emails",
                         "url"  => "editemails.php");

if(checkAccess("accessadmin"))
{
$output = "
	<TABLE BORDER=0 WIDTH=100% CLASS='BoardRowBody'><TR>
	<TD WIDTH=100%>
	<H1><U><B>System Email Templates</B></U></H1>
	<UL>
	<LI><A HREF='editemails1.php'>New User Email</A>
	<LI><A HREF='editemails2.php'>Change Password Email</A>
	<LI><A HREF='editemails3.php'>Recover Password Email</A>
	<LI><A HREF='editemails4.php'>Reset Password Email</A>
	<LI><A HREF='editemails5.php'>Ban Notification Email</A>
	</UL></TD></TR></TABLE>
	";
}
else
{
header("Location: ../noaccess.php");
}

$pagecontents = $output;
include("layout.php");
?>