<?php
$boardfile = "admin/editboard.php";
$protectedpage = 1;
$adminfile = 1;
include("common.php");
$title = "Edit Board";
if (!$_POST && $action == "editting") { exit; }

if (checkAccess("manager"))
{
  if ($action == "editting")
  {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $rank = $_POST['rank'];
    $groupid = $_POST['group'];
    $private = $_POST['private'];
    $privusers = $_POST['users'];
    $post = $_POST['post'];
    $poll = $_POST['poll'];
    $reply = $_POST['reply'];
    $boardid = $_POST['boardid'];
    $posti = $_POST['posti'];
    $dollari = $_POST['dollari'];
    $sql = "UPDATE ".$TableBoards." SET name = '$name', description = '$description', rank = '$rank', groupid = '$groupid', 
	private = '$private', users = '$privusers', post = '$post', poll = '$poll', reply = '$reply', posti = '$posti', dollari = '$dollari' WHERE ID = '$boardid' LIMIT 1";
    $exe = runQuery($sql);
    if ($exe)
    {
      $adminaction = "Board Edited";
      $description = "The ".$name." Board Was Updated";
      newAdminAction($adminaction, $description);
      header("Location: intro.php?sysmsg=The+".$name."+Board+Was+Successfully+Updated");
    }
    else
    {
      $sysmsg = "An error occured, please try again";
      $action = "";
    }
  }
  
  if ($action == "edit")
  {
    $boardid = $_POST['boardid'];
    $boardinfo = fetchRow($boardid, $TableBoards, "ID");
    $name = $boardinfo['name'];
    $description = $boardinfo['description'];
    $rank = $boardinfo['rank'];
    $groupid = $boardinfo['groupid'];
    $private = $boardinfo['private'];
    $users = $boardinfo['users'];
    $post = $boardinfo['post'];
    $poll = $boardinfo['poll'];
    $reply = $boardinfo['reply'];
    $posti = $boardinfo['posti'];
    $dollari = $boardinfo['dollari'];
    include("../elements/boardform.php");
    $output = "<table width=\"100%\" cellpadding=\"3\" cellspacing=\"1\" border=\"0\" class=\"MainTable\">\n"
	."<form action=\"editboard.php\" method=\"post\" name=\"sbform\" onSubmit=\"disableSubmit()\">\n"
	."<tr>\n"
	."<td width=\"50%\" class=\"BoardColumn\">Description</td>\n"
	."<td width=\"50%\" class=\"BoardColumn\">Permissions</td>\n"
	."</tr>\n"
	.$boardform
	."<tr>\n"
	."<td colspan=\"2\" align=\"center\" class=\"BoardRowB\">\n"
	.inputHidden("boardid", $boardid)."\n"
	.inputHidden("action", "editting")."\n"
	.inputSubmit("Edit Board")."\n"
	."</td></tr>\n"
	."</form>\n"
	."</table>\n";
    $makeneat = 1;
  }
  
  if (!$action || $action == "")
  {
    $sql = "SELECT ID FROM ".$TableGroups." ORDER BY rank ASC";
    $exe = runQuery($sql);
    while($row = fetchResult($exe))
    {
      $moresql = "SELECT ID, name FROM ".$TableBoards." WHERE groupid = '$row[ID]' ORDER BY rank ASC";
      $moreexe = runQuery($moresql);
      while ($morerow = fetchResult($moreexe))
      {
        $options .= "<option value=\"".$morerow['ID']."\">".$morerow['name']."</option>\n";
      }
    }
    $output = "<form action=\"editboard.php\" method=\"post\" name=\"sbform\" onSubmit=\"disableSubmit()\">\n"
	."<span class=\"InputSection\">Choose A Board To Edit:</span><br>\n"
	."<select name=\"boardid\">\n"
	.$options
	."</select><p>\n"
	.inputHidden("action", "edit")."\n"
	.inputSubmit("Next")."\n"
	."</form>\n";
  }
}
else
{
  header("Location: ../noaccess.php");
}

if (!$makeneat)
{
  $output = "<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"20\">\n"
	."<tr>\n"
	."<td class=\"BoardRowB\" width=\"100%\">\n"
	.$output
	."</td>\n"
	."</tr>\n"
	."</table>\n";
}
include("layout.php");
?>