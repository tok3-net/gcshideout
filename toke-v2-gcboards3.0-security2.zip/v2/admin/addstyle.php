<?php
$boardfile = "admin/addstyle.php";
$protectedpage = 1;
$adminfile = 1;
$title = "Add System Style";
include("common.php");
if (!$_POST && $action == "add") { exit; }
if (!$action) { $action = $_POST['action']; }

if (checkAccess("admin"))
{
  if ($action == "add")
  {
    $name = $_POST['name'];
    $content = $_POST['content'];
    $content = stripSlashes($content);
    if (file_exists("../stylesheets/".$name.".php")) { $reason = "That Style Already Exists, Please Pick A New Name"; }
    if (!$name) { $reason = "You Didn't Enter A Style Name"; }
    if (!$content) { $reason = "You Didn't Enter Any Style Content"; }
    if (!$reason)
    {
      $out = fopen("../stylesheets/".$name.".php", "x+");
      fwrite($out, $content);
      fclose($out);
      $filename = $name.".php";
      $sql = "INSERT INTO ".$TableStyles." (name, filename) VALUES ('$name', '$filename')";
      $exe = runQuery($sql);
      if ($exe)
      {
        $adminaction = "System Style Added";
        $description = "The ".$name." System Style Was Added";
        newAdminAction($adminaction, $description);
        $sysmsg = "The ".$name." System Style Was Successfully Added";
        $action = "";
      }
      else
      {
        $sysmsg = "An Error Occured, Please Try Again";
        $action = "";
      }
    }
    else
    {
      $sysmsg = $reason;
      $action = "";
    }
  }

  if (!$action)
  {
    include("../elements/styleform.php");
    $output = "<form action=\"addstyle.php\" method=\"post\" name=\"sbform\" onSubmit=\"disableSubmit()\">\n"
	."<table width=\"100%\" cellspacing=\"1\" cellpadding=\"3\" border=\"0\">\n"
	.$styleform
	."<tr><td class=\"BoardRowA\" colspan=\"2\" width=\"100%\">\n"
	.inputHidden("action", "add")."\n"
	.inputSubmit("Add Style")."\n"
	."</td></tr>\n"
	."</table>\n"
	."</form>\n";
  }
}
else
{
  header("Location: ../noaccess.php");
}

include("layout.php");
?>