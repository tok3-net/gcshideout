<?php
   $startime = microtime();
   $protectedpage = 1;
   $functionset   = "admin";
   include("common.php");
if (($_COOKIE['adminlogin'] != $userdata['adminpass']) || (!$userdata['adminpass'])) { header("Location: login.php"); }

if (checkAccess("accessmoderator"))
{
   $navigation[] = array("name" => "Admin Action Log",
                         "url"  => "actions.php");

if ($action == "searchdata")
{
  $filterid = $_POST['filterid'];
  $filterip = $_POST['filterip'];
  $filtertype = $_POST['filtertype'];
  if ($filterid)
  {
    $wherestuff = "adminid = '".$filterid."'";
  }
  elseif ($filterip)
  {
    $wherestuff = "ip = '".$filterip."'";
  }
  elseif ($filtertype)
  {
    $wherestuff = "action = '".$filtertype."'";
  }
  elseif ($filterid && $filterip)
  {
    $wherestuff = "adminid = '".$filterid."' AND ip = '".$filterip."'";
  }
  elseif ($filterid && $filtertype)
  {
    $wherestuff = "adminid = '".$filterid."' AND action = '".$filtertype."'";
  }
  elseif ($filterip && $filtertype)
  {
    $wherestuff = "ip = '".$filterip."' AND action = '".$filtertype."'";
  }
  elseif ($filterid && $filterip && $filtertype)
  {
    $wherestuff = "adminid = '".$filterid."' AND ip = '".$filterip."' AND action = '".$filtertype."'";
  }
  else
  {
    $sysmsg = "custom";
    $sysmsgcustomcontent = "You Didnt Enter Any Filter Info";
    $action = "search";
  }

  $sql = "SELECT * FROM ".TABLE_ADMIN_ACTION_LOG." WHERE ".$wherestuff."";
  $exe = runQuery($sql);
  $output = "<table width='100%' cellspacing='1' cellpadding='3' class='BoardRowBody' border=1 STYLE=\"border-collapse: collapse;\">\n"
         ."<tr><td colspan=5 class='BoardRowHeading'>\n"
         ."<a href='actions.php' class='MainMenuLink'>View Actions</a><b> | </b><a href='actions.php?action=search' class='MainMenuLink'>Filter</a>\n"
         ."</td></tr>"
         ."  <tr>\n"
         ."    <td class='BoardColumn'>Admin</td>\n"
         ."    <td class='BoardColumn'>IP Address</td>\n"
         ."    <td class='BoardColumn'>Action Type</td>\n"
         ."    <td class='BoardColumn'>Description</td>\n"
         ."    <td class='BoardColumn'>Date Performed</td>\n"
         ."  </tr>";
  while ($row = fetchResultArray($exe))
  {
      $adminuserlink = usernameDisplay($row['adminid'], "", "", "", "admin");
      $output .= "  <tr>\n"
              ."    <td class='BoardRowBody'>".$adminuserlink."</td>\n"
	."    <td class='BoardRowBody'>".$row['ip']."</td>\n"
              ."    <td class='BoardRowBody'>".$row['action']."</td>\n"
              ."    <td class='BoardRowBody'><SPAN CLASS='InputNotes'>".$row['description']."</SPAN></td>\n"
              ."    <td class='BoardRowBody'>".dateNeat($row['date'])."</td>\n"
              ."  </tr>\n";
  }
}

if ($action == "search")
{
  $output = "<TABLE BORDER=0 WIDTH=100% CELLSPACING=1 CELLPADDING=3>"
	  ."<TR><TD CLASS=\"BoardRowBody\" WIDTH=\"100%\">"
	  ."<FORM ACTION='".$PHP_SELF."' METHOD=\"POST\">"
	  ."<SPAN CLASS='InputSection'>Filter By Admin User ID:</SPAN><BR>"
	  .inputText('filterid', $filterid, 10, 100)."<BR><BR>"
	  ."<SPAN CLASS='InputSection'>Filter By IP Address:</SPAN><BR>"
	  .inputText('filterip', $filterip, 15, 100)."<BR><BR>"
	  ."<SPAN CLASS='InputSection'>Filter By Action Type:</SPAN><BR>"
	  .inputText('filtertype', $filtertype, 20, 100)."<BR><BR>"
	  .inputHidden("action", "searchdata")
	  .inputSubmit("Filter")
	  ."</FORM>"
	  ."</TD></TR>";
}

if ($action == "del")
{
if (checkAccess("accessadmin"))
{
$sql = "DELETE FROM ".TABLE_ADMIN_ACTION_LOG."";
$exe = runQuery($sql);
}
else
{
Header("Location: ../noaccess.php");
}
if ($exe)
{
       $sysmsg = "custom";
       $sysmsgcustomcontent = "The Admin Action Log Was Successfully Cleared";
	$adminaction = "Log Cleared";
	$description = "The Admin Action Log Was Cleared";
       newAdminAction($adminaction, $description);
	$action = "";
}
else
{
       $sysmsg = "custom";
       $sysmsgcustomcontent = "There Was An Error And The Action Log Couldn't Be Cleared";
}
}
   
if (!$action || $action == "")
{
$output .= "<table width='100%' cellspacing='1' cellpadding='3' class='BoardRowBody' border=1 STYLE=\"border-collapse: collapse;\">\n"
	."<tr><td colspan=5 class='BoardRowHeading'>";
if (checkAccess("accessadmin"))
{
$output .= "<a href='actions.php?action=del' class='MainMenuLink'>Delete Action Log</a><b> | </b>";
}
if (!$limit || $limit == "fifty")
{
$output .= "<a href='actions.php?limit=none' class='MainMenuLink'>View All Actions</a>";
}
if ($limit == "none")
{
$output .= "<a href='actions.php?limit=fifty' class='MainMenuLink'>View Last 50 Actions</a>";
}
$output .= "<b> | </b><a href='actions.php?action=search' class='MainMenuLink'>Filter Actions</a>";
$output .= "</td></tr>"
         ."  <tr>\n"
         ."    <td class='BoardColumn'>Admin</td>\n"
         ."    <td class='BoardColumn'>IP Address</td>\n"
         ."    <td class='BoardColumn'>Action Type</td>\n"
         ."    <td class='BoardColumn'>Description</td>\n"
         ."    <td class='BoardColumn'>Date Performed</td>\n"
         ."  </tr>";

if (!$limit || $limit == "fifty")
{
$sql = "SELECT * FROM ".TABLE_ADMIN_ACTION_LOG." "
      ."ORDER BY date DESC LIMIT 0,50";
}
if ($limit == "none")
{
$sql = "SELECT * FROM ".TABLE_ADMIN_ACTION_LOG." "
      ."ORDER BY date DESC ";
}

if ($exe = runQuery($sql))
{
while ($row = fetchResultArray($exe))
{
      $adminuserlink = usernameDisplay($row['adminid'], "", "", "", "admin");
      $output .= "  <tr>\n"
              ."    <td class='BoardRowBody'>".$adminuserlink."</td>\n"
	."    <td class='BoardRowBody'>".$row['ip']."</td>\n"
              ."    <td class='BoardRowBody'>".$row['action']."</td>\n"
              ."    <td class='BoardRowBody'><SPAN CLASS='InputNotes'>".$row['description']."</SPAN></td>\n"
              ."    <td class='BoardRowBody'>".dateNeat($row['date'])."</td>\n"
              ."  </tr>\n";
}
}
}
$output .= "</table>";
}
else
{
Header("Location: ../noaccess.php");
}

   $pagecontents = $output;
   include("layout.php");
?>