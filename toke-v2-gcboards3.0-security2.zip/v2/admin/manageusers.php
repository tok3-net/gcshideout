<?php
   $starttime = microtime();
   $protectedpage = 1;
   $functionset   = "admin";
   include("common.php");
if (($_COOKIE['adminlogin'] != $userdata['adminpass']) || (!$userdata['adminpass'])) { header("Location: login.php"); }
if ($step == "3" && !$_POST) { exit; }

if (checkAccess("accessadmin"))
{

       $navigation[] = array("name" => "User Management",
                             "url"  => "$PHP_SELF?action=manageusers&step=1");

       if (!$step) { $step = 1; }
       
       if ($step == 3)
       {
         $navigationhead = "Change User Access";

         // Figure out the new classid for these users
         $classid = str_replace("class", "", $change);
  
         for ($i = 1; $i <= $checkboxcount; $i++ )
         {
           $var = "user".$i;
           
           if ($$var)
           {
             $updateuserid = $$var;
             
             // Fetch the information for the class we're putting this user
             // in - we need this so we can copy the nameformat element over
             $classdata = fetchRow($classid, TABLE_ACCESS_CLASS);
             
             $data['classid'] = $classid;
             $data['displayformat'] = $classdata['nameformat']; // The new access class' default format
             
             $update = updateUser($updateuserid, $data);
           }
         }
 	$adminaction = "User Rights Updated";
	$description = "User Rights Updated For User ID: ".$updateuserid."";
       newAdminAction($adminaction, $description);        
         $sysmsgcustom = "custom";
         $sysmsgcustomcontent = "Your requested changes have been made";
         $step = 1;
       }
       
       if ($step == 2)
       {
         $navigationhead = "User Search Results";
         if ($classid)
         { 
           $options['classid'] = $classid;
         }
         
         if (!is_array($options))
         {
           if (!trim($searchuser)) { $err[] = "No username to match!"; }
         }
         
         if ($err)
         {
           $reason = implode("<BR>\n", $err);
         }
         else
         {
           $searchresults = listUsers($searchuser, "admin", $options);
           
           if ($$searchresults['resultcnt']) 
           {
             $sysmsgcustom = "custom";
             $sysmsgcustomcontent = "No users were found"; 
             $step = 1;
           }
           else
           {
             $nowrap = 1;
             $searchresults['usertable'] = str_replace("BUTTON", inputSubmit("Modify Users"), $searchresults['usertable']);
             $pageformstart = "<FORM ACTION='$PHP_SELF' METHOD=POST>\n" 
                             .inputHidden("action", "manageusers")
                             .inputHidden("checkboxcount", $searchresults['checkboxcount'])
                             .inputHidden("step", 3);
             $output = $searchresults['usertable'];
             $pageformstop = "</FORM>\n";
           }
         }
       }
       
       if ($step == 1)
       {
         $navigationhead = "User Search";
         
         $usercount = countUsers();
         
         for ($i = 0; $i < count($usercount); $i++ )
         {
           $userinforow .= "<TR><TD><A HREF='$PHP_SELF?action=manageusers&step=2&classid=".$usercount[$i]['classid']."'>".$usercount[$i]['classname']."</A></TD>\n"
                          ."    <TD>".$usercount[$i]['usercount']."</TD></TR>\n";
           $totalusercount = $totalusercount + $usercount[$i]['usercount'];
         }
         $userinfotable = "<TABLE>\n"
                         .$userinforow
                         ."<TR><TD><B>Total</B></TD>\n"
                         ."    <TD><B>".$totalusercount."</B></TD></TR>\n"
                         ."</TABLE>\n";
         
         include("../elements/listusers.php");
         $output = "<TABLE WIDTH=100%>\n"
                  ."<TR VALIGN=TOP>\n"
                  ."    <TD WIDTH=75%>\n"
                  ."        <FORM ACTION='$PHP_SELF' METHOD=POST>\n"
                  ."        ".inputHidden("action", "manageusers")
                  ."        ".inputHidden("step", 2)
                  ."        ".str_replace("\n", "        ", $searchform)
                  ."        ".inputSubmit("Search")
                  ."        </FORM></TD>\n"
                  ."    <TD WIDTH=25%>\n"
                  .$userinfotable
                  ."        </TD></TR>\n"
                  ."</TABLE>\n";
         
       }
}
else
{
header("Location: ../noaccess.php");
}

     $output = "<TABLE WIDTH=100% CELLPADDING=20 CELLSPACING=1 BORDER=0>\n"
              ."<TR><TD CLASS='BoardRowBody'>\n"
              ."        ".str_replace("\n", "\n        ", $output)."</TD></TR>\n"
              ."</TABLE>\n";
$pagecontents = $output;
include("layout.php");
?>