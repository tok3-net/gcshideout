<?php
   $starttime = microtime();
   $protectedpage = 1;
   $functionset   = "admin";
   include("common.php");
if (($_COOKIE['adminlogin'] != $userdata['adminpass']) || (!$userdata['adminpass'])) { header("Location: login.php"); }
if (!$_POST && $action == "remove") { exit; }

   $navigation[] = array("name" => "Remove Users Posts",
                         "url"  => $PHP_SELF);

if (checkAccess("accessmoderator"))
{
  if ($action == "remove")
  {
    $userid = $_POST['userid'];
    $sql = "DELETE FROM ".TABLE_POSTS." WHERE authorid = '".$userid."';";
    if ($exe = runQuery($sql))
    {
      $adminaction = "Remove Posts";
      $admindescription = "Posts for ".$userid." have been removed";
      newAdminAction($adminaction, $admindescription);
      $sysmsg = "custom";
      $sysmsgcustomcontent = "All posts for ".$userid." were successfully removed";
      $action = "";
    }
    else
    {
      $sysmsg = "custom";
      $sysmsgcustomcontent = "There was an error please try again";
      $action = "";
    }
  }

  if (!$action || $action == "")
  {
    $output = "<FORM ACTION='".$PHP_SELF."' METHOD='POST'>"
	    ."<B>Enter The User ID Of The User's Posts You Would Like To Get Rid Of Below:</B><BR>"
	    ."<SPAN CLASS='InputNotes'>If this user has the last post in <B>ANY</B> board that board will "
	    ."mess up and you won't be able to see it, so make sure that the user doesn't have the last post in any board.  "
	    ."The users posts will still be counted in topics, but when you go to view them they just wont be there.</SPAN><BR>"
	    ."<B>User ID: </B><INPUT TYPE='TEXT' NAME='userid' VALUE='$userid'><BR>"
	    ."<INPUT TYPE='HIDDEN' NAME='action' VALUE='remove'>"
	    ."<INPUT TYPE='SUBMIT' VALUE='Remove Posts'>"
	    ."</FORM>"
	    ."";
  }
}
else
{
header("Location: ../noaccess.php");
}
   

     $output = "<TABLE WIDTH=100% CELLPADDING=20 CELLSPACING=1 BORDER=0>\n"
              ."<TR><TD CLASS='BoardRowBody'>\n"
              ."        ".str_replace("\n", "\n        ", $output)."</TD></TR>\n"
              ."</TABLE>\n";   

   $pagecontents = $output;
   include("layout.php");
?>