<?php
   $protectedpage = 1;
   $functionset   = "admin";
   include("common.php");
if (($_COOKIE['adminlogin'] != $userdata['adminpass']) || (!$userdata['adminpass'])) { header("Location: login.php"); }
if (!$_POST && $action == "save") { exit; }
   
   $navigation[] = array("name" => "Edit TOS",
                         "url"  => "admin-edittos.php");

if(checkAccess("accessadmin"))
{
  if(!$action)
{ 
$action = "edit"; 
}
  if($action == "edit")
{
    $tosfile = "../elements/tos.txt";
    $handle = fopen($tosfile, "rb");
    $termsofservice = fread($handle, filesize($tosfile));
    fclose($handle);
    
    if (false /* get_magic_quotes_gpc() removed in PHP8; always false since 5.4 */)
    {
      $termsofservice = stripSlashes($termsofservice);
    }
    include("../elements/admintos.php");
    $output ="<table width=\"100%\" cellpadding=\"20\" cellspacing=\"1\" border=\"0\">\n"
            ."  <tr>\n"
            ."    <td class=\"BoardRowBody\">\n"
 	      ."    <form action=\"edittos.php\" method=\"post\">\n"
            .inputHidden("action", "save")
            .$edittosform
            ."    </form>\n"
            ."    </td>\n"
            ."  </tr>\n"
            ."</table>\n";
    

  }
  if($action == "save")
{
    if (false /* get_magic_quotes_gpc() removed in PHP8; always false since 5.4 */)
    {
      $termsofservice = stripSlashes($termsofservice);
    }
    $out = fopen("../elements/tos.txt", "w");
    if ($out === false)
    {
      $writefileerror = "Couldn't write to elements/tos.txt -- check its file permissions.";
    }
    else
    {
      fwrite($out, $termsofservice);
      fclose($out);
	$adminaction = "TOS Updated";
	$description = "System TOS Updated";
       newAdminAction($adminaction, $description);
    }
    $action = "edit";
    $sysmsg = "custom";
    $sysmsgcustomcontent = "TOS Updated";
    
    $action = "edit";
    $description = "Terms of Service updated";
    
    $output ="<table width=\"100%\" cellpadding=\"20\" cellspacing=\"1\" border=\"0\">\n"
            ."  <tr>\n"
            ."    <td class=\"BoardRowBody\">\n"
            ."    <span class=\"InputSection\">Terms of Service:</span><br><br>\n"
            .$termsofservice
            ."    </td>\n"
            ."  </tr>\n"
            ."</table>\n";
  }
}
else
{
header("Location: ../noaccess.php");
}

$pagecontents = $output;
include("layout.php");
?>