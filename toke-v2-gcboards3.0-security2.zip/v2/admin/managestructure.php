<?php
   $starttime = microtime();
   $protectedpage = 1;
   $functionset   = "admin";
   include("common.php");
if (($_COOKIE['adminlogin'] != $userdata['adminpass']) || (!$userdata['adminpass'])) { header("Location: login.php"); }
if (($step == "reallyremove" || $step == "reallyremoveboard" || $step == "saveboard" || $step == "3") && (!$_POST)) { exit; }

if (checkAccess("accessmanager"))
{
     if ($action == "managestructure" || !$action)
     {
       $navigation[] = array("name" => "Board Structure",
                             "url"  => "$PHP_SELF?action=managestructure&step=1");

       if (!$step) { $step = 1; }
       
       if ($step == "reallyremove")
       {
         $navigationhead = "Group Removal";
         
         $groupdata = fetchRow($groupid, TABLE_GROUPS);

         $remove = removeGroup($groupid);
         if ($remove)
         {
	$adminaction = "Board Group Removed";
	$description = "".$groupdata['groupname']." Category Was Deleted";
       newAdminAction($adminaction, $description);
           $sysmsgcustom = "custom";
           $sysmsgcustomcontent = "The group <I>".$groupdata['groupname']."</I> has been removed.";
         }
         else
         {
           $sysmsgcustom = "custom";
           $sysmsgcustomcontent = "The group <I>".$groupdata['groupname']."</I> could not be removed.";
         }
         $step = 1;
       }
       
       if ($step == "remove")
       {
         $navigationhead = "Group Removal";

         // Remove a group. Confirm that they want to remove it.
         $groupdata = fetchRow($groupid, TABLE_GROUPS);
         
         $output = "<FORM ACTION='$PHP_SELF' METHOD=POST>\n"
                  .inputHidden("action", "managestructure")
                  .inputHidden("step", "reallyremove")
                  .inputHidden("groupid", $groupid)
                  ."<B CLASS='red'>IMPORTANT</B>\n"
                  ."<P>\n"
                  ."Please confirm that you want to delete <B>".$groupdata['groupname']."</B>\n"
                  ."<P>\n"
                  .inputCheckbox("confirm", 1, $confirm)." Confirm removal\n"
                  ."<P>\n"
                  .inputSubmit("Continue")
                  ."</FORM>\n";
       }

       if ($step == "reallyremoveboard")
       {
         $navigationhead = "Board Removal";
         
         $boarddata = fetchRow($boardid, TABLE_BOARDS);

         $remove = removeBoard($boardid);
         if ($remove)
         {
	$adminaction = "Board Deleted";
	$description = "".$boarddata['boardname']." Board Was Deleted";
       newAdminAction($adminaction, $description);
           $sysmsg = "custom";
           $sysmsgcustomcontent = "The board <I>".$boarddata['boardname']."</I> has been removed.";
         }
         else
         {
           $sysmsg = "custom";
           $sysmsgcustomcontent = "The board <I>".$boarddata['boardname']."</I> could not be removed.";
         }
         $step = 1;
       }
       
       if ($step == "removeboard")
       {
         $navigationhead = "Board Removal";

         // Remove a board. Confirm that they want to remove it.
         $boarddata = fetchRow($boardid, TABLE_BOARDS);
         
         $output = "<FORM ACTION='$PHP_SELF' METHOD=POST>\n"
                  .inputHidden("action", "managestructure")
                  .inputHidden("step", "reallyremoveboard")
                  .inputHidden("boardid", $boardid)
                  ."<B CLASS='red'>IMPORTANT</B>\n"
                  ."<P>\n"
                  ."Please confirm that you want to delete <B>".$boarddata['boardname']."</B>\n"
                  ."<P>\n"
                  .inputCheckbox("confirm", 1, $confirm)." Confirm removal\n"
                  ."<P>\n"
                  .inputSubmit("Continue")
                  ."</FORM>\n";
       }

       if ($step == "saveboard")
       {
         $navigationhead = "Board Management";

         if (!trim($boardname)) { $err[] = "No board name was entered"; }
         
         if ($err)
         {
           $reason = implode("<BR>\n", $err);
           $step = "editboard";
         }
         else
         {
           if ($boardid)
           {
             $boardstuff = updateBoardData($boardid, $boardname, $boardrank, $boarddescription, $boardgroupid, $boardvippost, $boardprivate, $boardprivateusers);
	$adminaction = "Board Updated";
	$description = "".$boardname." Board Was Updated";
       newAdminAction($adminaction, $description);
           }
           else
           {
             $boardstuff = newBoard($groupid, $boardname, $boardrank, $boarddescription, $boardvippost, $boardprivate, $boardprivateusers);
	$adminaction = "New Board";
	$description = "".$boardname." Board Was Created";
       newAdminAction($adminaction, $description);
           }
           
           if ($boardstuff)
           {
             $sysmsg = "custom";
             $sysmsgcustomcontent = "Your requested change has been performed";
           }
           else
           {
             $sysmsgcustom = "custom";
             $sysmsgcustomcontent = "Your requested change was not performed";
           }
           $step = 1;
         }
       }
       
       if ($step == "editboard")
       {
         $navigationhead = "Board Details";

         $submitbutton = "Create Board";
         $intro        = "Enter the information below to create a new Board";
         if ($boardid)
         {
           $submitbutton = "Update Board";
           $intro        = "Update the information below to change this Board";
         }
          
         if (($boardid) && (!$err))
         {
           $boarddata = fetchRow($boardid, TABLE_BOARDS);
           $boardname        = $boarddata['boardname'];
           $boardrank        = $boarddata['boardrank'];
           $boarddescription = $boarddata['description'];
           $boardgroupid     = $boarddata['groupid'];
           $boardvippost     = $boarddata['vippost'];
           $boardprivate     = $boarddata['private'];
           $boardprivateusers  = $boarddata['privateusers'];
         }
         
         include("../elements/boardedit.php");
         $output = $intro
                  ."<FORM ACTION='$PHP_SELF' METHOD=POST>\n"
                  .inputHidden("action", "managestructure")
                  .inputHidden("step", "saveboard")
                  .inputHidden("boardid", $boardid)
                  .inputHidden("groupid", $groupid)
                  .$boardform
                  .inputSubmit($submitbutton)
                  ."</FORM>\n";
         
       }
       
       if ($step == 3)
       {
         $navigationhead = "Group Management";

         if (!trim($groupname)) { $err[] = "No group name was entered"; }
         
         if ($err)
         {
           $reason = implode("<BR>\n", $err);
           $step = 2;
         }
         else
         {
           if ($groupid)
           {
             $groupstuff = updateGroupData($groupid, $groupname, $grouprank);
	$adminaction = "Board Group Updated";
	$description = "".$groupname." Category Was Updated";
       newAdminAction($adminaction, $description);
           }
           else
           {
             $groupstuff = newGroup($groupname);
	$adminaction = "New Board Group";
	$description = "".$groupname." Category Was Added";
       newAdminAction($adminaction, $description);
           }
           
           if ($groupstuff)
           {
             $sysmsgcustom = "custom";
             $sysmsgcustomcontent = "Your requested change has been performed";
           }
           else
           {
             $sysmsgcustom = "custom";
             $sysmsgcustomcontent = "Your requested change was not performed";
           }
           $step = 1;
         }
       }
       
       if ($step == 2)
       {
         $navigationhead = "Group Details";

         $submitbutton = "Create Group";
         $intro        = "Enter the information below to create a new Group";
         if ($groupid)
         {
           $submitbutton = "Update Group";
           $intro        = "Update the information below to change this Group";
         }
          
         if (($groupid) && (!$err))
         {
           $groupdata = fetchRow($groupid, TABLE_GROUPS);
           $groupname = $groupdata['groupname'];
           $grouprank = $groupdata['grouprank'];
         }
         
         include("../elements/groupedit.php");
         $output = $intro
                  ."<FORM ACTION='$PHP_SELF' METHOD=POST>\n"
                  .inputHidden("action", "managestructure")
                  .inputHidden("step", 3)
                  .inputHidden("groupid", $groupid)
                  .$groupform
                  .inputSubmit($submitbutton)
                  ."</FORM>\n";
       }
       
       if ($step == 1)
       {
         $navigationhead = "Board Setup";

         $areaoptions[] = array("name" => "Create a New Group",
                                "url"  => $PHP_SELF."?action=managestructure&step=2");
         
         $groups = listGroups("admin", "all");
         
         $output = $groups;
         $nowrap = 1;
       }
   }
}
else
{
header("Location: ../noaccess.php");
}

     $output = "<TABLE WIDTH=100% CELLPADDING=20 CELLSPACING=1 BORDER=0>\n"
              ."<TR><TD CLASS='BoardRowBody'>\n"
              ."        ".str_replace("\n", "\n        ", $output)."</TD></TR>\n"
              ."</TABLE>\n";
$pagecontents = $output;
include("layout.php");
?>