<?php
$starttime = microtime();
$protectedpage = 1;
$functionset = "admin";
include("common.php");
if (($_COOKIE['adminlogin'] != $userdata['adminpass']) || (!$userdata['adminpass'])) { header("Location: login.php"); }
if (!$_POST && $action == "save") { exit; }
$navigationhead = "Edit Users Profile";

if (checkAccess("accessmanager"))
{
if ($action == "save")
{
$data['displayname'] = $_POST['displayname'];
$data['displayformat'] = $_POST['displayformat'];
$data['fname'] = $_POST['fname'];
$data['sname'] = $_POST['sname'];
$data['iconid'] = $_POST['iconid'];
$data['ownicon'] = $_POST['ownicon'];
$data['title'] = $_POST['title'];
$data['profiletitle'] = $_POST['profiletitle'];
$data['postcount'] = $_POST['postcount'];
$data['dollars'] = $_POST['dollars'];
$data['company'] = $_POST['company'];
$data['jobtitle'] = $_POST['jobtitle'];
$data['picurl'] = $_POST['picurl'];
$data['wwwurl'] = $_POST['wwwurl'];
$data['color'] = $_POST['color'];
$data['shoptitle'] = $_POST['shoptitle'];
$data['namechange'] = $_POST['namechange'];
$data['chooseicon'] = $_POST['chooseicon'];
$data['contactemail'] = $_POST['contactemail'];
$data['contacticq'] = $_POST['contacticq'];
$data['contactmsn'] = $_POST['contactmsn'];
$data['contactaim'] = $_POST['contactaim'];
$data['contactyahoo'] = $_POST['contactyahoo'];
$data['sig1'] = $_POST['sig1'];
$data['sig2'] = $_POST['sig2'];
$data['sig3'] = $_POST['sig3'];
$data['sig4'] = $_POST['sig4'];
$data['sig5'] = $_POST['sig5'];
$data['bio'] = $_POST['bio'];
$data['created'] = $_POST['created'];
$update = updateUser($userid, $data, "no");
if ($update)
{
	$adminaction = "Profile Editted";
	$description = "Profile For ".$data['displayname']." Was Editted";
       newAdminAction($adminaction, $description);
  $sysmsg = "custom";
  $sysmsgcustomcontent = "Profile For ".$data['displayname']." Was Successfully Updated";
  $action = "";
}
else
{
  $sysmsg = "custom";
  $sysmsgcustomcontent = "An Error Occured, Please Try Again";
  $action = "";
}
}

if ($action == "edit")
{
  $username = $_POST['username'];
  $userinformation = fetchRow($username, TABLE_USERS, "displayname", "idfieldistext", "dontcareifblank");
  if ($userinformation['ID'])
  {
    $userinfo = getUserInformation($userinformation['ID']);
    $output = "<FORM ACTION='".$PHP_SELF."' METHOD=\"POST\">"
	."<TABLE WIDTH=100% CELLSPACING=1 CELLPADDING=3 BORDER=1 STYLE=\"border-collapse: collapse;\">"
	."<TR><TD CLASS='BoardRowHeading'>Username</TD>"
	."<TD CLASS='BoardRowBody'>".inputText("displayname", $userinfo['displayname'])."</TD></TR>"
	."<TR><TD CLASS='BoardRowHeading'>Display Format</TD>"
	."<TD CLASS='BoardRowBody'>".inputText("displayformat", $userinfo['displayformat'])."</TD></TR>"
	."<TR><TD CLASS='BoardRowHeading'>Date Registered</TD>"
	."<TD CLASS='BoardRowBody'>".inputText("created", $userinfo['created'])."</TD></TR>"
	."<TR><TD CLASS='BoardRowHeading'>First Name</TD>"
	."<TD CLASS='BoardRowBody'>".inputText("fname", $userinfo['fname'])."</TD></TR>"
	."<TR><TD CLASS='BoardRowHeading'>Last Name</TD>"
	."<TD CLASS='BoardRowBody'>".inputText("sname", $userinfo['sname'])."</TD></TR>"
	."<TR><TD CLASS='BoardRowHeading'>Icon ID</TD>"
	."<TD CLASS='BoardRowBody'>".inputText("iconid", $userinfo['iconid'])."</TD></TR>"
	."<TR><TD CLASS='BoardRowHeading'>Own Icon URL</TD>"
	."<TD CLASS='BoardRowBody'>".inputText("ownicon", $userinfo['ownicon'])."</TD></TR>"
	."<TR><TD CLASS='BoardRowHeading'>Title</TD>"
	."<TD CLASS='BoardRowBody'>".inputText("title", $userinfo['title'])."</TD></TR>"
	."<TR><TD CLASS='BoardRowHeading'>Profile Title</TD>"
	."<TD CLASS='BoardRowBody'>".inputText("profiletitle", $userinfo['profiletitle'])."</TD></TR>"
	."<TR><TD CLASS='BoardRowHeading'>Postcount</TD>"
	."<TD CLASS='BoardRowBody'>".inputText("postcount", $userinfo['postcount'])."</TD></TR>"
	."<TR><TD CLASS='BoardRowHeading'>Dollars</TD>"
	."<TD CLASS='BoardRowBody'>".inputText("dollars", $userinfo['dollars'])."</TD></TR>"
	."<TR><TD CLASS='BoardRowHeading'>Company</TD>"
	."<TD CLASS='BoardRowBody'>".inputText("company", $userinfo['company'])."</TD></TR>"
	."<TR><TD CLASS='BoardRowHeading'>Job Title</TD>"
	."<TD CLASS='BoardRowBody'>".inputText("jobtitle", $userinfo['jobtitle'])."</TD></TR>"
	."<TR><TD CLASS='BoardRowHeading'>Picture URL</TD>"
	."<TD CLASS='BoardRowBody'>".inputText("picurl", $userinfo['picurl'])."</TD></TR>"
	."<TR><TD CLASS='BoardRowHeading'>Website</TD>"
	."<TD CLASS='BoardRowBody'>".inputText("wwwurl", $userinfo['wwwurl'])."</TD></TR>"
	."<TR><TD CLASS='BoardRowHeading'>Shop Colors</TD>"
	."<TD CLASS='BoardRowBody'>".inputText("color", $userinfo['color'])."</TD></TR>"
	."<TR><TD CLASS='BoardRowHeading'>Shop Title</TD>"
	."<TD CLASS='BoardRowBody'>".inputText("shoptitle", $userinfo['shoptitle'])."</TD></TR>"
	."<TR><TD CLASS='BoardRowHeading'>Shop Name Change</TD>"
	."<TD CLASS='BoardRowBody'>".inputText("namechange", $userinfo['namechange'])."</TD></TR>"
	."<TR><TD CLASS='BoardRowHeading'>Shop Choose Own Icon</TD>"
	."<TD CLASS='BoardRowBody'>".inputText("chooseicon", $userinfo['chooseicon'])."</TD></TR>"
	."<TR><TD CLASS='BoardRowHeading'>Email</TD>"
	."<TD CLASS='BoardRowBody'>".inputText("contactemail", $userinfo['contactemail'])."</TD></TR>"
	."<TR><TD CLASS='BoardRowHeading'>ICQ</TD>"
	."<TD CLASS='BoardRowBody'>".inputText("contacticq", $userinfo['contacticq'])."</TD></TR>"
	."<TR><TD CLASS='BoardRowHeading'>MSN</TD>"
	."<TD CLASS='BoardRowBody'>".inputText("contactmsn", $userinfo['contactmsn'])."</TD></TR>"
	."<TR><TD CLASS='BoardRowHeading'>AIM</TD>"
	."<TD CLASS='BoardRowBody'>".inputText("contactaim", $userinfo['contactaim'])."</TD></TR>"
	."<TR><TD CLASS='BoardRowHeading'>Yahoo</TD>"
	."<TD CLASS='BoardRowBody'>".inputText("contactyahoo", $userinfo['contactyahoo'])."</TD></TR>"
	."<TR><TD CLASS='BoardRowHeading'>Sig Line 1</TD>"
	."<TD CLASS='BoardRowBody'>".inputText("sig1", $userinfo['sig1'])."</TD></TR>"
	."<TR><TD CLASS='BoardRowHeading'>Sig Line 2</TD>"
	."<TD CLASS='BoardRowBody'>".inputText("sig2", $userinfo['sig2'])."</TD></TR>"
	."<TR><TD CLASS='BoardRowHeading'>Sig Line 3</TD>"
	."<TD CLASS='BoardRowBody'>".inputText("sig3", $userinfo['sig3'])."</TD></TR>"
	."<TR><TD CLASS='BoardRowHeading'>Sig Line 4</TD>"
	."<TD CLASS='BoardRowBody'>".inputText("sig4", $userinfo['sig4'])."</TD></TR>"
	."<TR><TD CLASS='BoardRowHeading'>Sig Line 5</TD>"
	."<TD CLASS='BoardRowBody'>".inputText("sig5", $userinfo['sig5'])."</TD></TR>"
	."<TR><TD CLASS='BoardRowHeading'>Bio</TD>"
	."<TD CLASS='BoardRowBody'><TEXTAREA NAME='bio' COLS=40 ROWS=10>".$userinfo['bio']."</TEXTAREA></TD></TR>"
	."</TABLE>"
	.inputHidden("action", "save")
	.inputHidden("userid", $userinformation['ID'])
	.inputSubmit("Update Users Profile")
	."</FORM>";
  }
  else
  {
    $sysmsg = "custom";
    $sysmsgcustomcontent = "No such username &quot;".$username."&quot;";
    $action = "";
  }
}

if (!$action)
{
  $output = "<SPAN CLASS='InputNotes'>"
	."Enter the username of the account you would like to edit the profile of:</SPAN><BR>"
	."<FORM ACTION='".$PHP_SELF."' METHOD=\"POST\">"
	.inputText("username", $username)."<BR>"
	.inputHidden("action", "edit")
	.inputSubmit("Edit Users Profile")
	."</FORM>";
}

$output = "<TABLE WIDTH=\"100%\" CELLSPACING=\"1\" CELLPADDING=\"20\" BORDER=\"0\">"
	."<TR><TD WIDTH=\"100%\" CLASS=\"BoardRowBody\">"
	.$output
	."</TD></TR></TABLE>";
}
else
{
header("Location: ../noaccess.php");
}
$pagecontents = $output;
include("layout.php");
?>