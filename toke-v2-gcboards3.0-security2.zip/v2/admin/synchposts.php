<?php
   $starttime = microtime();
   $protectedpage = 1;
   $functionset   = "admin";
   include("common.php");
if (($_COOKIE['adminlogin'] != $userdata['adminpass']) || (!$userdata['adminpass'])) { header("Location: login.php"); }
if (!$_POST && $action == "process") { exit; }

   $navigation[] = array("name" => "Synch User Posts",
                         "url"  => $PHP_SELF);

if (checkAccess("accessmoderator"))
{
  if($action == "next")
  {
    $userinfo = fetchRow($username, TABLE_USERS, "displayname", "idfieldistext", "dontcareifblank");
    if (!$userinfo['ID'] || !$username)
    {
      $action = "";
      $sysmsg = "custom";
      $sysmsgcustomcontent = "No Such User";
    }
    else
    {
      $realpostcount = getPostCount($userinfo['ID']);  
      $output = "<span class='InputSection'>Synch User's Post Count</span><br>\n"
               ."<span class='InputNotes'>Virtual Post Count: ".$userinfo['postcount']."<br>\n"
	 ."Actual Post Count: ".$realpostcount."<br>\n"
               .usernameDisplay($userinfo['ID'])." will lose ".($userinfo['postcount'] - $realpostcount)." posts.</span><br>\n"
               ."<form action='".$PHP_SELF."' method='POST'>\n"
               .inputHidden("action", "process")
               .inputHidden("userid", $userinfo['ID'])
               .inputHidden("username", $userinfo['displayname'])
               .inputHidden("realpostcount", $realpostcount)
               .inputHidden("postcount", $userinfo['postcount'])
               ."Click continue to synch this users post count."
               ."<p>\n"
               .inputSubmit(" Continue ")
               ."</form>\n";
    }
  }
  if ($action == "process")
  {

    if(!$username)
    {
      $err[] = "No username was entered";
    }
    $userinfo = fetchRow($username, TABLE_USERS, "displayname", "idfieldistext", "dontcareifblank");
    if(!$userinfo['ID'])
    {
      $err[] = "User '".$username."' doesn't exist";
    }
    if ($err)
    {
      $reason = implode("<BR>\n", $err);
      $action = "process";
    }
    else
    {
       $sql = "UPDATE ".TABLE_USERS." SET postcount = '$realpostcount' WHERE ID = '$userid' LIMIT 1";
       $exe = runQuery($sql);
      if ($exe)
      {
        $sysmsg = "custom";
        $sysmsgcustomcontent = $username."'s Post Count Was Successfully Synched";
	$adminaction = "Posts Synched";
	$description = $username." Posts Were Synched";
       newAdminAction($adminaction, $description);
        $action = "";
      }
      else
      {
        $sysmsg = "custom";
        $sysmsgcustomcontent = "There Was An Error Synching ".$username."'s Post Count";
        $action = "";
      }
    }
  }
  if (!$action || $action == "")
  {
    $output = "<span class='InputSection'>Synch User's Post Count</span><br>\n"
             ."<span class='InputNotes'>The user's post count will be reset to their actual post count. <br>\n"
             ."The post count displayed in a users profile and beside their posts is their &quot;Virtual Post Count&quot; "
             ."after synching a users postcount their postcount will be reset to their &quot;Actual Post Count&quot; which "
             ."is the total number of posts they have on the boards currently.  That have not been deleted by a moderator."
             ."<form action='".$PHP_SELF."' method='POST'>\n"
             .inputHidden("action", "next")
             ."Username: "
             .inputText("username", $username)
             ."<p>\n"
             .inputSubmit(" Synch Users Post Count ")
             ."</form>\n";
  }
}
else
{
  header("Location: ../noaccess.php");
}

     $output = "<table width=100% cellpadding=20 cellspacing=1 border=0>\n"
              ."  <tr>\n"
              ."    <td class='BoardRowBody'>\n"
              ."        ".str_replace("\n", "\n        ", $output)."\n</td>\n  </tr>\n"
              ."</table>\n";

   $pagecontents = $output;
   include("layout.php");
?>