<?php

$starttime = microtime();
$protectedpage = 1;
$functionset = "admin";
include("common.php");

if (checkAccess("accessvip"))
{

$navigationhead = "Admin Login";
global $userdata;

$sql = "SELECT adminpass, encpassword FROM ".TABLE_USERS." WHERE ID = '$userdata[ID]'";
$exe = runQuery($sql);
$row = fetchResultArray($exe);
$adminpass = $row['adminpass'];

if ($action == "logout")
{
  sendCookie("adminlogin", "");
  header("Location: ../index.php");
}

if ($action == "login")
{
  $pass = $_POST['loginpass'];
  $checkpass = encPassword($pass, "authenticate");
  if ($checkpass == $adminpass)
  {
    sendCookie("adminlogin", "");
    // Should Expire In 24 Hours
    sendSpecialCookie("adminlogin", $adminpass, "86400");
    header("Location: index.php");
  }
  else
  {
    $sysmsg = "custom";
    $sysmsgcustomcontent = "Sorry you entered an incorrect password.";
    $action = "";
  }
}

if ($action == "newpass" && !$userdata['adminpass'])
{
  if ($_POST['pass1'] == $_POST['pass2'])
  {
    $adminpassword = encPassword($_POST['pass1'], "authenticate");

    if ($adminpassword != $row['encpassword'])
    {
      $data['adminpass'] = $adminpassword;
      $update = updateUser($userdata['ID'], $data, "no");

      if ($update)
      {
        $adminaction = "New Admin Pass";
        $description = $userdata['displayname']." Registered An Admin Password";
        newAdminAction($adminaction, $description);
        header("Location: index.php");
      }
      else
      {
        $sysmsg = "custom";
        $sysmsgcustomcontent = "An error occured.  Please try again.";
        $action = "";
      }
    }
    else
    {
      $sysmsg = "custom";
      $sysmsgcustomcontent = "Your Admin Password cannot be the same as your account password.";
      $action = "";
    }

  }
  else
  {
    $sysmsg = "custom";
    $sysmsgcustomcontent = "The passwords didn't match.";
    $action = "";
  }
}

if (!$action || $action == "")
{
  if (!$adminpass)
  {
    $output = ""
	."<SPAN CLASS='InputNotes'>You currently do not have an Administrative Passsword set up, please enter one below."
	."  All the Admin Password is for, is to &quot;Login To The Admin Panel&quot;."
	."  Your Admin Password should be different from your actual user account password, this way if you happen to get hacked"
	." it prevents the hacker from doing any real damage.</SPAN><BR>"
	."<FORM ACTION='login.php' METHOD='POST'>"
	."<SPAN CLASS='InputSection'>Enter New Password: </SPAN><INPUT TYPE='password' NAME='pass1'><BR>"
	."<SPAN CLASS='InputSection'>Confirm New Password: </SPAN><INPUT TYPE='password' NAME='pass2'><BR>"
	."<INPUT TYPE='hidden' NAME='action' VALUE='newpass'>"
	."<INPUT TYPE='submit' VALUE='Submit New Password'>"
	."</FORM>"
	."";
  }
  else
  {
    if (!$adminlogin)
    {
    $output = ""
	."<SPAN CLASS='InputSection'>Please enter your Admin Password below so you can access the Admin Panel.</SPAN><BR>"
	."<FORM ACTION='login.php' METHOD='POST'>"
	."<B>Enter Admin Password: </B><INPUT TYPE='password' NAME='loginpass'><BR>"
	."<INPUT TYPE='hidden' NAME='action' VALUE='login'>"
	."<INPUT TYPE='submit' VALUE='Login'>"
	."</FORM>"
	."";
    }
    else
    {
      $output = "You are currently logged in.  If this isn't you please <A HREF='login.php?action=logout'>Logout</A>";
    }
  }
}
}
else
{
header("Location: ../noaccess.php");
}

$output = "<TABLE BORDER='0' WIDTH='100%' CELLPADDING='20' CELLSPACING='1'>"
	."<TR><TD WIDTH='100%' CLASS='BoardRowBody'>"
	.$output
	."</TD></TR></TABLE>";

$pagecontents = $output;
include("layout.php");
?>