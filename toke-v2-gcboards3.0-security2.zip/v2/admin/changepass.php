<?php
   $starttime = microtime();
   $protectedpage = 1;
   $functionset   = "admin";
   include("common.php");
if (($_COOKIE['adminlogin'] != $userdata['adminpass']) || (!$userdata['adminpass'])) { header("Location: login.php"); }
if (!$_POST && $action == "savepass") { exit; }

if (checkAccess("accessadmin"))
{     
     if ($action == "savepass")
     {
       $navigationhead = "Change User's Password";

       if (!$username)     { $err[] = "No username was entered"; }
       {
         $userinfo = fetchRow($username, TABLE_USERS, "displayname", "idfieldistext", "dontcareifblank");
         if (!$userinfo['ID'])
                           { $err[] = "User '".$username."' doesn't exist"; }
       }
       if (!$password)     { $err[] = "No password was entered"; }
       
       if ($err)
       {
         $reason = implode("<BR>\n", $err);
         $action = "changepass";
       }
       else
       {
         // Hash the password and store it
         $data['encpassword'] = password_hash($password, PASSWORD_DEFAULT);
         
         $update = updateUser($userinfo['ID'], $data);
         if ($update)
         {
	$adminaction = "Password Changed";
	$description = $username." Password Was Changed";
       newAdminAction($adminaction, $description);
           $sysmsg = "custom";
           $sysmsgcustomcontent = "The password for <I>".$username."</I> has been changed to <I>".$password."</I>.\n";
           $action = "display";
         }
         else
         {
           $sysmsg = "custom";
           $sysmsgcustomcontent = "The password for <I>".$username."</I> was not changed.\n";
           $action = "display";
         }
       }
     }
     
     if ($action == "changepass" || !$action)
     {
       $navigationhead = "Change User's Password";
       $mandatory = "<SPAN CLASS='red'>�</SPAN>";
       
       include("../elements/adminchangepass.php");
       $output = "<SPAN CLASS='InputSection'>Change User's Password</SPAN><BR>\n"
                ."Enter the username and new password below.<BR>\n"
                ."<FORM ACTION='$PHP_SELF' METHOD=POST>\n"
                .inputHidden("action", "savepass")
                .$changepassform
                ."<P>\n"
                .inputSubmit("Change Password")
                ."</FORM>\n";
     }
}
else
{
header("Location: ../noaccess.php");
}

     $output = "<TABLE WIDTH=100% CELLPADDING=20 CELLSPACING=1 BORDER=0>\n"
              ."<TR><TD CLASS='BoardRowBody'>\n"
              ."        ".str_replace("\n", "\n        ", $output)."</TD></TR>\n"
              ."</TABLE>\n";
$pagecontents = $output;
include("layout.php");
?>