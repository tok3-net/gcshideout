<?php
   $starttime = microtime();
   $protectedpage = 1;
   $functionset   = "admin";
   include("common.php");
if (($_COOKIE['adminlogin'] != $userdata['adminpass']) || (!$userdata['adminpass'])) { header("Location: login.php"); }
if (!$_POST && $action == "unban") { exit; }
if (checkAccess("accessmoderator"))
{

   $navigation[] = array("name" => "Unban User",
                         "url"  => $PHP_SELF);
{ 
   
   if ($action == "unban")
   {
     if ($username)
     {
       $vars['classid'] = 6;
       
       $userinfo = fetchRow($username, TABLE_USERS, "displayname", "idfieldistext", "dontcareifblank");
if ($userinfo['classid'] == "7")
{
       if ($userinfo['ID'])
       {
         $update = updateUser($userinfo['ID'], $vars);
         if ($update)
         {
	$adminaction = "User Unbanned";
	$description = $username." Was Unbanned";
              newAdminAction($adminaction, $description);
 	$sysmsg = "custom";
	$sysmsgcustomcontent = $username." Was Un-Banned";
	$action = "";
         }
         else
         {
           $reason = "Couldn't un-ban this user - you'll have to get an administrator to do it.<BR>\n";
           $action = "";
         }
       }
       else
       {
         $reason = "Didn't find a user named  <I>".$username."</I>. Mistyped?<BR>\n";
         $action = "";
       }
     }
}
if ($userinfo['classid'] != "7")
{
       $action = "";
       $sysmsg = "custom";
       $sysmsgcustomcontent = $username." Isn't Currently Banned";
}
     
   }
   
   if (!$action || $action == "")
   {
// u.ID, u.displayname, c.classname, u.postcount, u.displayformat
     $sql = "SELECT * "
           ."  FROM ".TABLE_USERS." u, ".TABLE_ACCESS_CLASS." c"
           ." WHERE u.classid = '7'"
           .$usermatchcondition
           ."   AND u.classid = c.ID ";
$exe = runQuery($sql);


     $output = ""
			."<TABLE BORDER=0 WIDTH=100%><TR><TD>"
			  ."<FORM ACTION='$PHP_SELF' METHOD=POST NAME=\"unban\">\n"
			  .inputHidden("action", "unban")
			  ."<SPAN CLASS='InputSection'>Username To UnBan: </SPAN>".inputText("username", $username)."<BR>"
			  .inputSubmit("Un-Ban User")
			  ."</FORM>\n"
			."</TD><TD VALIGN=TOP>"
			."<CENTER><U><B>Currently Banned Users:</B></U></CENTER><BR>"
			."<SPAN CLASS=\"InputNotes\">Click On The Username To See The Ban Reason</SPAN>"
			."<TABLE BORDER=1 WIDTH=100%><TR><TD><B>Username:</B></TD>"
			."<TD><B>Un-Ban Date:</TD></TR>";
			// $options[classid] = "7";
			while ($row = fetchResultArray($exe))
			{
$output .= ""

			."<TR><TD><A HREF=\"#\" onClick=\"alert('".$row['banreason']."'); document.unban.username.value='".$row['displayname']."';\">".$row['displayname']."</A></TD><TD>".$row['unbandate']."</TD></TR>";
			}
$output .= ""
			."</TABLE></TD></TR></TABLE>";

   }



   if ($reason)
   {
     $reasonoutput = "<B CLASS='red'>".$reason."</B>\n"
                    ."<P>\n";
   }
   
   $output = "<TABLE WIDTH=100% CELLPADDING=20 CELLSPACING=1 BORDER=0>\n"
            ."<TR><TD CLASS='BoardRowBody'>\n"
            ."        ".str_replace("\n", "\n        ", $reason.$output)."</TD></TR>\n"
            ."</TABLE>\n";
}
}
else
{
header("Location: ../noaccess.php");
}
   $pagecontents = $output;
   include("layout.php");
?>