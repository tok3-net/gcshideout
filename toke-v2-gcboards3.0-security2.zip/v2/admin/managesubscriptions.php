<?php
ini_set("display_errors", 0);
$starttime = microtime();
$protectedpage = 1;
$functionset = "admin";
include("common.php");
if (($_COOKIE['adminlogin'] != $userdata['adminpass']) || (!$userdata['adminpass'])) { header("Location: login.php"); }
if (($action == "subscribe" || $action == "reallyend" || $action == "added") && (!$_POST)) { exit; }

$navigation[] = array("name" => "Manage Subscriptions",
		  "url" => $PHP_SELF);

if (checkAccess("accessmanager"))
{

if ($action == "add")
{
  $navigationhead = "Add A Subscription";
  $output = "<FORM ACTION=\"".$PHP_SELF."\" METHOD=\"POST\">"
	  ."<TABLE BORDER=\"1\" CELLSPACING=\"1\" CELLPADDING=\"3\">"
	  ."<TR><TD CLASS=\"BoardRowHeading\" COLSPAN=\"2\"><B>Add A New Subscription</B></TD></TR>"
	  ."<TR><TD CLASS=\"BoardColumn\">Username</TD>"
	  ."<TD CLASS=\"BoardRowBody\">".inputText("username", $username)."</TD></TR>";
  if ($AllowShop)
  {
    $output .= "<TR><TD CLASS=\"BoardColumn\">Cost (Board Dollars)</TD>"
	  ."<TD CLASS=\"BoardRowBody\">".inputText("cost", "0")."</TD></TR>";
  }
  else
  {
    $output .= inputHidden("cost", "0");
  }
  $output .= "<TR><TD CLASS=\"BoardColumn\">Subscription End Date</TD>"
	  ."<TD CLASS=\"BoardRowBody\">".inputText("ienddate", $ienddate)."</TD></TR>"
	  .inputHidden("action", "added")
	  ."<TR><TD CLASS=\"BoardRowBody\">".inputSubmit("Add Subscription")."</TD></TR>"
	  ."</TABLE>"
	  ."</FORM>";
}

if ($action == "added")
{
  $navigationhead = "Subscription Added";
  $username = $_POST['username'];
  $cost = $_POST['cost'];
  $ienddate = $_POST['ienddate'];
  $userinfo = fetchRow($username, TABLE_USERS, "displayname", "idfieldistext", "dontcareifblank");
  if (!$userinfo['ID'])
  {
    $sysmsg = "custom";
    $sysmsgcustomcontent = "The Username &quot;".$username."&quot; Does Not Exist";
    $action = "add";
  }
  if ($cost > $userinfo['dollars'])
  {
    $sysmsg = "custom";
    $sysmsgcustomcontent = $username." Does Not Have $".$cost."";
    $action = "add";
  }
  $newdollars = $userinfo['dollars'] - $cost;
  $data['dollars'] = $newdollars;
  $data['classid'] = "5";
  $data['ienddate'] = $ienddate;
  $update = updateUser($userinfo['ID'], $data, "no");
  if ($update)
  {
    $adminaction = "Subscription Added";
    $description = "A Subscription For ".$username." Was Added";
    newAdminAction($adminaction, $description);
    $sysmsg = "custom";
    $sysmsgcustomcontent = "The Subscription Was Successfully Added";
    $action = "";
  }
  else
  {
    $sysmsg = "custom";
    $sysmsgcustomcontent = "An error occured and the subscription could not be added";
    $action = "add";
  }
}

if ($action == "renew")
{
  $navigationhead = "Renew Subscription";
  $userid = $_GET['ID'];
  $output = "<SPAN CLASS=\"InputSection\">Renew A Users Subscription</SPAN><BR>"
	  ."<SPAN CLASS=\"InputNotes\">Enter The Subscription Information For ".usernameDisplay($userid, "", "", "", "admin")."</SPAN><BR>"
	  ."<FORM ACTION=\"".$PHP_SELF."\" METHOD=\"POST\">"
	  ."<TABLE CELLPADDING=\"3\" CELLSPACING=\"1\">"
	  ."<TR><TD CLASS=\"BoardColumn\">Subscription End Date</TD>"
	  ."<TD CLASS=\"BoardRowBody\">".inputText("ienddate", $ienddate)."</TD></TR>"
	  .inputHidden("userid", $userid)
	  .inputHidden("action", "subscribe");
  if ($AllowShop)
  {
    $output .= "<TR><TD CLASS=\"BoardColumn\">Cost (Board Dollars)</TD>"
	     ."<TD CLASS=\"BoardRowBody\">".inputText("cost", "0")."</TD></TR>";
  }
  else
  {
    $output .= inputHidden("cost", "0");
  }
  $output .= "<TR><TD CLASS=\"BoardRowBody\" COLSPAN=\"2\">".inputSubmit("Renew Users Subscription")."</TD></TR>"
	  ."</TABLE>"
	  ."</FORM>";
}

if ($action == "subscribe")
{
  $navigationhead = "User Subscribed";
  $ienddate = $_POST['ienddate'];
  $cost = $_POST['cost'];
  $sql = "SELECT dollars, displayname FROM ".TABLE_USERS." WHERE ID = '$userid' LIMIT 1";
  $exe = runQuery($sql);
  $row = fetchResultArray($exe);
  if ($row['dollars'] >= $cost)
  {
    $newdollars = $row['dollars'] - $cost;
    $data['dollars'] = $newdollars;
    $data['ienddate'] = $ienddate;
    $update = updateUser($userid, $data, "no");
    if ($update)
    {
      $adminaction = "Subscription Renewed";
      $description = "The Subscription For ".$row['displayname']." Was Renewed";
      newAdminAction($adminaction, $description);
      $sysmsg = "custom";
      $sysmsgcustomcontent = "The Subscription For ".$row['displayname']." Was Renewed";
      $action = "";
    }
    else
    {
      $sysmsg = "custom";
      $sysmsgcustomcontent = "An error occured and the subscription could not be renewed";
      $action = "";
    }
  }
  else
  {
    $sysmsg = "custom";
    $sysmsgcustomcontent = $row['displayname']." Does Not Have Enough Money To Pay For The Subscription Renewal";
    $action = "";
  }
}

if ($action == "end")
{
  $userid = $_GET['ID'];
  $output = "<SPAN CLASS=\"InputSection\">Confirm Subscription Termination</SPAN><BR>"
	  ."<FORM ACTION=\"".$PHP_SELF."\" METHOD=\"POST\">"
	  ."Are you sure you want to terminate the subscription for ".usernameDisplay($userid, "", "", "", "admin")."?<BR>"
	  ."<INPUT TYPE=\"CHECKBOX\" NAME=\"confirm\" VALUE=\"yes\"><BR>"
	  .inputHidden("userid", $userid)
	  .inputHidden("action", "reallyend")
	  .inputSubmit("Confirm")
	  ."</FORM>";
}

if ($action == "reallyend")
{
  $sql = "SELECT displayname FROM ".TABLE_USERS." WHERE ID = '$userid' LIMIT 1";
  $exe = runQuery($sql);
  $row = fetchResultArray($exe);
  $data['classid'] = "6";
  $data['ienddate'] = "Not Set";
  $update = updateUser($userid, $data, "no");
  if ($update)
  {
    $adminaction = "Subscription Ended";
    $description = "The Subscription For ".$row['displayname']." Was Terminated";
    newAdminAction($adminaction, $description);
    $sysmsg = "custom";
    $sysmsgcustomcontent = "The Subscription For ".$row['displayname']." Was Terminated";
    $action = "";
  }
  else
  {
    $sysmsg = "custom";
    $sysmsgcustomcontent = "An error occured and the subscription could not be terminated";
    $action = "";
  }
}

if (!$action)
{
  $sql = "SELECT classid, ienddate, ID FROM ".TABLE_USERS." WHERE classid = '5'";
  $exe = runQuery($sql);
  $output = "<TABLE BORDER=1 WIDTH=100% CELLSPACING=1 CELLPADDING=3>"
	."<TR><TD CLASS='BoardColumn' COLSPAN=4>"
	."<A HREF='managesubscriptions.php?action=add' CLASS=\"MainMenuLink\">Add Subscriber</A>"
	."</TD></TR>"
	."<TR><TD CLASS=\"BoardRowHeading\">Username</TD>"
	."<TD CLASS=\"BoardRowHeading\">End Date</TD>"
	."<TD CLASS=\"BoardRowHeading\">Renew Subscription</TD>"
	."<TD CLASS=\"BoardRowHeading\">End Subscription</TD></TR>";


    while ($row = fetchResultArray($exe))
    {
      if (!$row['ienddate'])
      {
        $end = "Never";
      }
      else
      {
        $end = $row['ienddate'];
      }
      $output .= "<TR><TD CLASS=\"BoardRowBody\">".usernameDisplay($row['ID'], "", "", "", "admin")."</TD>"
	     ."<TD CLASS=\"BoardRowBody\">".$end."</TD>"
	     ."<TD CLASS=\"BoardRowBody\"><A HREF=\"managesubscriptions.php?action=renew&ID=".$row['ID']."\">Renew</A></TD>"
	     ."<TD CLASS=\"BoardRowBody\"><A HREF=\"managesubscriptions.php?action=end&ID=".$row['ID']."\">End</A></TD></TR>";
      $checkvar = 1;
    }
    if (!$checkvar)
    {
      $output .= "<TR><TD WIDTH=\"100%\" COLSPAN=\"4\" CLASS=\"BoardRowBody\"><B>There Are Currently No Active Subscriptions</B></TD></TR>";
    }

  $output .= "</TABLE>";
}

}
else
{
  header("Location: ../noaccess.php");
}

$output = "<TABLE BORDER=0 WIDTH=100% CLASS='BoardRowBody' CELLSPACING=1 CELLPADDING=3>"
	."<TR><TD WIDTH=100% CLASS='BoardRowBody'>"
	.$output
	."</TD></TR></TABLE>";
$pagecontents = $output;
include("layout.php");
?>