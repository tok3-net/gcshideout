<?php
   $starttime = microtime();
   $protectedpage = 1;
   $functionset   = "admin";
   include("common.php");
if (($_COOKIE['adminlogin'] != $userdata['adminpass']) || (!$userdata['adminpass'])) { header("Location: login.php"); }

   if (checkAccess("accessvip"))
   {

     $navigation[] = array("name" => "Administration",
                           "url"  => "$PHP_SELF?action=blank");

     
     if ($action == "blank")
     {
	$navigationhead = "Admin Intro";
       $output = "<-- choose an admin action to the left<BR><BR>"
	."<TABLE BORDER=1 STYLE='background-color:#9CA1B4;' WIDTH=150><TR><TD>"
	."The following moderator features can be accessed from the message you are viewing by clicking on the corresponding link:<BR><BR>"
	."- Add/Remove Sticky<BR>"
	."- Move Topic<BR>"
	."- Delete Topic<BR>"
	."- Delete Message<BR>"
	."- Lock/Unlock Topic<BR>"
	."- Edit Message"
	."</TD></TR></TABLE>"
	."";
     }

if ($action == "menu")
{
       $navigationhead = "Administration";
       
       // Define options
       $pageoptadmin[] = array("name" => "Edit Support E-Mails",
			 "url" => "editemails.php",
			 "desc" => "Allows Admins To Edit The Email Templates For Certain Emails The Board Sends Out.\n");
       $pageoptadmin[] = array("name" => "Edit TOS Settings",
			 "url" => "edittos.php",
			 "desc" => "Allows Admins To Edit The TOS.\n");
       $pageoptadmin[] = array("name" => "Add System Style",
			 "url" => "stylesheets.php?action=add",
			 "desc" => "Allows Administrators to add a system stylesheet.\n");
       $pageoptadmin[] = array("name" => "Edit System Style",
			 "url" => "stylesheets.php",
			 "desc" => "Allows Administrators to edit system stylesheets.\n");
       $pageoptadmin[] = array("name" => "Remove User",
			 "url" => "removeuser.php",
			 "desc" => "Allows you to delete a users account.\n");
       $pageoptadmin[] = array("name" => "Add User",
			           "url"  => "adduser.php",
			           "desc" => "Adds a user with a password you set.\n");
       $pageoptadmin[] = array("name" => "Change User's Password",
                         	   "url"  => "changepass.php",
                       		   "desc" => "Change the password on a user's account.\n");
global $AllowFileViewer;
if ($AllowFileViewer)
{
       $pageoptadmin[] = array("name" => "File Viewer",
			"url" => "fileviewer.php",
			"desc" => "Allows you to view any file in the GC Boards root.\n");
}
       $pageoptadmin[] = array("name" => "Edit User Rights",
                          	   "url"  => "manageusers.php",
                         	   "desc" => "Assign different access classes to board users.\n");
global $AllowShop;
if ($AllowShop)
{
       $pageoptadmin[] = array("name" => "Edit Shop",
			 "url" => "editshop.php",
			 "desc" => "Allows you to edit shop prices.\n");
}
       $pageoptadmin[] = array("name" => "Manage Access Classes",
                          	   "url"  => "manageclasses.php",
                         	   "desc" => "Change the permissions assigned to access classes or create new ones.\n");
       $pageoptadmin[] = array("name" => "Mass Email",
                         	   "url"  => "massemail.php",
                          	   "desc" => "Allows you to Mass Email board members.\n");
       $pageoptadmin[] = array("name" => "View A Message",
                         	   "url"  => "viewmessage.php",
                          	   "desc" => "View any message on the board by its unique ID.\n");
       $pageoptmanager[] = array("name" => "Add Category",
                          	     "url"  => "managestructure.php?action=managestructure&step=2",
                         	     "desc" => "Adds A Category To Your Boards.\n");
       $pageoptmanager[] = array("name" => "Manage Board Structure",
                          	     "url"  => "managestructure.php",
                         	     "desc" => "Add, remove or edit boards and the groups they're presented in.\n");
       $pageoptmanager[] = array("name" => "Manage Icons",
                         	     "url"  => "manageicons.php",
                          	     "desc" => "Add, remove or edit icons and associated groups.\n");
       $pageoptmanager[] = array("name" => "Assign Title",
                          	 "url"  => "titles.php",
                          	 "desc" => "Set or Change a user's Title field\n");
       $pageoptmanager[] = array("name" => "Change User's Username",
			"url" => "changename.php",
			"desc" => "Allows you to change a user's username.\n");
       $pageoptmanager[] = array("name" => "Edit Users Profile",
			     "url" => "edituserprofile.php",
			     "desc" => "Allows you to edit a users profile.\n");
       $pageoptmanager[] = array("name" => "IP Address Bans",
                         	     "url"  => "ipban.php",
                           	     "desc" => "Administer the system-wide IP bans\n");
       $pageoptmanager[] = array("name" => "Manage Subscriptions",
                          	 "url"  => "managesubscriptions.php",
                          	 "desc" => "Allows you to manage insider users.\n");

	   $pageoptmod[] = array("name" => "Ban User",
				"url"  => "banuser.php",
				"desc" => "Puts the specified username into the ban class for now.\n");
	   $pageoptmod[] = array("name" => "Unban User",
				"url"  => "unbanuser.php",
				"desc" => "Puts the specified username into the member class for now.\n");
       $pageoptmod[] = array("name" => "User's Admin Notes",
                          	 "url"  => "notes.php",
                         	 "desc" => "View admin-only notes about any board user\n");
       $pageoptmod[] = array("name" => "User IP Check",
                          	 "url"  => "ip.php",
                          	 "desc" => "Find users by IP address or IPs used by a user\n");
	$pageoptmod[] = array("name" => "Admin Action Log",
			"url" => "actions.php",
			"desc" => "View Actions VIP+ Have Done.\n");
         $pageoptmod[] = array("name" => "Synch Users Posts",
			 "url" => "synchposts.php",
			 "desc" => "Resets a users postcount back to its actual post count.\n");
	$pageoptmod[] = array("name" => "Remove Users Posts",
			"url" => "removeposts.php",
			"desc" => "Removes a users posts.\n");
	   $pageoptmod[] = array("name" => "Change Users Post Count",
							 "url"  => "changepost.php",
							 "desc" => "Changes a users post count.\n");
if ($AllowShop)
{
       $pageoptmod[] = array("name" => "Edit Users Money",
			"url" => "changedollar.php",
			"desc" => "Changes a users amount of money.\n");
}

       $pageoptvip[] = array("name" => "Change User Name Style",
                         	 "url"  => "../options.php?action=nameformat&functionset=admin",
                             "desc" => "Change your user name colors and style\n");
       $pageoptvip[] = array("name" => "Change Admin Password",
                         	 "url"  => "changeadminpass.php",
                             "desc" => "Changes your admin password.\n");
       $pageoptvip[] = array("name" => "Daily System Stats",
                         	 "url"  => "viewsessions.php",
                             "desc" => "Check which users have accessed the system.\n");
	   $pageoptvip[] = array("name" => "Change Your Own Title",
						  	 "url"  => "../own-title.php?functionset=admin",
						 	 "desc" => "Using this you can change your own title.  And ONLY your own title.\n");

//----------------------------------------------------       
       // Show a menu of options availabale to Admins

       
       // New style
       for ($i = 0; $i < count($pageoptadmin); $i++ )
       {
         $menurowadmin .= "<TR><TD><A HREF='".$pageoptadmin[$i]['url']."' CLASS='AdminMenuLink' STYLE='text-decoration:none;' TARGET='main'>".$pageoptadmin[$i]['name']."</A></TD></TR>\n";
       }
//----------------------------------------------------
       // Show a menu of options availabale to Managers

       
       // New style
       for ($i = 0; $i < count($pageoptmanager); $i++ )
       {
         $menurowmanager .= "<TR><TD><A HREF='".$pageoptmanager[$i]['url']."' CLASS='AdminMenuLink' STYLE='text-decoration:none;' TARGET='main'>".$pageoptmanager[$i]['name']."</A></TD></TR>\n";
       }
//----------------------------------------------------
       // Show a menu of options availabale to Mods

       
       // New style
       for ($i = 0; $i < count($pageoptmod); $i++ )
       {
         $menurowmod .= "<TR><TD><A HREF='".$pageoptmod[$i]['url']."' CLASS='AdminMenuLink' STYLE='text-decoration:none;' TARGET='main'>".$pageoptmod[$i]['name']."</A></TD></TR>\n";
       }
//----------------------------------------------------
       // Show a menu of options availabale to VIP's

       
       // New style
       for ($i = 0; $i < count($pageoptvip); $i++ )
       {
         $menurowvip .= "<TR><TD><A HREF='".$pageoptvip[$i]['url']."' CLASS='AdminMenuLink' STYLE='text-decoration:none;' TARGET='main'>".$pageoptvip[$i]['name']."</A></TD></TR>\n";
       }
//----------------------------------------------------
       // [close] link doesn't work ... yet
       $output = ""
                ."<SCRIPT LANGUAGE='JavaScript'>\n"
                ."function closeAdminFrame() { \n"
                ."parent.location = parent.frames['main'].location; \n"
                ."return false; \n"
                ."} \n"
                ."</SCRIPT>\n"
                ."<A HREF='#' CLASS='statistictext' onClick='return closeAdminFrame();' STYLE='text-decoration:none;'>[close]</A>&nbsp;&nbsp;"
	  ."<A HREF='index.php?action=menu' CLASS='statistictext' STYLE='text-decoration:none;' TARGET='menu'>[reload main]</A><BR><BR>"
                ."<SPAN CLASS='statistictext' style='font-size:9pt;'><B><U>Administrator</U></B> "
                ."</SPAN><BR>\n"
                ."<TABLE CELLSPACING=0 CELLPADDING=0>\n"
                .$menurowadmin
				."</TABLE>"
                ."<br><SPAN CLASS='statistictext' style='font-size:9pt;'><B><U>Manager</U></B> "
                ."</SPAN><BR>\n"
                ."<TABLE CELLSPACING=0 CELLPADDING=0>\n"
                .$menurowmanager
				."</TABLE>"
                ."<br><SPAN CLASS='statistictext' style='font-size:9pt;'><B><U>Moderator</U></B> "
                ."</SPAN><BR>\n"
				."<TABLE CELLSPACING=0 CELLPADDING=0>\n"
                .$menurowmod
                ."</TABLE>"
                ."<br><SPAN CLASS='statistictext' style='font-size:9pt;'><B><U>VIP</U></B> "
                ."</SPAN><BR>\n"
				."<TABLE CELLSPACING=0 CELLPADDING=0>\n"
                .$menurowvip
                ."</TABLE><BR>\n";
       $ThemeName = "plain";
       $bodycolor = "#333333";
       $marginx = 3;
       $marginy = 3;
       $nowrap = 1;
}
    
     
     if (!$action)
     {
       $menusrc = $PHP_SELF."?action=menu";
       $mainsrc = $PHP_SELF."?action=blank";
       include("../elements/frameset.php");
       $output = $frameset;
       $ThemeName = "frameset";
       $nowrap = 1;
     }

   }
   else
   {
	header("Location: ../noaccess.php");
   }

   if ($reason)
   {
     $reasonoutput = "<TABLE WIDTH=100% CELLPADDING=3 CELLSPACING=1 BORDER=0><TR><TD CLASS='BoardRowBody'>\n"
                    ."<B CLASS='red'>".$reason."</B>\n"
                    ."</TD></TR></TABLE><BR>\n";
   }
   $output = $reasonoutput
            .$output;
   
   if (!$nowrap)
   {
     $output = "<TABLE WIDTH=100% CELLPADDING=20 CELLSPACING=1 BORDER=0>\n"
              ."<TR><TD CLASS='BoardRowBody'>\n"
              ."        ".str_replace("\n", "\n        ", $output)."</TD></TR>\n"
              ."</TABLE>\n";
   }       
   $pagecontents = $output;
   include("layout.php");
?>
