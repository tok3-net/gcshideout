<?php
   $starttime = microtime();
   $protectedpage = 1;
   $functionset   = "admin";
   include("common.php");
if (($_COOKIE['adminlogin'] != $userdata['adminpass']) || (!$userdata['adminpass'])) { header("Location: login.php"); }
if (($step == "3" || $step == "savenewclass") && (!$_POST)) { exit; }

if (checkAccess("accessadmin"))
{
     
     if ($action == "manageclasses" || !$action)
     {
       $navigation[] = array("name" => "Access Management",
                             "url"  => "$PHP_SELF?action=manageclasses&step=1");

       if (!$step) { $step = 1; }
       
       if ($step == "savenewclass")
       {
         $classinfo['accessadmin']      = $accessadmin;
         $classinfo['accessmanager']    = $accessmanager;
         $classinfo['accessmoderator']  = $accessmoderator;
         $classinfo['accessvip']	= $accessvip;
         $classinfo['accessinsider'] = $accessinsider;
         $classinfo['accessread']       = $accessread;
         $classinfo['accesswrite']      = $accesswrite;
         $classinfo['accessdelete']     = $accessdelete;
         $classinfo['accesstimeedit']   = $accesstimeedit;
         $classinfo['accessfulledit']   = $accessfulledit;
         $classinfo['accessnameformat'] = $accessnameformat;
         $classinfo['accesslogin']      = $accesslogin;
         
         $newclassid = newClass($classname);
         if ($newclassid)
         {
           $permissions = newClassPermissions($newclassid, $classinfo);
	$adminaction = "New Access Class";
	$description = "".$classname." Access Class Was Added";
       newAdminAction($adminaction, $description);
           
           $sysmsgcustom = "custom";
           $sysmsgcustomcontent = "Your requested Access Class, '".$classname."' has been created";
         }
         else
         {
           $sysmsgcustom = "custom";
           $sysmsgcustomcontent = "Couldn't create a new Access Class";
         }
         $step = 1;
       }
       
       if ($step == "newclass")
       {
         $options['classname']        = $classname;
         $options['accessadmin']      = $accessadmin;
		 $options['accessmanager']    = $accessmanager;
         $options['accessmoderator']  = $accessmoderator;
		 $options['accessvip']		= $accessvip;
         $options['accessinsider'] = $accessinsider;
         $options['accessread']       = $accessread;
         $options['accesswrite']      = $accesswrite;
         $options['accessdelete']     = $accessdelete;
         $options['accesstimeedit']   = $accesstimeedit;
         $options['accessfulledit']   = $accessfulledit;
         $options['accessnameformat'] = $accessnameformat;
         $options['accesslogin']      = $accesslogin;
         $classes = listClasses($options, "blankrow");

         $output = "<FORM ACTION='$PHP_SELF' METHOD=POST>\n"
                  .inputHidden("action", "manageclasses")
                  .inputHidden("step", "savenewclass")
                  .inputHidden("permissionrowid", $classes['permissionrowid'])
                  .inputHidden("currentadmin", $classes['currentadmin'])
                  .inputHidden("currentname", $classes['classname'])
                  .$classes['classlist']
                  .$confirmrow
                  .inputSubmit("Submit Changes")
                  ."</FORM>\n";
       }

       if ($step == 3)
       {
         $navigationhead = "Update Class Permissions";
         
         if ((intval($currentadmin) != intval($accessadmin)) && (!$confirm))
         {
           $err[] = "This change affects Admin access - please confirm it.";
           
           $options['overridevalues'] = array("ID"               => $classid,
                                            "classname"        => $classname,
                                            "permissionrowid"  => $permissionrowid,
                                            "accessadmin"      => $accessadmin,
			"accessmanager"    => $accessmanager,
                                            "accessmoderator"  => $accessmoderator,
			"accessvip"		   => $accessvip,
			  "accessinsider" => $accessinsider,
                                            "accessread"       => $accessread,
                                            "accesswrite"      => $accesswrite,
                                            "accessdelete"     => $accessdelete,
                                            "accesstimeedit"   => $accesstimeedit,
                                            "accessfulledit"   => $accessfulledit,
                                            "accessnameformat" => $accessnameformat,
                                            "accesslogin" => $accesslogin);
           $confirmrow = "<BR>".inputCheckbox("confirm", 1)." <SPAN CLASS='BoardRowBody'>Confirm this change</SPAN><BR><BR>";
         }
         if (!trim($classname))
         { $err[] = "No class name was entered"; }
         
         if ($err)
         {
           $reason = implode("<BR>\n", $err);
           $step = 2;
         }
         else
         {
           // Put the name format settings in here, too
           $newsettings['hlcolour']       = $hlcolour;
           $newsettings['txtcolour']      = $txtcolour;
           $newsettings['stylebold']      = $bold;
           $newsettings['styleitalic']    = $italic;
           
           $newsettings['styleunderline']     = $underline;
           $newsettings['styleoverline']      = $overline;
           $newsettings['stylestrikethrough'] = $strikethrough;
           $newsettings['bottomborder'] = $bottomborder;
           $newsettings['topborder']    = $topborder;
           $newsettings['leftborder']   = $leftborder;
           $newsettings['rightborder']  = $rightborder;
           $newsettings['bordercolour'] = $bordercolour;
           
           if ($hlcolour || $txtcolour || $bold || $italic || $underline || $overline || $strikethrough || $bottomborder || $topborder || $leftborder || $rightborder )
           {
             $nameformat = serialize($newsettings);
           }
           
           $updateclass = updateClass($classid, $classname, $nameformat);
  
           $vars['accessadmin']      = $accessadmin;
	$vars['accessmanager']    = $accessmanager;
           $vars['accessmoderator']  = $accessmoderator;
	$vars['accessvip']		   = $accessvip;
           $vars['accessinsider'] = $accessinsider;
           $vars['accessread']       = $accessread;
           $vars['accesswrite']      = $accesswrite;
           $vars['accessdelete']     = $accessdelete;
           $vars['accesstimeedit']   = $accesstimeedit;
           $vars['accessfulledit']   = $accessfulledit;
           $vars['accessnameformat'] = $accessnameformat;
           $vars['accesslogin']      = $accesslogin;
           
           $changeperm = updateClassPermissions($permissionrowid, $vars);
	$adminaction = "Access Class Updated";
	$description = "".$classname." Access Class Updated";
       newAdminAction($adminaction, $description);
           
           $sysmsgcustom = "custom";
           $sysmsgcustomcontent = "Access Levels have been updated for <B>$classname</B>.\n";
           $step = 1;
         }
       }
       
       if ($step == 2)
       {
         $navigationhead = "Change Class Permissions";
  
         $options['classid']       = $classid;
         $options['showlinks']     = 0;
         $options['checkboxes']    = 1;
         $options['editclassname'] = 1;
         $classes = listClasses($options);
         
         $formatsettings = unserialize($classes['nameformat']);
         //print_r($formatsettings);
         //echo "<BR>\n";
         $hlcolour  = $formatsettings['hlcolour'];
         $txtcolour = $formatsettings['txtcolour'];
         $bold      = $formatsettings['stylebold'];
         $italic    = $formatsettings['styleitalic'];
         // Legacy
         $bottomborder  = $formatsettings['styleunderline'];
         $topborder     = $formatsettings['styleoverline'];
         $strikethrough = $formatsettings['stylestrikethrough'];
         // Border switches
         $bottomborder = $formatsettings['bottomborder'];
         $topborder    = $formatsettings['topborder'];
         $leftborder   = $formatsettings['leftborder'];
         $rightborder  = $formatsettings['rightborder'];
         $bordercolour = $formatsettings['bordercolour'];

         include("../elements/nameformat.php");
         $pageformstart = "<FORM ACTION='$PHP_SELF' METHOD=POST>\n"
                         .inputHidden("action", "manageclasses")
                         .inputHidden("classid", $classid)
                         .inputHidden("step", 3)
                         .inputHidden("permissionrowid", $classes['permissionrowid'])
                         .inputHidden("currentadmin", $classes['currentadmin'])
                         .inputHidden("currentname", $classes['classname']);
         $pageformstop = "</FORM>\n";
         $output = $classes['classlist']
                  .$confirmrow
                  ."<TABLE WIDTH=100% CELLPADDING=3 CELLSPACING=1 BORDER=0>\n"
                  ."<TR><TD COLSPAN=3 CLASS='BoardColumn'>Default Name Format</TD></TR>\n"
                  ."<TR><TD COLSPAN=3 CLASS='BoardRowBody'>\n"
                  .$nameformattable."</TD></TR>\n"
                  ."<TR><TD COLSPAN=3 CLASS='BoardRowHeading' ALIGN=RIGHT>\n"
                  .inputSubmit("Update Access Class")."</TD></TR>\n"
                  ."</TABLE>\n";
         
         $nowrap = 1;
       }
       
       if ($step == 1)
       {
         $navigationhead = "List Available Classes";
  
         // Show a list of available classes
         $options['linkparams'] = "?action=manageclasses&step=2";
         $options['showlinks']  = 1;
         $classes = listClasses($options);
         
         $areaoptions[] = array("name" => "Create a New Access Class",
                                "url"  => $PHP_SELF."?action=manageclasses&step=newclass");

         $output = $classes['classlist'];
         $nowrap = 1;
       }
   }
}
else
{
header("Location: ../noaccess.php");
}

     $output = "<TABLE WIDTH=100% CELLPADDING=20 CELLSPACING=1 BORDER=0>\n"
              ."<TR><TD CLASS='BoardRowBody'>\n"
              ."        ".str_replace("\n", "\n        ", $output)."</TD></TR>\n"
              ."</TABLE>\n";
$pagecontents = $output;
include("layout.php");
?>