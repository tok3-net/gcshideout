<?php
$boardfile = "admin/ban.php";
$protectedpage = 1;
$adminfile = 1;
include("common.php");
$title = "Ban User";
if (!$_POST && $action == "ban") { exit; }

if (checkAccess("moderator"))
{
  if ($action == "ban")
  {
    $username = $_POST['username'];
    $userinfo = fetchRow($username, $TableUsers, "username");
    $unban = $_POST['unbandate'];
    $banreason = $_POST['banreason'];
    $slash1 = substr($unban, 2, 1);
    $slash2 = substr($unban, 5, 1);
    if (!$userinfo['bad'])
    {
      $bad = 1;
      $why = "That user does not exist";
    }
    if (($userinfo['classid'] == "1" || $userinfo['classid'] == "2" || $userinfo['classid'] == "3" || $userinfo['classid'] == "4") && (!checkAccess("admin"))) 
    { 
      $bad = 1; 
      $why = "That user is not in an access class you can ban."; 
    }
    if ($slash1 != "/" || $slash2 != "/") { $bad = 1; $why = "You did not enter a correctly formatted unban date."; }
    if (!$bad)
    {
      $email = implode("", file("../templates/banemail.txt"));
      $email = preg_replace('#'.("FNAME").'#', $userinfo['fname'], $email);
      $email = preg_replace('#'.("BOARDNAME").'#', $BoardName, $email);
      $email = preg_replace('#'.("BANREASON").'#', $banreason, $email);
      $email = preg_replace('#'.("UNBANDATE").'#', $unban, $email);
      sendEmail($userinfo['email'], "You Have Been Banned", $email);
      $class = fetchRow("7", $TableClasses, "ID", "format");
      $sql = "UPDATE ".$TableUsers." SET classid = '7', banreason = '$banreason', unbandate = '$unban', format = '$class[format]' WHERE username = '$username' LIMIT 1";
      $exe = runQuery($sql);
      if ($exe)
      {
        $adminaction = "User Banned";
        $description = $username." Was Banned Until ".$unban;
        newAdminAction($adminaction, $description);
        $sysmsg = $username." Was Successfully Banned.";
        $action = "";
      }
      else
      {
        $sysmsg = "An Error Occured, Please Try Again.";
        $action = "";
      }
    }
    else
    {
      $action = "";
      $sysmsg = $why;
    }
  }

  if (!$action || $action == "")
  {
    if (!$username) { $username = $_GET['username']; }
    $output = "<TABLE WIDTH=\"100%\" CELLSPACING=\"1\" CELLPADDING=\"3\" BORDER=\"0\">\n"
	."<TR>\n"
	."<TD CLASS=\"BoardRowB\" WIDTH=\"100%\">\n"
	."<FORM ACTION=\"ban.php\" METHOD=\"POST\" NAME=\"sbform\" onSubmit=\"disableSubmit()\">\n"
	."<SPAN CLASS=\"InputNotes\"><B>Ban A User</B></SPAN><P>\n"
	."<SPAN CLASS=\"InputSection\">Username:</SPAN><BR>\n"
	.inputText("username", $username)."<P>\n"
	."<SPAN CLASS=\"InputSection\">Unban Date (mm/dd/yyyy):</SPAN><BR>\n"
	.inputText("unbandate", $unbandate)."<P>\n"
	."<SPAN CLASS=\"InputSection\">Ban Reason</SPAN><BR>\n"
	."<TEXTAREA COLS=\"50\" ROWS=\"10\" NAME=\"banreason\">- - - Ban Reason - - -</TEXTAREA><P>\n"
	.inputHidden("action", "ban")."\n"
	.inputSubmit("Ban User")."\n"
	."</FORM>\n"
	."</TD>\n"
	."</TR>\n"
	."</TABLE>\n";
  }
}
else
{
  header("Location: ../noaccess.php");
}

include("layout.php");
?>