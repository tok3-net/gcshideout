<?php
   $starttime = microtime();
   $protectedpage = 1;
   $functionset   = "admin";
   include("common.php");
if (($_COOKIE['adminlogin'] != $userdata['adminpass']) || (!$userdata['adminpass'])) { header("Location: login.php"); }
if (!$_POST && $messageid) { exit; }

if (checkAccess("accessadmin"))
{
                           
       $navigation[] = array("name" => "View Single Message",
                             "url"  => "$PHP_SELF?action=viewmessage");

       if ($messageid)
       {
         $navigationhead = "Message ".$messageid;

         $viewmessage = viewSingleMessage($messageid);
         if ($viewmessage['html'])
         {
           $output = $viewmessage['html'];
           $nowrap = 1;
           $sysmsg = "custom";
           $sysmsgcustomcontent = "Viewing message ".$messageid;
	$adminaction = "Message Viewed";
	$description = "Message No. ".$messageid." Was Viewed";
       newAdminAction($adminaction, $description);
         }
         else
         {
           $sysmsg = "custom";
           $sysmsgcustomcontent = "Invalid Message ID: $messageid";
           $messageid = "";
         }
       }

       if (!$messageid)
       {
         $navigationhead = "Selection";

         $output = "<B>View Individual Message</B><BR>\n"
                  ."Enter the ID number of a message to view it.<BR>\n"
                  ."<FORM ACTION='$PHP_SELF' METHOD=POST>\n"
                  .inputHidden("action", "viewmessage")
                  .inputText("messageid", "", 5)
                  .inputSubmit("View")
                  ."</FORM>\n";
       }
       
}
else
{
header("Location: ../noaccess.php");
}

     $output = "<TABLE WIDTH=100% CELLPADDING=20 CELLSPACING=1 BORDER=0>\n"
              ."<TR><TD CLASS='BoardRowBody'>\n"
              ."        ".str_replace("\n", "\n        ", $output)."</TD></TR>\n"
              ."</TABLE>\n";
$pagecontents = $output;
include("layout.php");
?>