/**
 * Displays an confirmation box before running a link object
 * This function is called while clicking links
 *
 * @param   object   the link
 * @param   object   the sql query to submit
 *
 * @return  boolean  whether to run the query or not
 */
function confirmLink(theLink, textItem)
{
    // browser is Opera (crappy js implementation)
    if (typeof(window.opera) != 'undefined') {
        return true;
    }

    var is_confirmed = confirm('Do you really want to' + ' ' + textItem);
    if (is_confirmed) {
        theLink.href += '&is_js_confirmed=1';
    }

    return is_confirmed;
} // end of the 'confirmLink()' function

function quickreply() 
{
  if (document.getElementById('quickreply').style.display=='none') 
  {
    document.getElementById('quickreply').style.display='block';
  } 
  else 
  {
    document.getElementById('quickreply').style.display='none';
  }
}

function posting()
{
	document.gcform.postbutton.value='Processing... Please Wait...';
	document.gcform.postbutton.disabled=true;
}

function toggleChecks(numberboxes)
{
  if (numberboxes > 0)
  {
    if (document.sbform.del1.checked) { newcheckval = false; }
    else { newcheckval = true; }
    for (icounter = 1; icounter <= numberboxes; icounter++)
    {
      document.getElementById('del' + icounter).checked = newcheckval;
    }
  }
}

function hideShowElement(elementID)
{
	elementObj = document.getElementById(elementID).style;
	if (elementObj.display == 'none')
	{
		elementObj.display = '';
	}
	else
	{
		elementObj.display = 'none';
	}
}