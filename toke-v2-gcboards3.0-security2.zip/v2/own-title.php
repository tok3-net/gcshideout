<?php
   $starttime = microtime();
   $protectedpage = 1;
   include("common.php");
if ((checkAccess("accessvip")) && (($_COOKIE['adminlogin'] != $userdata['adminpass']) || (!$userdata['adminpass']))) { header("Location: admin/login.php"); }

   $navigation[] = array("name" => "Change Your Title",
                         "url"  => $PHP_SELF);
   
   $mandatory = "<SPAN CLASS='red'>�</SPAN>";
   
   $allowedfileextensions = array("php", "php3", "html", "txt");
   global $userdata;
   if (checkAccess("accessnameformat") || $EditOwnTitle || $userdata['shoptitle'])
   {

       $username = $userdata['displayname'];
       
       if (!$username) { $err[] = "No username was entered"; }
       else
       {
         $usersearchdata = fetchRow($username, TABLE_USERS, "displayname", "idfieldistext", "dontcareifblank");
         if ($usersearchdata['ID']) 
         { 
           $userid = $usersearchdata['ID'];
         }
         else
         {
           $err[] = "No such user: ".$username;
         }

         if ($err)
         {
           $action = "";
           $reason = implode("<BR>\n", $err);
         }
         else
         {
           $userinfo = getUserInformation($userid);
           
           $currenttitle = applyOnlyTextEffects($userinfo['title']);
	$sqltitle = $userinfo['title'];
           
           include("elements/usertitle.php");
           $output = "<FORM ACTION='".$PHP_SELF."' METHOD=POST>\n"
                    .inputHidden("action", "save")
                    .inputHidden("userid", $userid)
                    .inputHidden("username", $userinfo['displayname'])
                    .$titleform
                    .inputSubmit("Update Title")
                    ."</FORM>\n";
         }

       }
       
     if ($action == "save")
     {
       $data['title'] = $newtitle;
	if ($userdata['shoptitle'])
	{
       	$data['shoptitle'] = $userdata['shoptitle'] - "1";    
	}   
	if (checkAccess("accessvip"))
	{
	  $adminaction = "Title Updated";
	  $description = $userinfo['displayname']." Updated Their Title";
                newAdminAction($adminaction, $description);
	}
       $update = updateUser($userid, $data, "no");
       
       $action = "done";
       $sysmsg = "custom";
       $sysmsgcustomcontent = "Title for ".$username." has been updated";
     }

	 if ($action == "done")
	 {
		$output = "Click <a href=\"own-title.php\">Here</a> To View Or Change Your Title.";
	 }


     

   }
   else
   {
header("Location: noaccess.php");
   }
   
   if ($reason)
   {
     $reasonoutput = "<B CLASS='red'>".$reason."</B>\n"
                    ."<P>\n";
   }
   
   $output = $reasonoutput.$output;
   
   // ALWAYS wrap output on this page.
   $wrapoutput = 1;
   
   if ($wrapoutput)
   {
     $output = "<TABLE WIDTH=100% CELLPADDING=20 CELLSPACING=1 BORDER=0>\n"
              ."<TR><TD CLASS='BoardRowBody'>\n"
              ."        ".str_replace("\n", "\n        ", $output)."</TD></TR>\n"
              ."</TABLE>\n";
   }      


   $pagecontents = $output;
   include("layout.php");
?>