<?php
   $starttime = microtime();
   include("common.php");
$protectedpage = 1;
$navigationhead = "Staff List";

$sql = "SELECT u.ID, u.displayname, u.lastlogin, u.created, u.classid, c.ID AS classid, c.classname FROM ".TABLE_USERS." u, ".TABLE_ACCESS_CLASS." c WHERE c.ID = u.classid AND (c.ID = '1' OR c.ID = '2' OR c.ID = '3' OR c.ID = '4') ORDER BY u.ID ASC";
$exe = runQuery($sql);
$output = "<TABLE CLASS='BoardRowBody' WIDTH=100%><TR><TD WIDTH=100% ALIGN=CENTER><H1>Staff List</H1></TD></TR></TABLE>"
."<TABLE BORDER=0 CELLSPACING=1 CELLPADDING=2 CLASS='MainTable' WIDTH=100%>"
."<tr>\n"
."<td class=\"BoardColumn\">Username</td>\n"
."<td class=\"BoardColumn\">Class</td>\n"
."<td class=\"BoardColumn\">Last Login</td>\n"
."<td class=\"BoardColumn\">Options</td>\n"
."</tr>\n";
while ($row = fetchResultArray($exe))
{
  $output .= "<tr>\n"
	."<td class=\"BoardRowBody\"><a href=\"user.php?user=".$row['ID']."\" class=\"AuthorLink\">".usernameDisplay($row['ID'], '', '')."</a></td>\n"
	."<td class=\"BoardRowHeading\">".$row['classname']."</td>\n"
	."<td class=\"BoardRowBody\">".dateNeat($row['lastlogin'])."</td>\n"
	."<td class=\"BoardRowHeading\">".makeLink("private.php?action=send&recipient=".$row['displayname'], "Send PM", "BoardRowHeadingLink")." | \n"
	.makeLink("messages.php?userid=".$row['ID'], "Post History", "BoardRowHeadingLink")."</td>\n"
	."</tr>\n";
}
$output .= "</table>\n";
/*
$classid = $row[classid];
if ($classid == "1")
{
$adminnames = "<H3><U>".$row[classname]."</U></H3>";
$admin .= "<A HREF='user.php?user=".$row[ID]."' CLASS='AuthorLink'>".usernameDisplay($row[ID],'','')."</A><BR>";
}
if ($classid == "2")
{
$managername = "<H3><U>".$row[classname]."</U></H3>";
$manager .= "<A HREF='user.php?user=".$row[ID]."' CLASS='AuthorLink'>".usernameDisplay($row[ID],'','')."</A><BR>";
}
if ($classid == "3")
{
$modname = "<H3><U>".$row[classname]."</U></H3>";
$mod .= "<A HREF='user.php?user=".$row[ID]."' CLASS='AuthorLink'>".usernameDisplay($row[ID],'','')."</A><BR>";
}
if ($classid == "4")
{
$vipname = "<H3><U>".$row[classname]."</U></H3>";
$vip .= "<A HREF='user.php?user=".$row[ID]."' CLASS='AuthorLink'>".usernameDisplay($row[ID],'','')."</A><BR>";
}
}

$output .= "<TR><TD WIDTH=25% ALIGN=CENTER VALIGN=TOP>".$adminnames
.$admin
."</TD>"
."<TD WIDTH=25% ALIGN=CENTER VALIGN=TOP>".$managername
.$manager
."</TD>"
."<TD WIDTH=25% ALIGN=CENTER VALIGN=TOP>".$modname
.$mod
."</TD>"
."<TD WIDTH=25% ALIGN=CENTER VALIGN=TOP>".$vipname
.$vip
."</TD>"
."</TR></TABLE>";
*/
   
$pagecontents = $output;
   include("layout.php");
?>