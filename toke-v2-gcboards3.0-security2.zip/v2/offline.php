<?php
  $starttime = microtime();
  $dontredirect = 1;
  include("common.php");
  $navigationhead = "Board Offline";
   
  $output = "<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"20\">\n"
	."<tr>\n"
	."<td class=\"BoardRowBody\" width=\"100%\">\n"
	.$BoardOfflineDesc
	."</td>\n"
	."</tr>\n"
	."</table>\n";

  $pagecontents = $output;
  include("layout.php");
?>
