<?php
   $starttime = microtime();
   $functionset = "iconview";
   
   include("common.php");
   
   $iconinfo = fetchRow($iconid, TABLE_ICONS);
	header("Location: ".$GFXRoot."/icons/".$iconinfo['data']);
	exit;
/*
   $iconmime = $iconinfo[mimetype];

   $icondata = base64ToFile($iconinfo[data]);
   
   Header("Content-type: ".$iconmime);
   echo $icondata;
   exit();
*/
?>