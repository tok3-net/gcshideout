<?php
global $userdata;
if((!$userdata['stylesheet']) || ($userdata['stylesheet'] == "NULL"))
{
   $css = "default.php";
}
else
{
   $css = $userdata['stylesheet'];
}
include("stylesheets/".$css.".php");
?>